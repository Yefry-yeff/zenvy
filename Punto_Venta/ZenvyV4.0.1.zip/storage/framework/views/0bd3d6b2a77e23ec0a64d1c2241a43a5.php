<div>
    <!-- MENSAJES DE SESIÓN -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>✅ Éxito:</strong> <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>⚠️ Advertencia:</strong> <?php echo e(session('warning')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>❌ Error:</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- CONTENEDOR PRINCIPAL OPTIMIZADO -->
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">📦 Productos Recibidos en Bodega</h5>
            <div class="flex items-center gap-2">
                <span class="text-sm opacity-90">Total: <?php echo e($productosRecibidos->total()); ?></span>
            </div>
        </div>

        <!-- FILTROS Y BÚSQUEDA -->
        <div class="px-4 py-3 bg-gray-50 border-b">
            <div class="grid grid-cols-1 gap-4 md:grid-cols-4">
                <!-- Búsqueda de Producto -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Buscar Producto</label>
                    <input type="text" 
                           wire:model.live.debounce.300ms="filtroProducto"
                           placeholder="Nombre, código de barras..."
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Filtro de Bodega -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Bodega</label>
                    <select wire:model.live="filtroBodega" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                        <option value="">Todas las bodegas</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bodega->id); ?>"><?php echo e($bodega->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>

                <!-- Filtro de Estado Stock -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Estado Stock</label>
                    <select wire:model.live="filtroEstado" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                        <option value="">Todos</option>
                        <option value="disponible">Disponible</option>
                        <option value="poco_stock">Poco Stock</option>
                        <option value="agotado">Agotado</option>
                    </select>
                </div>

                <!-- Filtro de Marca -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Marca</label>
                    <select wire:model.live="filtroMarca" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                        <option value="">Todas las marcas</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
            </div>
            
            <div class="mt-3">
                <button wire:click="limpiarFiltros" class="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                    🗑️ Limpiar Filtros
                </button>
            </div>
        </div>

        <!-- INFORMACIÓN DE RESULTADOS -->
        <div class="px-4 py-2 bg-gray-100 border-b">
            <div class="text-sm text-gray-600">
                Showing <?php echo e($productosRecibidos->firstItem() ?? 0); ?> to <?php echo e($productosRecibidos->lastItem() ?? 0); ?> 
                of <?php echo e($productosRecibidos->total()); ?> results
                <!--[if BLOCK]><![endif]--><?php if($filtroProducto): ?>
                    | Filtrado por: "<?php echo e($filtroProducto); ?>"
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!-- TABLA OPTIMIZADA -->
        <div class="px-4 py-3">
            <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->count() > 0): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full table-auto border border-gray-200">
                        <thead class="bg-gray-50">
                            <!-- Encabezados con ordenamiento -->
                            <tr>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100" 
                                    wire:click="ordenar('producto_nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Producto</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'producto_nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('codigo_barra')">
                                    <div class="flex items-center space-x-1">
                                        <span>Código</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'codigo_barra'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('marca_nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Marca</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'marca_nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('bodega_nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Bodega</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'bodega_nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b">Segmento</th>
                                <th class="px-4 py-3 text-left border-b">Sección</th>
                                <th class="px-4 py-3 text-center border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('cantidad_disponible')">
                                    <div class="flex items-center justify-center space-x-1">
                                        <span>Stock</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'cantidad_disponible'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-center border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('fecha_recibido')">
                                    <div class="flex items-center justify-center space-x-1">
                                        <span>Fecha Recibido</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'fecha_recibido'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-center border-b">Fecha Expiración</th>
                                <th class="px-4 py-3 text-center border-b">Estado</th>
                                <th class="px-4 py-3 text-center border-b">Comentario</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productosRecibidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50 cursor-pointer <?php echo e($item->cantidad_disponible > 10 ? 'bg-green-50' : ($item->cantidad_disponible > 0 ? 'bg-yellow-50' : 'bg-red-50')); ?>"
                                    wire:click="editarProducto(<?php echo e($item->producto_id); ?>)"
                                    title="Clic para editar producto">
                                    
                                    <!-- Producto -->
                                    <td class="px-4 py-3 border-b">
                                        <div class="flex flex-col">
                                            <span class="font-semibold text-gray-900"><?php echo e($item->producto_nombre); ?></span>
                                            <!--[if BLOCK]><![endif]--><?php if($item->producto_descripcion): ?>
                                                <small class="text-gray-500"><?php echo e(Str::limit($item->producto_descripcion, 30)); ?></small>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </td>

                                    <!-- Código -->
                                    <td class="px-4 py-3 border-b">
                                        <code class="text-sm bg-gray-100 px-2 py-1 rounded"><?php echo e($item->codigo_barra ?? 'N/A'); ?></code>
                                    </td>

                                    <!-- Marca -->
                                    <td class="px-4 py-3 border-b text-gray-700">
                                        <?php echo e($item->marca_nombre ?? 'Sin marca'); ?>

                                    </td>

                                    <!-- Bodega -->
                                    <td class="px-4 py-3 border-b">
                                        <div class="flex flex-col">
                                            <span class="font-semibold text-gray-900"><?php echo e($item->bodega_nombre); ?></span>
                                            <small class="text-gray-500"><?php echo e($item->tienda_nombre); ?></small>
                                        </div>
                                    </td>

                                    <!-- Segmento -->
                                    <td class="px-4 py-3 border-b text-gray-700">
                                        <?php echo e($item->segmento_descripcion ?? 'N/A'); ?>

                                    </td>

                                    <!-- Sección -->
                                    <td class="px-4 py-3 border-b text-gray-700">
                                        <?php echo e($item->seccion_descripcion ?? 'N/A'); ?>

                                    </td>

                                    <!-- Stock -->
                                    <td class="px-4 py-3 border-b text-center">
                                        <span class="font-bold <?php echo e($item->cantidad_disponible > 10 ? 'text-green-600' : ($item->cantidad_disponible > 0 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                            <?php echo e(number_format($item->cantidad_disponible, 0)); ?>

                                        </span>
                                        <div class="text-xs text-gray-500"><?php echo e($item->unidad_medida ?? 'Unidad'); ?></div>
                                    </td>

                                    <!-- Fecha Recibido -->
                                    <td class="px-4 py-3 border-b text-center text-sm text-gray-600">
                                        <?php echo e(\Carbon\Carbon::parse($item->fecha_recibido)->format('d/m/Y')); ?>

                                    </td>

                                    <!-- Fecha Expiración -->
                                    <td class="px-4 py-3 border-b text-center text-sm">
                                        <!--[if BLOCK]><![endif]--><?php if($item->fecha_expiracion): ?>
                                            <?php
                                                $fechaExpiracion = \Carbon\Carbon::parse($item->fecha_expiracion);
                                                $diasRestantes = $fechaExpiracion->diffInDays(now(), false);
                                            ?>
                                            <span class="<?php echo e($diasRestantes > 30 ? 'text-green-600' : ($diasRestantes > 7 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                                <?php echo e($fechaExpiracion->format('d/m/Y')); ?>

                                                <!--[if BLOCK]><![endif]--><?php if($diasRestantes <= 30): ?>
                                                    <div class="text-xs">(<?php echo e(abs($diasRestantes)); ?> días)</div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">N/A</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <!-- Estado -->
                                    <td class="px-4 py-3 border-b text-center">
                                        <!--[if BLOCK]><![endif]--><?php if($item->cantidad_disponible > 10): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold text-white bg-green-500 rounded-full">Disponible</span>
                                        <?php elseif($item->cantidad_disponible > 0): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold text-white bg-yellow-500 rounded-full">Poco Stock</span>
                                        <?php else: ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold text-white bg-red-500 rounded-full">Agotado</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <!-- Comentario -->
                                    <td class="px-4 py-3 border-b text-sm">
                                        <!--[if BLOCK]><![endif]--><?php if($item->comentario): ?>
                                            <span title="<?php echo e($item->comentario); ?>" class="text-gray-700"><?php echo e(Str::limit($item->comentario, 20)); ?></span>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-12">
                    <div class="flex flex-col items-center">
                        <svg class="w-16 h-16 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-4.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 009.586 13H7"></path>
                        </svg>
                        <span class="text-xl text-gray-500 font-medium">No hay productos recibidos en bodega</span>
                        <small class="text-gray-400 mt-1">Los productos aparecerán aquí cuando sean distribuidos a las bodegas</small>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- PAGINACIÓN PERSONALIZADA CON SELECTOR -->
            <div class="mt-4">
                <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->hasPages()): ?>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-4">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($productosRecibidos->firstItem()); ?> to <?php echo e($productosRecibidos->lastItem()); ?> of <?php echo e($productosRecibidos->total()); ?> results
                            </div>
                            <div class="flex items-center gap-2">
                                <label class="text-sm text-gray-600">Show:</label>
                                <select wire:model.live="registrosPorPagina" class="px-2 py-1 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                        </div>
                        <div class="flex space-x-1">
                            
                            <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->onFirstPage()): ?>
                                <span class="px-3 py-2 text-sm text-gray-400 bg-gray-200 border border-gray-300 rounded cursor-not-allowed">Previous</span>
                            <?php else: ?>
                                <button wire:click="previousPage" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50">Previous</button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <?php
                                $currentPage = $productosRecibidos->currentPage();
                                $lastPage = $productosRecibidos->lastPage();
                                $start = max(1, min($currentPage - 2, $lastPage - 4));
                                $end = min($start + 4, $lastPage);
                            ?>

                            <!--[if BLOCK]><![endif]--><?php for($page = $start; $page <= min($end, $lastPage); $page++): ?>
                                <!--[if BLOCK]><![endif]--><?php if($page == $currentPage): ?>
                                    <span class="px-3 py-2 text-sm font-medium text-blue-600 bg-blue-50 border border-blue-300 rounded"><?php echo e($page); ?></span>
                                <?php else: ?>
                                    <button wire:click="gotoPage(<?php echo e($page); ?>)" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50"><?php echo e($page); ?></button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <!--[if BLOCK]><![endif]--><?php if($end < $lastPage): ?>
                                <!--[if BLOCK]><![endif]--><?php if($end < $lastPage - 1): ?>
                                    <span class="px-3 py-2 text-sm text-gray-400">...</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <button wire:click="gotoPage(<?php echo e($lastPage); ?>)" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50"><?php echo e($lastPage); ?></button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->hasMorePages()): ?>
                                <button wire:click="nextPage" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50">Next</button>
                            <?php else: ?>
                                <span class="px-3 py-2 text-sm text-gray-400 bg-gray-200 border border-gray-300 rounded cursor-not-allowed">Next</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                <?php else: ?>
                    <div class="flex items-center gap-4">
                        <div class="text-sm text-gray-700">
                            Showing <?php echo e($productosRecibidos->firstItem() ?? 0); ?> to <?php echo e($productosRecibidos->lastItem() ?? 0); ?> of <?php echo e($productosRecibidos->total()); ?> results
                        </div>
                        <div class="flex items-center gap-2">
                            <label class="text-sm text-gray-600">Show:</label>
                            <select wire:model.live="registrosPorPagina" class="px-2 py-1 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

</div> <?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/lista-de-productos.blade.php ENDPATH**/ ?>