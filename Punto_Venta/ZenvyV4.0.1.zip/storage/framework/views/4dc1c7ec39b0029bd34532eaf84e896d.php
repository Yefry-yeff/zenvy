<div
    class="overflow-hidden border border-gray-300 rounded shadow"
    x-data="{ sinCambiosModal: false }"
    x-init="$watch('theme', t => localStorage.setItem('theme', t))"
    x-on:mostrar-sin-cambios.window="sinCambiosModal = true"
>

    <!-- ENCABEZADO CON TEMA -->
    <div
        class="flex items-center justify-between px-4 py-2 font-semibold text-white"
        :class="{
            'bg-emerald-600': theme === 'verde',
            'bg-blue-600': theme === 'azul',
            'bg-gray-900': theme === 'oscuro',
            'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
        }"
    >
        <button wire:click="volver" class="px-3 py-1 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
            ← Volver
        </button>
        <h5><?php echo e($categoriaId ? 'Editar Categoría' : 'Crear Categoría'); ?></h5>
        <div></div> <!-- Spacer para mantener el centrado -->
    </div>

    <!-- DATOS DE LA CATEGORÍA -->
    <div class="p-4">
        <div class="p-4 bg-white border shadow rounded-xl">
            <h2 class="mb-4 text-lg font-semibold text-gray-700">📁 Datos de la Categoría</h2>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Nombre de la Categoría<span class="text-red-600">*</span></label>
                <input type="text" wire:model.defer="form.nombre" class="w-full px-3 py-2 border rounded" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!--[if BLOCK]><![endif]--><?php if(!$categoriaId): ?>
                <!-- Botón para proceder a subcategorías (solo en modo agregar) -->
                <div class="flex justify-end">
                    <button
                        wire:click="procederASubcategorias"
                        class="px-4 py-2 text-white rounded"
                        :class="{
                            'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                            'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                            'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                            'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                        }"
                    >
                        📂 Ingresar Subcategoría
                    </button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- SUBCATEGORÍAS -->
    <div class="p-4" x-data="{ mostrarSubcategorias: <?php if ((object) ('mostrarSeccionSubcategorias') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarSeccionSubcategorias'->value()); ?>')<?php echo e('mostrarSeccionSubcategorias'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarSeccionSubcategorias'); ?>')<?php endif; ?> }">
        <div class="p-4 bg-white border shadow rounded-xl">
            <h2 class="mb-4 text-lg font-semibold text-gray-700">📂 Subcategorías</h2>

            <!--[if BLOCK]><![endif]--><?php if($categoriaId): ?>
                <!-- Agregar nueva subcategoría (solo en modo editar) -->
                <div class="flex gap-2 mb-4">
                    <input
                        type="text"
                        wire:model.defer="nuevaSubcategoria"
                        placeholder="Nombre de la nueva subcategoría"
                        class="flex-1 px-3 py-2 border rounded"
                    />
                    <button
                        wire:click="agregarSubcategoria"
                        class="px-4 py-2 text-white rounded"
                        :class="{
                            'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                            'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                            'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                            'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                        }"
                    >
                        ➕ Agregar
                    </button>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevaSubcategoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Lista de subcategorías (solo en modo editar) -->
                <!--[if BLOCK]><![endif]--><?php if($subcategorias->count() > 0): ?>
                    <table id="subcategoriaTable" class="w-full text-sm text-left border border-gray-300">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-3 py-2 border">ID</th>
                                <th class="px-3 py-2 border">Nombre</th>
                                <th class="px-3 py-2 border">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-3 py-2 border cursor-pointer" wire:click="editarSubcategoria(<?php echo e($subcategoria->id); ?>)"><?php echo e($subcategoria->id); ?></td>
                                    <td class="px-3 py-2 border cursor-pointer" wire:click="editarSubcategoria(<?php echo e($subcategoria->id); ?>)"><?php echo e($subcategoria->nombre); ?></td>
                                    <td class="px-3 py-2 border">
                                        <button
                                            wire:click="eliminarSubcategoria(<?php echo e($subcategoria->id); ?>)"
                                            class="p-0 btn btn-link"
                                            title="Eliminar"
                                            onclick="event.stopPropagation();"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 7v12a2 2 0 002 2h8a2 2 0 002-2V7M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2m-7 0h10" style="color:#e3342f;" />
                                                <line x1="10" y1="11" x2="10" y2="17" stroke="#e3342f" stroke-width="2"/>
                                                <line x1="14" y1="11" x2="14" y2="17" stroke="#e3342f" stroke-width="2"/>
                                            </svg>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="italic text-gray-600">No hay subcategorías asignadas a esta categoría.</p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Botón guardar para modo editar -->
                <div class="flex justify-end mt-4">
                    <button
                        wire:click="guardar"
                        class="px-6 py-2 font-medium text-white rounded"
                        :class="{
                            'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                            'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                            'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                            'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                        }"
                    >
                        💾 Guardar Categoría
                    </button>
                </div>
            <?php else: ?>
                <!-- Modo agregar -->
                <div x-show="!mostrarSubcategorias">
                    <!-- Mensaje informativo inicial -->
                    <div class="p-4 text-center border-2 border-gray-300 border-dashed rounded-lg bg-gray-50">
                        <div class="text-gray-500">
                            <i class="mb-2 text-2xl fas fa-info-circle"></i>
                            <p class="text-sm font-medium">Las subcategorías se podrán gestionar después de crear la categoría</p>
                            <p class="mt-1 text-xs text-gray-400">Guarda primero la categoría principal para agregar subcategorías</p>
                        </div>
                    </div>
                </div>

                <div x-show="mostrarSubcategorias" x-transition>
                    <!-- Sección habilitada para agregar subcategorías -->
                    <div class="p-4 mb-4 border border-green-200 rounded-lg bg-green-50">
                        <div class="text-center text-green-700">
                            <i class="mb-2 text-xl fas fa-check-circle"></i>
                            <p class="text-sm font-medium">¡Perfecto! Ahora puedes agregar subcategorías (opcional)</p>
                            <p class="mt-1 text-xs">Puedes agregar subcategorías o guardar directamente la categoría</p>
                        </div>
                    </div>

                    <!-- Campo para nueva subcategoría -->
                    <div class="flex gap-2 mb-4">
                        <input
                            type="text"
                            wire:model.defer="nuevaSubcategoria"
                            placeholder="Nombre de la nueva subcategoría (opcional)"
                            class="flex-1 px-3 py-2 border rounded"
                        />
                        <button
                            wire:click="agregarSubcategoriaTemporal"
                            class="px-4 py-2 text-white rounded"
                            :class="{
                                'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                                'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                                'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                                'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                            }"
                        >
                            ➕ Agregar
                        </button>
                    </div>

                    <!-- Lista temporal de subcategorías -->
                    <!--[if BLOCK]><![endif]--><?php if(!empty($subcategoriasTemporales)): ?>
                        <div class="mb-4">
                            <h4 class="mb-2 text-sm font-medium text-gray-700">Subcategorías a crear:</h4>
                            <table id="subcategoriaTable" class="w-full text-sm text-left border border-gray-300">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-3 py-2 border">#</th>
                                        <th class="px-3 py-2 border">Nombre</th>
                                        <th class="px-3 py-2 border">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subcategoriasTemporales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-3 py-2 border"><?php echo e($index + 1); ?></td>
                                            <td class="px-3 py-2 border"><?php echo e($subcategoria); ?></td>
                                            <td class="px-3 py-2 border">
                                                <button
                                                    wire:click="eliminarSubcategoriaTemporal(<?php echo e($index); ?>)"
                                                    class="p-0 btn btn-link"
                                                    title="Eliminar"
                                                >
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 7v12a2 2 0 002 2h8a2 2 0 002-2V7M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2m-7 0h10" style="color:#e3342f;" />
                                                        <line x1="10" y1="11" x2="10" y2="17" stroke="#e3342f" stroke-width="2"/>
                                                        <line x1="14" y1="11" x2="14" y2="17" stroke="#e3342f" stroke-width="2"/>
                                                    </svg>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mb-4 italic text-gray-600">No hay subcategorías agregadas aún.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Botón guardar para modo agregar -->
                    <div class="flex justify-end">
                        <button
                            wire:click="guardar"
                            class="px-6 py-2 font-medium text-white rounded"
                            :class="{
                                'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                                'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                                'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                                'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                            }"
                        >
                            💾 Guardar Categoría
                        </button>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- MENSAJE DE ÉXITO -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarMensaje): ?>
    <div
        x-data="{ show: true }"
        x-show="show"
        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
        @click.outside="show = false; Livewire.dispatch('cambiarVista', { ruta: 'Inventario.Categoria' })"
        @keydown.window.escape="show = false; Livewire.dispatch('cambiarVista', { ruta: 'Inventario.Categoria' })"
    >
        <div class="w-full max-w-sm p-6 text-center bg-white rounded-lg shadow-lg">
            <h2 class="mb-2 text-lg font-semibold text-green-700">✅ Categoría guardada correctamente</h2>
            <p class="text-sm text-gray-600">Los cambios se han guardado exitosamente.</p>
            <button
                class="px-4 py-2 mt-4 text-sm text-white rounded bg-emerald-600 hover:bg-emerald-700"
                @click="show = false; Livewire.dispatch('cambiarVista', { ruta: 'Inventario.Categoria' })"
            >
                Cerrar
            </button>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- MENSAJES DE SESIÓN -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('mensaje')): ?>
        <div x-data="{ show: true }" x-show="show"
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="mt-3 mb-0 transition-opacity duration-300 alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div x-data="{ show: true }" x-show="show"
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="mt-3 mb-0 transition-opacity duration-300 alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal Eliminar Subcategoría -->
    <div wire:key="modal-eliminar-subcategoria">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($modalEliminarSubcategoriaAbierto): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cerrarModalEliminarSubcategoria()"
        >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="text-white modal-header bg-danger">
                        <h5 class="modal-title">¿Eliminar subcategoría?</h5>
                    </div>
                    <div class="modal-body">
                        <p>¿Estás seguro que deseas eliminar esta subcategoría? Esta acción no se puede deshacer.</p>
                        <div class="flex justify-end gap-2 mt-4">
                            <button type="button" class="btn btn-secondary" wire:click="cerrarModalEliminarSubcategoria">No</button>
                            <button type="button" class="btn btn-danger" wire:click="confirmarEliminarSubcategoria">Sí, eliminar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Editar Subcategoría -->
    <div wire:key="modal-editar-subcategoria">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($modalEditarSubcategoriaAbierto): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cerrarModalEditarSubcategoria()"
        >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header"
                         :class="{
                            'bg-emerald-700 text-white': theme === 'verde',
                            'bg-blue-700 text-white': theme === 'azul',
                            'bg-gray-900 text-white': theme === 'oscuro',
                            'bg-slate-700 text-white': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                         }"
                    >
                        <h5 class="modal-title">Editar Subcategoría</h5>
                    </div>
                    <div class="modal-body">
                        <form wire:submit.prevent="guardarSubcategoria">
                            <div class="mb-3">
                                <label for="subcategoriaNombre" class="form-label">Nombre de la Subcategoría</label>
                                <input type="text" id="subcategoriaNombre" class="form-control" wire:model.defer="formSubcategoria.nombre">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['formSubcategoria.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="flex justify-end mt-4">
                                <button
                                    type="submit"
                                    class="px-4 py-2 text-white rounded"
                                    :class="{
                                        'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                                        'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                                        'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                                        'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                                    }"
                                >
                                    💾 Guardar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/categoria-form.blade.php ENDPATH**/ ?>