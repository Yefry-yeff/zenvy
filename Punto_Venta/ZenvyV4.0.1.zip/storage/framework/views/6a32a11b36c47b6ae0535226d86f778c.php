<div class="px-4 container-fluid">
    <!-- Encabezado -->
    <div class="mb-4 row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="mb-0 text-gray-800 h3">Lista de Facturas</h1>
            </div>
        </div>
    </div>

    <!-- Tabla de Facturas -->
    <div class="row">
        <div class="col-12">
            <!-- Información de filtro por usuario -->
            <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                <!--[if BLOCK]><![endif]--><?php if($esAdmin ?? false): ?>
                    <div class="mb-3 alert alert-success border-left-success">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-user-shield me-2"></i>
                            <div>
                                <strong>Vista de Administrador:</strong> Puedes ver todas las facturas del sistema.
                                <small class="d-block text-muted">Usuario: <?php echo e(Auth::user()->name); ?> (Admin)</small>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="mb-3 alert alert-info border-left-info">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle me-2"></i>
                            <div>
                                <strong>Vista personalizada:</strong> Solo se muestran las facturas que has creado.
                                <small class="d-block text-muted">Usuario actual: <?php echo e(Auth::user()->name); ?></small>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="shadow card">
                <div class="py-3 card-header">
                    <h6 class="m-0 font-weight-bold text-primary">Facturas Registradas</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="listafacturasTable" class="table table-hover table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 8%;">ID</th>
                                    <th style="width: 12%;">No. Fac</th>
                                    <th style="width: 20%;">Cliente</th>
                                    <th style="width: 12%;">RTN</th>
                                    <th style="width: 12%;">Fecha</th>
                                    <th style="width: 10%;" class="text-end">Subtotal</th>
                                    <th style="width: 8%;" class="text-end">ISV</th>
                                    <th style="width: 10%;" class="text-end">Total</th>
                                    <th style="width: 10%;">Estado</th>
                                    <th style="width: 8%;" class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr wire:click="verDetalle(<?php echo e($factura->id); ?>)">
                                        <td><?php echo e($factura->id); ?></td>
                                        <td>
                                            <strong><?php echo e($factura->numero_factura ?? 'N/A'); ?></strong>
                                        </td>
                                        <td><?php echo e($factura->nombre_cliente ?? 'Cliente General'); ?></td>
                                        <td><?php echo e($factura->rtn ?? 'N/A'); ?></td>
                                        <td>
                                            <?php echo e(\Carbon\Carbon::parse($factura->fecha_emision)->format('d/m/Y')); ?>

                                        </td>
                                        <td class="text-end">L. <?php echo e(number_format($factura->sub_total, 2)); ?></td>
                                        <td class="text-end">L. <?php echo e(number_format($factura->isv, 2)); ?></td>
                                        <td class="text-end"><strong>L. <?php echo e(number_format($factura->total, 2)); ?></strong></td>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($factura->estado_factura_id == 1): ?>
                                                <span class="badge bg-success">Pagada</span>
                                            <?php elseif($factura->estado_factura_id == 2): ?>
                                                <span class="badge bg-warning">Pendiente</span>
                                            <?php elseif($factura->estado_factura_id == 3): ?>
                                                <span class="badge bg-danger">Anulada</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Desconocido</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                        <td class="text-center" onclick="event.stopPropagation()">
                                            <a href="<?php echo e(route('factura.pdf.preview', $factura->id)); ?>" 
                                               target="_blank" 
                                               class="btn btn-sm btn-success"
                                               title="Imprimir Factura">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            <button class="btn btn-sm btn-danger"
                                                    wire:click="generarPDF(<?php echo e($factura->id); ?>)"
                                                    title="Descargar PDF">
                                                <i class="fas fa-file-pdf"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="10" class="py-4 text-center">
                                            <div class="text-muted">
                                                <i class="mb-3 fas fa-file-invoice fa-3x"></i>
                                                <p class="mb-0">No se encontraron facturas</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de impresión de factura -->
    <!--[if BLOCK]><![endif]--><?php if($facturaParaImprimir): ?>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-print"></i>
                            Impresión de Factura <?php echo e($facturaParaImprimir->numero_factura); ?>

                        </h5>
                        <button type="button" class="btn-close" wire:click="cerrarImpresion"></button>
                    </div>
                    <div class="p-0 modal-body">
                        <div class="row no-gutters">
                            <!-- Vista previa de la factura -->
                            <div class="col-md-8">
                                <div class="p-3" style="background-color: #f8f9fa; height: 600px; overflow-y: auto;">
                                    <div class="p-4 bg-white shadow-sm" style="max-width: 400px; margin: 0 auto; font-family: Arial, sans-serif; font-size: 12px;">
                                        <?php echo $__env->make('pdf.factura', [
                                            'factura' => $facturaParaImprimir,
                                            'productos' => collect($productosFacturaImpresa),
                                            'pagos' => collect($pagosFacturaImpresa),
                                            'empresa' => \Illuminate\Support\Facades\DB::table('empresa')->first(),
                                            'tienda' => \Illuminate\Support\Facades\DB::table('tienda as t')
                                                ->leftJoin('direccion as d', 't.direccion_sucursal_id', '=', 'd.id')
                                                ->select('t.*', 'd.domicilio_tributario')
                                                ->where('t.id', 1)
                                                ->first(),
                                            'caiFacturaImpresa' => $caiFacturaImpresa
                                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Panel de opciones -->
                            <div class="col-md-4">
                                <div class="p-4">
                                    <h6 class="mb-3">Opciones de impresión</h6>

                                    <div class="gap-2 mb-3 d-grid">
                                        <button onclick="window.print()" class="btn btn-primary">
                                            <i class="fas fa-print"></i> Imprimir ahora
                                        </button>

                                        <a href="<?php echo e(route('factura.pdf', $facturaParaImprimir->id)); ?>"
                                           target="_blank" class="btn btn-danger">
                                            <i class="fas fa-file-pdf"></i> Descargar PDF
                                        </a>

                                        <!--[if BLOCK]><![endif]--><?php if($facturaParaImprimir->factura_imagen): ?>
                                            <a href="<?php echo e(route('factura.imagen', $facturaParaImprimir->id)); ?>"
                                               target="_blank" class="btn btn-info">
                                                <i class="fas fa-image"></i> Ver imagen PNG
                                            </a>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <div class="pt-3 border-top">
                                        <small class="text-muted">
                                            <strong>Información de la factura:</strong><br>
                                            • Cliente: <?php echo e($facturaParaImprimir->nombre_cliente); ?><br>
                                            • Total: L. <?php echo e(number_format($facturaParaImprimir->total, 2)); ?><br>
                                            • Fecha: <?php echo e($facturaParaImprimir->fecha_emision->format('d/m/Y')); ?>

                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="cerrarImpresion">
                            <i class="fas fa-times"></i> Cerrar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal para ver detalle de la factura -->
    <!--[if BLOCK]><![endif]--><?php if($facturaDetalle && $facturaDetalle->id): ?>
        <div class="modal fade show d-flex align-items-center justify-content-center" 
             style="display: flex; background-color: rgba(0,0,0,0.5);" 
             tabindex="-1" 
             role="dialog"
             wire:click="cerrarDetalle">
            <div class="modal-dialog modal-lg" 
                 role="document" 
                 onclick="event.stopPropagation()">
                <div class="modal-content shadow-lg">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">
                            <i class="fas fa-file-invoice mr-2"></i>
                            Detalle de Factura - <?php echo e($facturaDetalle->numero_factura ?? 'N/A'); ?>

                        </h5>
                        <button type="button" class="close text-white" wire:click="cerrarDetalle" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body bg-light">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header bg-info text-white">
                                        <h6 class="mb-0"><i class="fas fa-user"></i> Información del Cliente</h6>
                                    </div>
                                    <div class="card-body">
                                        <p><strong>Nombre:</strong><br><?php echo e($facturaDetalle->nombre_cliente ?? 'Cliente General'); ?></p>
                                        <p><strong>RTN:</strong><br><?php echo e($facturaDetalle->rtn ?? 'N/A'); ?></p>
                                        <p><strong>Fecha:</strong><br><?php echo e(\Carbon\Carbon::parse($facturaDetalle->fecha_emision)->format('d/m/Y H:i')); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header bg-success text-white">
                                        <h6 class="mb-0"><i class="fas fa-receipt"></i> Información de la Factura</h6>
                                    </div>
                                    <div class="card-body">
                                        <p><strong>ID:</strong><br><?php echo e($facturaDetalle->id); ?></p>
                                        <p><strong>No. Factura:</strong><br><?php echo e($facturaDetalle->numero_factura ?? 'N/A'); ?></p>
                                        <p><strong>Estado:</strong><br>
                                            <!--[if BLOCK]><![endif]--><?php if($facturaDetalle->estado_factura_id == 1): ?>
                                                <span class="badge badge-success">Pagada</span>
                                            <?php elseif($facturaDetalle->estado_factura_id == 2): ?>
                                                <span class="badge badge-warning">Pendiente</span>
                                            <?php elseif($facturaDetalle->estado_factura_id == 3): ?>
                                                <span class="badge badge-danger">Anulada</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Desconocido</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header bg-warning text-dark">
                                        <h6 class="mb-0"><i class="fas fa-calculator"></i> Resumen de Totales</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row text-center">
                                            <div class="col-md-3">
                                                <div class="border-right">
                                                    <h6 class="text-muted">Subtotal</h6>
                                                    <h5 class="text-dark">L. <?php echo e(number_format($facturaDetalle->sub_total, 2)); ?></h5>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="border-right">
                                                    <h6 class="text-muted">Descuento</h6>
                                                    <h5 class="text-dark">L. <?php echo e(number_format($facturaDetalle->descuento ?? 0, 2)); ?></h5>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="border-right">
                                                    <h6 class="text-muted">ISV</h6>
                                                    <h5 class="text-dark">L. <?php echo e(number_format($facturaDetalle->isv, 2)); ?></h5>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <h6 class="text-muted">Total</h6>
                                                <h5 class="text-dark font-weight-bold">L. <?php echo e(number_format($facturaDetalle->total, 2)); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary" wire:click="cerrarDetalle">
                            <i class="fas fa-times"></i> Cerrar
                        </button>
                        <!--[if BLOCK]><![endif]--><?php if($facturaDetalle && $facturaDetalle->id): ?>
                            <a href="<?php echo e(route('factura.pdf', $facturaDetalle->id)); ?>" target="_blank" class="btn btn-danger">
                                <i class="fas fa-download"></i> Descargar PDF
                            </a>
                            <a href="<?php echo e(route('factura.pdf.preview', $facturaDetalle->id)); ?>" target="_blank" class="btn btn-success">
                                <i class="fas fa-eye"></i> Visualizar Factura
                            </a>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/sala-de-ventas/lista-de-facturas.blade.php ENDPATH**/ ?>