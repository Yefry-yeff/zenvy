<div class="min-h-screen p-6 bg-gradient-to-br from-purple-50 via-white to-indigo-50">
    <div class="mx-auto max-w-7xl">
        <!-- Header -->
        <div class="p-6 mb-6 bg-white border border-gray-200 shadow-lg rounded-2xl">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <div class="p-3 bg-purple-100 rounded-full">
                        <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800">Cierre de Caja</h1>
                        <p class="text-gray-600">
                            Resumen del día y conteo de efectivo
                            <!--[if BLOCK]><![endif]--><?php if(isset($resumenTransacciones['fecha_jornada'])): ?>
                                - Jornada: <?php echo e($resumenTransacciones['fecha_jornada']); ?>

                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </p>
                    </div>
                </div>
                <div class="flex space-x-3">
                    <!--[if BLOCK]><![endif]--><?php if($cierreProcesado): ?>
                        <span class="px-3 py-2 text-sm font-semibold text-green-800 bg-green-100 rounded-lg">
                            ✅ Caja Cerrada
                        </span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </div>
            </div>
        </div>

        <!--[if BLOCK]><![endif]--><?php if(!$cajaActual): ?>
            <!-- No hay caja abierta -->
            <div class="p-8 text-center border border-red-200 bg-red-50 rounded-2xl">
                <svg class="w-16 h-16 mx-auto mb-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                </svg>
                <h2 class="mb-2 text-xl font-bold text-red-800">No hay caja abierta</h2>
                <p class="text-red-600">Debe tener una caja abierta para realizar el cierre.</p>
            </div>
        <?php else: ?>
            <!-- Mensajes -->
            <!--[if BLOCK]><![endif]--><?php if($mensajeExito): ?>
                <div class="p-4 mb-6 border border-green-200 bg-green-50 rounded-2xl" x-data="{ show: true }" x-show="show">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <p class="text-sm font-medium text-green-800"><?php echo e($mensajeExito); ?></p>
                        </div>
                        <button @click="show = false; $wire.limpiarMensajes()" class="text-green-600 hover:text-green-800">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($mensajeError): ?>
                <div class="p-4 mb-6 border border-red-200 bg-red-50 rounded-2xl" x-data="{ show: true }" x-show="show">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <p class="text-sm font-medium text-red-800"><?php echo e($mensajeError); ?></p>
                        </div>
                        <button @click="show = false; $wire.limpiarMensajes()" class="text-red-600 hover:text-red-800">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="grid grid-cols-1 gap-6 xl:grid-cols-3">
                <!-- Resumen del día -->
                <div class="xl:col-span-1">
                    <div class="p-6 mb-6 bg-white border border-gray-200 shadow-lg rounded-2xl">
                        <h2 class="flex items-center mb-4 text-lg font-semibold text-gray-800">
                            <svg class="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                            </svg>
                            Resumen del Día
                        </h2>

                        <div class="space-y-4">
                            <div class="p-4 border border-orange-200 rounded-lg bg-orange-50">
                                <div class="flex items-center justify-between">
                                    <span class="text-sm font-medium text-orange-800">💰 Saldo Inicial:</span>
                                    <span class="text-lg font-bold text-orange-600">
                                        L.<?php echo e(number_format($resumenTransacciones['saldo_inicial'] ?? 0, 2)); ?>

                                    </span>
                                </div>
                            </div>

                            <div class="p-4 border border-blue-200 rounded-lg bg-blue-50">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm font-medium text-blue-800">Balance Sistema:</span>
                                    <span class="text-lg font-bold text-blue-600">
                                        L.<?php echo e(number_format($totalSistema, 2)); ?>

                                    </span>
                                </div>
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm font-medium text-blue-800">Transacciones:</span>
                                    <span class="text-sm text-blue-600">
                                        <?php echo e($resumenTransacciones['transacciones'] ?? 0); ?>

                                    </span>
                                </div>
                            </div>

                            <div class="p-4 border border-green-200 rounded-lg bg-green-50">
                                <h3 class="mb-3 text-sm font-semibold text-green-800">💰 Efectivo</h3>

                                <!-- Desglose de Entradas - Mostrar siempre, aunque esté vacío -->
                                <div class="mb-3">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="text-xs font-medium text-green-700">📊 Desglose Entradas:</span>
                                        <button class="text-xs text-green-600 hover:text-green-800"
                                                x-data="{ show: false }"
                                                @click="show = !show">
                                            <span x-text="show ? 'Ocultar' : 'Ver detalles'"></span>
                                        </button>
                                    </div>

                                    <div x-data="{ show: false }" class="space-y-1">
                                        <div @click="show = !show" class="cursor-pointer">
                                            <div class="flex justify-between p-2 text-xs bg-white border border-green-100 rounded">
                                                <span class="text-green-700">Total Entradas:</span>
                                                <div class="flex items-center">
                                                    <span class="font-medium text-green-800">L.<?php echo e(number_format($resumenTransacciones['efectivo_entrada'] ?? 0, 2)); ?></span>
                                                    <svg class="w-3 h-3 ml-1 text-green-600" :class="{ 'rotate-180': show }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>

                                        <div x-show="show" x-collapse>
                                            <div class="ml-2 space-y-1">
                                                <!--[if BLOCK]><![endif]--><?php if(count($desglose_entradas) > 0): ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $desglose_entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="flex justify-between px-2 py-1 text-xs border-l-2 border-green-300 rounded bg-green-25">
                                                            <span class="text-green-600"><?php echo e($entrada['tipo']); ?> (<?php echo e($entrada['cantidad']); ?>)</span>
                                                            <span class="font-medium text-green-700">L.<?php echo e(number_format($entrada['total'], 2)); ?></span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php else: ?>
                                                    <div class="px-2 py-1 text-xs text-green-600 border-l-2 border-green-300 rounded bg-green-25">
                                                        No hay entradas registradas
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="space-y-1 text-sm">
                                    <div class="flex justify-between">
                                        <span class="text-green-700">Entradas:</span>
                                        <span class="font-medium">L.<?php echo e(number_format($resumenTransacciones['efectivo_entrada'] ?? 0, 2)); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-green-700">Salidas:</span>
                                        <span class="font-medium">L.<?php echo e(number_format($resumenTransacciones['efectivo_salida'] ?? 0, 2)); ?></span>
                                    </div>
                                    <div class="flex justify-between pt-1 border-t">
                                        <span class="font-semibold text-green-800">Neto:</span>
                                        <span class="font-bold">L.<?php echo e(number_format($resumenTransacciones['efectivo_neto'] ?? 0, 2)); ?></span>
                                    </div>
                                </div>
                            </div>

                            <!-- Otros Métodos de Pago - DESGLOSADOS -->
                            <div class="p-4 border border-purple-200 rounded-lg bg-purple-50">
                                <h3 class="mb-3 text-sm font-semibold text-purple-800">💳 Otros Métodos de Pago</h3>
                                
                                <!-- Desglose de Tarjetas -->
                                <div class="mb-3">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="text-xs font-medium text-purple-700">💳 Tarjetas:</span>
                                        <button class="text-xs text-purple-600 hover:text-purple-800"
                                                x-data="{ show: false }"
                                                @click="show = !show">
                                            <span x-text="show ? 'Ocultar' : 'Ver detalles'"></span>
                                        </button>
                                    </div>

                                    <div x-data="{ show: false }" class="space-y-1">
                                        <div @click="show = !show" class="cursor-pointer">
                                            <div class="flex justify-between p-2 text-xs bg-white border border-purple-100 rounded">
                                                <span class="text-purple-700">Total Tarjetas:</span>
                                                <div class="flex items-center">
                                                    <span class="font-medium text-purple-800">L.<?php echo e(number_format($resumenTransacciones['tarjeta'] ?? 0, 2)); ?></span>
                                                    <svg class="w-3 h-3 ml-1 text-purple-600" :class="{ 'rotate-180': show }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>

                                        <div x-show="show" x-collapse>
                                            <div class="ml-2 space-y-1">
                                                <!--[if BLOCK]><![endif]--><?php if(isset($desgloseTarjetas) && count($desgloseTarjetas) > 0): ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $desgloseTarjetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarjeta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="flex justify-between px-2 py-1 text-xs border-l-2 border-purple-300 rounded bg-purple-25">
                                                            <span class="text-purple-600"><?php echo e($tarjeta->metodo_pago ?? 'Tarjeta'); ?> (<?php echo e($tarjeta->cantidad_transacciones ?? 1); ?>)</span>
                                                            <span class="font-medium text-purple-700">L.<?php echo e(number_format($tarjeta->total_pagado ?? 0, 2)); ?></span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php else: ?>
                                                    <div class="px-2 py-1 text-xs text-purple-600 border-l-2 border-purple-300 rounded bg-purple-25">
                                                        No hay transacciones con tarjeta registradas
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Desglose de Transferencias -->
                                <div class="mb-3">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="text-xs font-medium text-purple-700">🏦 Transferencias:</span>
                                        <button class="text-xs text-purple-600 hover:text-purple-800"
                                                x-data="{ show: false }"
                                                @click="show = !show">
                                            <span x-text="show ? 'Ocultar' : 'Ver detalles'"></span>
                                        </button>
                                    </div>

                                    <div x-data="{ show: false }" class="space-y-1">
                                        <div @click="show = !show" class="cursor-pointer">
                                            <div class="flex justify-between p-2 text-xs bg-white border border-purple-100 rounded">
                                                <span class="text-purple-700">Total Transferencias:</span>
                                                <div class="flex items-center">
                                                    <span class="font-medium text-purple-800">L.<?php echo e(number_format($resumenTransacciones['transferencia'] ?? 0, 2)); ?></span>
                                                    <svg class="w-3 h-3 ml-1 text-purple-600" :class="{ 'rotate-180': show }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>

                                        <div x-show="show" x-collapse>
                                            <div class="ml-2 space-y-1">
                                                <!--[if BLOCK]><![endif]--><?php if(isset($desgloseTransferencias) && count($desgloseTransferencias) > 0): ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $desgloseTransferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transferencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="flex justify-between px-2 py-1 text-xs border-l-2 border-purple-300 rounded bg-purple-25">
                                                            <span class="text-purple-600"><?php echo e($transferencia->metodo_pago ?? 'Transferencia'); ?> (<?php echo e($transferencia->cantidad_transacciones ?? 1); ?>)</span>
                                                            <span class="font-medium text-purple-700">L.<?php echo e(number_format($transferencia->total_pagado ?? 0, 2)); ?></span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php else: ?>
                                                    <div class="px-2 py-1 text-xs text-purple-600 border-l-2 border-purple-300 rounded bg-purple-25">
                                                        No hay transferencias registradas
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Desglose de Cheques -->
                                <div class="mb-3">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="text-xs font-medium text-purple-700">🏦 Cheques:</span>
                                        <button class="text-xs text-purple-600 hover:text-purple-800"
                                                x-data="{ show: false }"
                                                @click="show = !show">
                                            <span x-text="show ? 'Ocultar' : 'Ver detalles'"></span>
                                        </button>
                                    </div>

                                    <div x-data="{ show: false }" class="space-y-1">
                                        <div @click="show = !show" class="cursor-pointer">
                                            <div class="flex justify-between p-2 text-xs bg-white border border-purple-100 rounded">
                                                <span class="text-purple-700">Total Cheques:</span>
                                                <div class="flex items-center">
                                                    <span class="font-medium text-purple-800">L.<?php echo e(number_format($resumenTransacciones['cheque'] ?? 0, 2)); ?></span>
                                                    <svg class="w-3 h-3 ml-1 text-purple-600" :class="{ 'rotate-180': show }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>

                                        <div x-show="show" x-collapse>
                                            <div class="ml-2 space-y-1">
                                                <!--[if BLOCK]><![endif]--><?php if(isset($desgloseCheques) && count($desgloseCheques) > 0): ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $desgloseCheques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cheque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="flex justify-between px-2 py-1 text-xs border-l-2 border-purple-300 rounded bg-purple-25">
                                                            <span class="text-purple-600"><?php echo e($cheque->metodo_pago ?? 'Cheque'); ?> (<?php echo e($cheque->cantidad_transacciones ?? 1); ?>)</span>
                                                            <span class="font-medium text-purple-700">L.<?php echo e(number_format($cheque->total_pagado ?? 0, 2)); ?></span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php else: ?>
                                                    <div class="px-2 py-1 text-xs text-purple-600 border-l-2 border-purple-300 rounded bg-purple-25">
                                                        No hay cheques registrados
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Resumen de Otros Pagos -->
                                <div class="space-y-1 text-sm border-t border-purple-200 pt-2">
                                    <div class="flex justify-between">
                                        <span class="text-purple-700">Tarjetas:</span>
                                        <span class="font-medium">L.<?php echo e(number_format($resumenTransacciones['tarjeta'] ?? 0, 2)); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-purple-700">Transferencias:</span>
                                        <span class="font-medium">L.<?php echo e(number_format($resumenTransacciones['transferencia'] ?? 0, 2)); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-purple-700">Cheques:</span>
                                        <span class="font-medium">L.<?php echo e(number_format($resumenTransacciones['cheque'] ?? 0, 2)); ?></span>
                                    </div>
                                    <div class="flex justify-between pt-1 border-t">
                                        <span class="font-semibold text-purple-800">Total Otros:</span>
                                        <span class="font-bold">L.<?php echo e(number_format(($resumenTransacciones['tarjeta'] ?? 0) + ($resumenTransacciones['transferencia'] ?? 0) + ($resumenTransacciones['cheque'] ?? 0), 2)); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Comparación -->
                    <div class="p-6 bg-white border border-gray-200 shadow-lg rounded-2xl">
                        <h2 class="flex items-center mb-4 text-lg font-semibold text-gray-800">
                            <svg class="w-5 h-5 mr-2 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                            </svg>
                            Comparación
                        </h2>

                        <div class="space-y-3">
                            <div class="flex items-center justify-between p-3 rounded-lg bg-blue-50">
                                <span class="text-sm font-medium text-blue-800">Sistema:</span>
                                <span class="text-lg font-bold text-blue-600">L.<?php echo e(number_format($totalSistema, 2)); ?></span>
                            </div>
                            <div class="flex items-center justify-between p-3 rounded-lg bg-green-50">
                                <span class="text-sm font-medium text-green-800">Contado:</span>
                                <span class="text-lg font-bold text-green-600">L.<?php echo e(number_format($totalContado, 2)); ?></span>
                            </div>
                            <div class="flex justify-between items-center p-3 rounded-lg <?php echo e($diferenciaEfectivo == 0 ? 'bg-green-50' : ($diferenciaEfectivo > 0 ? 'bg-yellow-50' : 'bg-red-50')); ?>">
                                <span class="text-sm font-medium <?php echo e($diferenciaEfectivo == 0 ? 'text-green-800' : ($diferenciaEfectivo > 0 ? 'text-yellow-800' : 'text-red-800')); ?>">Diferencia:</span>
                                <span class="text-lg font-bold <?php echo e($diferenciaEfectivo == 0 ? 'text-green-600' : ($diferenciaEfectivo > 0 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                    <?php echo e($diferenciaEfectivo >= 0 ? '+' : ''); ?>L.<?php echo e(number_format($diferenciaEfectivo, 2)); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Conteo de Billetes y Monedas -->
                <div class="xl:col-span-2">
                    <div class="p-6 bg-white border border-gray-200 shadow-lg rounded-2xl">
                        <h2 class="flex items-center mb-6 text-lg font-semibold text-gray-800">
                            <svg class="w-5 h-5 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                            </svg>
                            Conteo de Efectivo
                        </h2>

                        <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
                            <!-- Billetes -->
                            <div class="space-y-4">
                                <h3 class="flex items-center text-lg font-semibold text-gray-700">
                                    <span class="mr-2 text-2xl">💵</span>
                                    Billetes
                                </h3>

                                <?php
                                    $billetes = [
                                        ['value' => 500, 'label' => 'L.500', 'model' => 'billetes_500'],
                                        ['value' => 200, 'label' => 'L.200', 'model' => 'billetes_200'],
                                        ['value' => 100, 'label' => 'L.100', 'model' => 'billetes_100'],
                                        ['value' => 50, 'label' => 'L.50', 'model' => 'billetes_50'],
                                        ['value' => 20, 'label' => 'L.20', 'model' => 'billetes_20'],
                                        ['value' => 10, 'label' => 'L.10', 'model' => 'billetes_10'],
                                        ['value' => 5, 'label' => 'L.5', 'model' => 'billetes_5'],
                                        ['value' => 2, 'label' => 'L.2', 'model' => 'billetes_2'],
                                        ['value' => 1, 'label' => 'L.1', 'model' => 'billetes_1']
                                    ]
                                ?>

                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $billetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center p-3 space-x-3 rounded-lg bg-green-50">
                                        <div class="w-16 text-sm font-semibold text-green-800"><?php echo e($billete['label']); ?></div>
                                        <div class="text-gray-600">×</div>
                                        <input wire:model.live="<?php echo e($billete['model']); ?>"
                                               type="number"
                                               min="0"
                                               value="<?php echo e($this->{$billete['model']} ?? 0); ?>"
                                               placeholder="0"
                                               <?php if($cierreProcesado): ?> disabled <?php endif; ?>
                                               class="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center font-semibold <?php echo e($cierreProcesado ? 'bg-gray-100' : 'focus:ring-2 focus:ring-green-500 focus:border-green-500'); ?>">
                                        <div class="text-gray-600">=</div>
                                        <div class="text-right font-bold text-green-600 min-w-[80px]">
                                            L.<?php echo e(number_format(is_numeric($this->{$billete['model']}) ? ($this->{$billete['model']} * $billete['value']) : 0, 2)); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!-- Monedas -->
                            <div class="space-y-4">
                                <h3 class="flex items-center text-lg font-semibold text-gray-700">
                                    <span class="mr-2 text-2xl">🪙</span>
                                    Monedas
                                </h3>

                                <?php
                                    $monedas = [
                                        ['value' => 0.50, 'label' => '50¢', 'model' => 'monedas_0_50'],
                                        ['value' => 0.20, 'label' => '20¢', 'model' => 'monedas_0_20'],
                                        ['value' => 0.10, 'label' => '10¢', 'model' => 'monedas_0_10'],
                                        ['value' => 0.05, 'label' => '5¢', 'model' => 'monedas_0_05'],
                                        ['value' => 0.02, 'label' => '2¢', 'model' => 'monedas_0_02'],
                                        ['value' => 0.01, 'label' => '1¢', 'model' => 'monedas_0_01']
                                    ]
                                ?>

                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center p-3 space-x-3 rounded-lg bg-yellow-50">
                                        <div class="w-16 text-sm font-semibold text-yellow-800"><?php echo e($moneda['label']); ?></div>
                                        <div class="text-gray-600">×</div>
                                        <input wire:model.live="<?php echo e($moneda['model']); ?>"
                                               type="number"
                                               min="0"
                                               value="<?php echo e($this->{$moneda['model']} ?? 0); ?>"
                                               placeholder="0"
                                               <?php if($cierreProcesado): ?> disabled <?php endif; ?>
                                               class="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center font-semibold <?php echo e($cierreProcesado ? 'bg-gray-100' : 'focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500'); ?>">
                                        <div class="text-gray-600">=</div>
                                        <div class="text-right font-bold text-yellow-600 min-w-[80px]">
                                            L.<?php echo e(number_format(is_numeric($this->{$moneda['model']}) ? ($this->{$moneda['model']} * $moneda['value']) : 0, 2)); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                <!-- Espaciador para centrar -->
                                <div class="space-y-4">
                                    <div class="h-8"></div>
                                    <div class="h-8"></div>
                                    <div class="h-8"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Botón de Cierre -->
                        <!--[if BLOCK]><![endif]--><?php if(!$cierreProcesado): ?>
                            <div class="pt-6 mt-8 border-t border-gray-200">
                                <button wire:click="procesarCierre"
                                        class="flex items-center justify-center w-full px-6 py-4 space-x-2 font-bold text-white transition-colors duration-200 bg-purple-600 rounded-lg hover:bg-purple-700">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span>Procesar Cierre de Caja</span>
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="pt-6 mt-8 text-center border-t border-gray-200">
                                <div class="inline-flex items-center px-6 py-3 space-x-2 font-semibold text-green-800 bg-green-100 rounded-lg">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span>Cierre de Caja Completado</span>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/caja/cierre-de-caja.blade.php ENDPATH**/ ?>