<div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

    <!-- ENCABEZADO CON TEMA -->
    <div
        class="flex items-center justify-between px-4 py-2 font-semibold text-white"
        :class="{
            'bg-emerald-600': theme === 'verde',
            'bg-blue-600': theme === 'azul',
            'bg-gray-900': theme === 'oscuro',
            'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
        }"
    >
        <h5 class="mb-0">Gestión de Usuarios</h5>
        <button
            x-on:click="$dispatch('cambiarVista', { ruta: 'Configuracion.Usuariosform' })"
            class="px-3 py-1 text-sm text-gray-800 no-underline bg-white rounded hover:bg-gray-100"
        >
            ➕ Agregar Usuario
        </button>
    </div>

    <!-- TABLA DE USUARIOS -->
    <div class="overflow-x-auto bg-white">
        <table class="min-w-full text-sm text-left border border-gray-300">
            <thead class="bg-gray-100 border-b border-gray-300">
                <tr class="text-xs font-semibold text-gray-700 uppercase">
                    <th class="px-4 py-2 border">NOMBRE</th>
                    <th class="px-4 py-2 border">CORREO</th>
                    <th class="px-4 py-2 border">DIRECCIÓN</th>
                    <th class="px-4 py-2 border">TELÉFONO</th>
                    <th class="px-4 py-2 border">ROL</th>
                    <th class="px-4 py-2 border">ESTADO</th>
                </tr>
            </thead>
            <tbody class="text-sm text-gray-800 bg-white divide-y divide-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr
                        wire:click="editar(<?php echo e($usuario->id); ?>)"
                        class="transition cursor-pointer hover:bg-gray-100"
                    >
                        <td class="px-4 py-2 border-t"><?php echo e($usuario->nombre); ?></td>
                        <td class="px-4 py-2 border-t"><?php echo e($usuario->correo); ?></td>
                        <td class="px-4 py-2 border-t"><?php echo e($usuario->direccion); ?></td>
                        <td class="px-4 py-2 border-t"><?php echo e($usuario->telefono); ?></td>
                        <td class="px-4 py-2 border-t"><?php echo e($usuario->rol); ?></td>
                        <td class="px-4 py-2 text-center border-t">
                            <!--[if BLOCK]><![endif]--><?php if($usuario->estado_id == 1): ?>
                                <span class="inline-block px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">Activo</span>
                            <?php else: ?>
                                <span class="inline-block px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">Inactivo</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-4 py-4 italic text-center text-gray-500">
                            No hay usuarios registrados.
                        </td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <!-- MENSAJE DE ÉXITO -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('mensaje')): ?>
        <div class="p-3 mt-4 text-green-700 bg-green-100 border border-green-400 rounded">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/configuracion/usuarios.blade.php ENDPATH**/ ?>