<div> 

    
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 mb-4 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">Gestión de Bodegas</h5>
            <button wire:click="crearNuevaBodega"
                class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                <span>➕</span> Nueva Bodega
            </button>
        </div>

        <!-- MENSAJES FLASH -->
        <div class="px-4">
            <!--[if BLOCK]><![endif]--><?php if(session('message')): ?>
                <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                    <i class="fas fa-info-circle me-2"></i><?php echo e(session('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i><?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <!-- CONTENIDO -->
        <div class="px-4 py-3 pt-0 card-body">
            <!-- Información de filtro por tienda del usuario -->
            <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                <!--[if BLOCK]><![endif]--><?php if(Auth::user()->tienda_id): ?>
                    <div class="mb-3 alert alert-info border-left-info">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle me-2"></i>
                            <div>
                                <strong>Vista filtrada:</strong> Solo se muestran las bodegas de tu tienda asignada
                                <?php if(Auth::user()->tienda): ?>
                                    <em>"<?php echo e(Auth::user()->tienda->denominacion_social); ?>"</em>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="mb-3 alert alert-warning">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <div>
                                <strong>Sin tienda asignada:</strong> No tienes una tienda asignada. Contacta al administrador para asignar una tienda a tu usuario.
                            </div>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- Barra de búsqueda y filtros -->
            <div class="mb-4 row">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text"
                               class="form-control"
                               placeholder="Buscar por nombre de bodega..."
                               wire:model.live="busqueda">
                    </div>
                </div>
                <div class="col-md-2">
                    <select class="form-select" wire:model.live="filtroTienda">
                        <option value="">Todas las tiendas</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tienda->id); ?>"><?php echo e($tienda->denominacion_social); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
                <div class="col-md-2">
                    <select class="form-select" wire:model.live="filtroTipo">
                        <option value="">Todos los tipos</option>
                        <option value="1">Principal</option>
                        <option value="0">Secundaria</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select class="form-select" wire:model.live="filtroEstado">
                        <option value="">Todos los estados</option>
                        <option value="1">Activas</option>
                        <option value="2">Inactivas</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button wire:click="limpiarFiltros" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-broom me-1"></i>Limpiar
                    </button>
                </div>
            </div>

        <!-- Tarjetas de bodegas -->
        <div class="row">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-4 col-md-4" wire:key="bodega-<?php echo e($bodega->id); ?>">
                    <div class="shadow-sm card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 card-title">
                                <i class="fas fa-warehouse me-2"></i><?php echo e($bodega->nombre); ?>

                                <!--[if BLOCK]><![endif]--><?php if($bodega->principal == 1): ?>
                                    <span class="badge bg-primary ms-2">
                                        <i class="fas fa-star me-1"></i>Principal
                                    </span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </h5>
                            <span class="badge <?php echo e($bodega->estado_id == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                                <?php echo e($bodega->estado_id == 1 ? 'Activa' : 'Inactiva'); ?>

                            </span>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <strong>Dirección:</strong> <?php echo e($bodega->direccion->domicilio_tributario ?? 'N/A'); ?><br>
                                <strong>Tienda asignada:</strong>
                                <!--[if BLOCK]><![endif]--><?php if($bodega->tienda): ?>
                                    <?php echo e($bodega->tienda->denominacion_social); ?>

                                <?php else: ?>
                                    <span class="text-muted">Sin tienda asignada</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]--><br>
                                <strong>Segmentos:</strong> <?php echo e($bodega->segmentos->count()); ?><br>
                                <strong>Secciones totales:</strong> <?php echo e($bodega->segmentos->sum(fn($s) => $s->secciones->count())); ?>

                            </p>
                        </div>
                        <div class="card-footer">
                            <div class="btn-group w-100" role="group">
                                <button wire:click="editarBodega(<?php echo e($bodega->id); ?>)"
                                        class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-edit"></i> Editar
                                </button>
                                <button wire:click="verSegmentos(<?php echo e($bodega->id); ?>)"
                                        class="btn btn-outline-info btn-sm">
                                    <i class="fas fa-layer-group"></i> Segmentos
                                </button>
                                <!--[if BLOCK]><![endif]--><?php if($bodega->estado_id == 1): ?>
                                    <button wire:click="inactivarBodega(<?php echo e($bodega->id); ?>)"
                                            class="btn btn-outline-secondary btn-sm">
                                        <i class="fas fa-pause"></i> Inactivar
                                    </button>
                                <?php else: ?>
                                    <button wire:click="activarBodega(<?php echo e($bodega->id); ?>)"
                                            class="btn btn-outline-success btn-sm">
                                        <i class="fas fa-play"></i> Activar
                                    </button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="text-center alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        No se encontraron bodegas con los criterios de búsqueda especificados.
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <!-- Paginación -->
        <!--[if BLOCK]><![endif]--><?php if($bodegas->hasPages()): ?>
            <div class="mt-3 d-flex justify-content-center">
                <?php echo e($bodegas->links()); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div> 
    </div> 

    <!-- Modal Confirmar Inactivación -->
    <div wire:key="modal-confirmar-inactivar">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($mostrarModalInactivar): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cancelarInactivar()"
        >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-secondary text-white">
                        <h5 class="modal-title">¿Inactivar Bodega?</h5>
                    </div>
                    <div class="modal-body">
                        <!--[if BLOCK]><![endif]--><?php if($bodegaAInactivar): ?>
                            <div class="mb-3">
                                <h6 class="text-secondary">🔸 Esta acción puede revertirse posteriormente</h6>
                                <p>¿Está seguro que desea inactivar la bodega <strong>"<?php echo e($bodegaAInactivar->nombre); ?>"</strong>?</p>

                                <div class="alert alert-secondary">
                                    <small><strong>Se inactivarán automáticamente:</strong></small>
                                    <ul class="mb-0 small">
                                        <li>• Todas las secciones asociadas a los segmentos</li>
                                        <li>• La bodega quedará inactiva (no se eliminará)</li>
                                    </ul>
                                    <div class="mt-2">
                                        <small class="text-muted"><em>Nota: Los segmentos se mantienen para posible reactivación futura.</em></small>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="flex justify-end gap-2 mt-4">
                            <button type="button" class="btn btn-light" wire:click="cancelarInactivar">Cancelar</button>
                            <button type="button" class="btn btn-secondary" wire:click="confirmarInactivacion">Sí, Inactivar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Confirmar Activación -->
    <div wire:key="modal-confirmar-activar">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($mostrarModalActivar): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cancelarActivar()"
        >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title">¿Activar Bodega?</h5>
                    </div>
                    <div class="modal-body">
                        <!--[if BLOCK]><![endif]--><?php if($bodegaAActivar): ?>
                            <div class="mb-3">
                                <h6 class="text-success">✅ Esta acción reactivará la bodega</h6>
                                <p>¿Está seguro que desea activar la bodega <strong>"<?php echo e($bodegaAActivar->nombre); ?>"</strong>?</p>

                                <div class="alert alert-success">
                                    <small><strong>Se activarán automáticamente:</strong></small>
                                    <ul class="mb-0 small">
                                        <li>• Todas las secciones asociadas a los segmentos</li>
                                        <li>• La bodega volverá a estar disponible</li>
                                    </ul>
                                    <div class="mt-2">
                                        <small class="text-muted"><em>Nota: La bodega y sus secciones estarán operativas nuevamente.</em></small>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="flex justify-end gap-2 mt-4">
                            <button type="button" class="btn btn-light" wire:click="cancelarActivar">Cancelar</button>
                            <button type="button" class="btn btn-success" wire:click="confirmarActivacion">Sí, Activar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div> 
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/bodegas.blade.php ENDPATH**/ ?>