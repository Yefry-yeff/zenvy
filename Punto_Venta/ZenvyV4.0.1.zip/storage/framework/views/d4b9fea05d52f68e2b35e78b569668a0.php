<div>
    <!-- Mensaje emergente si el cliente no existe -->
    <!--[if BLOCK]><![endif]--><?php if(session('cliente_no_encontrado')): ?>
        <div class="fixed z-50 px-4 py-2 text-white bg-red-500 rounded shadow-lg top-5 right-5">
            <?php echo e(session('cliente_no_encontrado')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Alertas de descuentos -->
    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show position-fixed"
             style="top: 20px; right: 20px; z-index: 1050; min-width: 300px;">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show position-fixed"
             style="top: 20px; right: 20px; z-index: 1050; min-width: 300px;">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show position-fixed"
             style="top: 20px; right: 20px; z-index: 1050; min-width: 300px;">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo e(session('warning')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de selección de clientes -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalClientesFlag): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         @click.self="$wire.cerrarModalClientes()"
         @keydown.escape.window="$wire.cerrarModalClientes()">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden"
             x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">
            <!-- Header con tema -->
            <div class="flex items-center justify-between px-6 py-4 text-white"
                :class="{
                    'bg-emerald-600': theme === 'verde',
                    'bg-blue-600': theme === 'azul',
                    'bg-gray-900': theme === 'oscuro',
                    'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                }">
                <h2 class="text-lg font-semibold">
                    <i class="fas fa-users me-2"></i>
                    Seleccionar Cliente
                </h2>
                <button wire:click="cerrarModalClientes" class="text-white transition-colors hover:text-gray-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
                <!-- Buscador -->
                <div class="mb-4">
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <i class="text-gray-400 fas fa-search"></i>
                        </div>
                        <input type="text"
                            wire:model.live.debounce.300ms="busquedaCliente"
                            class="w-full py-3 pl-10 pr-4 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-200"
                            placeholder="Buscar cliente por nombre, identidad, RTN o correo...">
                    </div>
                </div>

                <!-- Tabla de clientes -->
                <div class="table-responsive">
                    <table class="table table-sm table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Identidad/RTN</th>
                                <th>Correo</th>
                                <th>Teléfono</th>
                                <th>Tipo Persona</th>
                                <th>Tipo Cliente</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $clientesModal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="align-middle transition-colors cursor-pointer hover:bg-blue-50"
                                    wire:click="seleccionarClienteModal(<?php echo e($cliente_item->id); ?>)"
                                    title="Clic para seleccionar este cliente">
                                    <td><?php echo e($cliente_item->id); ?></td>

                                    <td class="text-start">
                                        <div>
                                            <strong><?php echo e($cliente_item->nombre); ?></strong><br>
                                            <small class="text-muted">
                                                Registrado: <?php echo e($cliente_item->created_at ? $cliente_item->created_at->format('d/m/Y') : 'N/A'); ?>

                                            </small>
                                        </div>
                                    </td>

                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($cliente_item->identidad): ?>
                                            <span class="badge bg-primary"><?php echo e($cliente_item->identidad); ?></span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if(!$cliente_item->identidad): ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <td><?php echo e($cliente_item->correo ?? 'N/A'); ?></td>

                                    <td><?php echo e($cliente_item->telefono ?? 'N/A'); ?></td>

                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($cliente_item->tipoPersona): ?>
                                            <span class="badge bg-info"><?php echo e($cliente_item->tipoPersona->nombre); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($cliente_item->tipoCliente): ?>
                                            <span class="badge bg-warning">
                                                <!--[if BLOCK]><![endif]--><?php if($cliente_item->tipoCliente->id == 1): ?>
                                                    Cliente A
                                                <?php elseif($cliente_item->tipoCliente->id == 2): ?>
                                                    Cliente B
                                                <?php else: ?>
                                                    <?php echo e($cliente_item->tipoCliente->nombre); ?>

                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <td>
                                        <span class="badge <?php echo e($cliente_item->estado_id == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                                            <?php echo e($cliente_item->estado_id == 1 ? 'Activo' : 'Inactivo'); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="py-4 text-center text-muted">
                                        <i class="mb-3 fas fa-users fa-2x"></i><br>
                                        No se encontraron clientes
                                    </td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <!-- Información adicional -->
                <!--[if BLOCK]><![endif]--><?php if(count($clientesModal) > 0): ?>
                    <div class="mt-4 text-center">
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            Mostrando <?php echo e(count($clientesModal)); ?> cliente(s). Haz clic en una fila para seleccionar.
                        </small>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de stock insuficiente -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalSinStock): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         @click.self="$wire.cerrarModalSinStock()"
         @keydown.escape.window="$wire.cerrarModalSinStock()">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-hidden">
            <!-- Header -->
            <div class="flex items-center justify-between px-6 py-4 text-white bg-red-600">
                <h2 class="text-lg font-semibold">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Stock Insuficiente
                </h2>
                <button wire:click="cerrarModalSinStock" class="text-white transition-colors hover:text-gray-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <!-- Content -->
            <div class="p-6">
                <div class="text-center">
                    <div class="mx-auto mb-4 text-red-500">
                        <i class="fas fa-times-circle fa-4x"></i>
                    </div>
                    <h3 class="mb-2 text-lg font-semibold text-gray-800">
                        No hay suficiente stock disponible
                    </h3>
                    <p class="mb-6 text-gray-600">
                        La cantidad solicitada excede el stock disponible en bodega. Por favor, verifica el inventario o reduce la cantidad.
                    </p>
                    
                    <div class="flex justify-center">
                        <button 
                            wire:click="cerrarModalSinStock"
                            class="px-6 py-2 text-white bg-red-600 border border-red-600 rounded-lg hover:bg-red-700 focus:ring-4 focus:ring-red-200">
                            <i class="fas fa-check me-2"></i>
                            Entendido
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- CONTENIDO PRINCIPAL: Siempre visible (modo manual por defecto) -->
    <div class="mx-auto max-w-7xl">
            
            <!-- 1. INFORMACIÓN DEL CLIENTE (arriba, ancho completo) -->
            <div class="mb-6 bg-white border border-gray-300 rounded-lg shadow-lg" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">
                <!-- Header -->
                <div class="flex items-center justify-between px-5 py-3 font-semibold text-white rounded-t"
                    :class="{
                        'bg-emerald-600': theme === 'verde',
                        'bg-blue-600': theme === 'azul',
                        'bg-gray-900': theme === 'oscuro',
                        'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                    }"
                >
                    <h3 class="mb-0 text-lg">
                        <i class="fas fa-user me-2"></i>
                        Información del Cliente
                    </h3>
                </div>

                <!-- Content -->
                <div class="p-4">
                    <!-- ALERTAS DEL CAI -->
                    <!--[if BLOCK]><![endif]--><?php if($alertaCAI): ?>
                        <?php
                            $esCritico = str_contains($alertaCAI, 'CRÍTICO') || str_contains($alertaCAI, 'ERROR');
                            $esAviso = str_contains($alertaCAI, 'AVISO') || str_contains($alertaCAI, 'ATENCIÓN');
                        ?>

                        <div class="alert mb-3 p-3 rounded <?php echo e($esCritico ? 'bg-red-50 border border-red-200' : ($esAviso ? 'bg-yellow-50 border border-yellow-200' : 'bg-blue-50 border border-blue-200')); ?>">
                            <i class="fas <?php echo e($esCritico ? 'fa-times-circle text-red-600' : ($esAviso ? 'fa-exclamation-triangle text-yellow-600' : 'fa-info-circle text-blue-600')); ?>"></i>
                            <span class="<?php echo e($esCritico ? 'text-red-800' : ($esAviso ? 'text-yellow-800' : 'text-blue-800')); ?>">
                                <strong>CAI:</strong> <?php echo e($alertaCAI); ?>

                            </span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Información de bodega y alertas de stock -->
                    <!--[if BLOCK]><![endif]--><?php if($bodegaPrincipal): ?>
                        <div class="alert alert-info d-flex align-items-center mb-3">
                            <div class="me-3">
                                <i class="fas fa-warehouse fa-lg"></i>
                            </div>
                            <div>
                                <strong>Tienda:</strong> <?php echo e($tiendaUsuario); ?><br>
                                <strong>Bodega Principal:</strong> <?php echo e($bodegaPrincipal->nombre); ?>

                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning d-flex align-items-center mb-3">
                            <div class="me-3">
                                <i class="fas fa-exclamation-triangle fa-lg"></i>
                            </div>
                            <div>
                                <strong>Advertencia:</strong> No se encontró bodega principal para su tienda
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="grid grid-cols-1 gap-4">
                        <!-- Primera fila: RTN/Identidad y Nombre -->
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <div class="space-y-1">
                                <label class="block text-sm font-medium text-gray-700">
                                    RTN / Número de Identidad
                                </label>
                                <div class="relative">
                                    <input type="text"
                                        wire:model.live.debounce.500ms="rtnManual"
                                        wire:keydown.enter="buscarClientePorRtn"
                                        class="w-full px-3 py-2 pr-10 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                        placeholder="RTN/Identidad (13-15 dígitos) - Enter para buscar"
                                        maxlength="15"
                                        <?php echo e($camposBloqueados ? 'readonly' : ''); ?>>
                                    <button type="button"
                                        wire:click="mostrarModalClientes"
                                        class="absolute inset-y-0 right-0 flex items-center px-3 text-gray-500 hover:text-blue-600"
                                        title="Buscar cliente">
                                        <!-- Icono de lupa (SVG) -->
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <div class="space-y-1">
                                <label class="block text-sm font-medium text-gray-700">Nombre del Cliente</label>
                                <input type="text"
                                    wire:model="nombreClienteManual"
                                    class="w-full px-3 py-2 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                    placeholder="Ingrese nombre del cliente"
                                    <?php echo e($camposBloqueados ? 'readonly' : ''); ?>>
                            </div>
                        </div>

                        <!-- Segunda fila: Correo y Teléfono -->
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <div class="space-y-1">
                                <label class="block text-sm font-medium text-gray-700">Correo Electrónico</label>
                                <input type="email"
                                    wire:model="correoClienteManual"
                                    class="w-full px-3 py-2 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                    placeholder="correo@ejemplo.com"
                                    <?php echo e($camposBloqueados ? 'readonly' : ''); ?>>
                            </div>

                            <div class="space-y-1" x-data="{ error: false }" 
                                @marcar-campo-error.window="if($event.detail === 'telefonoClienteManual') { error = true; setTimeout(() => error = false, 3000) }">
                                <label class="block text-sm font-medium text-gray-700">Teléfono *</label>
                                <input type="tel"
                                    wire:model="telefonoClienteManual"
                                    :class="error ? 'border-red-500 ring-1 ring-red-200 bg-red-50' : 'border-gray-300'"
                                    class="w-full px-3 py-2 border rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                    placeholder="+504 0000-0000"
                                    <?php echo e($camposBloqueados ? 'readonly' : ''); ?>>
                            </div>
                        </div>

                        <!-- Tercera fila: Dirección -->
                        <div class="space-y-1">
                            <label class="block text-sm font-medium text-gray-700">Dirección</label>
                            <textarea wire:model="direccionClienteManual"
                                class="w-full px-3 py-2 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                rows="2"
                                placeholder="Dirección completa del cliente"
                                <?php echo e($camposBloqueados ? 'readonly' : ''); ?>></textarea>
                        </div>

                        <!-- Cuarta fila: Tipo de Persona y Tipo de Cliente -->
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <div class="space-y-1">
                                <label class="block text-sm font-medium text-gray-700">Tipo de Persona</label>
                                <select wire:model="tipoPersonaId"
                                    class="w-full px-3 py-2 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                    <?php echo e($camposBloqueados ? 'disabled' : ''); ?>>
                                    <option value="">Seleccione tipo de persona</option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tiposPersona; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoPersona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($tipoPersona->id); ?>"><?php echo e($tipoPersona->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="1">Natural</option>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php if($camposBloqueados && isset($tiposPersona)): ?>
                                    <?php
                                        $tipoPersonaSeleccionada = $tiposPersona->firstWhere('id', $tipoPersonaId);
                                    ?>
                                    <!--[if BLOCK]><![endif]--><?php if($tipoPersonaSeleccionada): ?>
                                        <p class="text-sm text-gray-600"><?php echo e($tipoPersonaSeleccionada->nombre); ?></p>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div class="space-y-1">
                                <label class="block text-sm font-medium text-gray-700">Tipo de Cliente</label>
                                <select wire:model="tipoClienteId"
                                    class="w-full px-3 py-2 border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200 <?php echo e($camposBloqueados ? 'bg-gray-100' : ''); ?>"
                                    <?php echo e($camposBloqueados ? 'disabled' : ''); ?>>
                                    <option value="">Seleccione tipo de cliente</option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tiposCliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoCliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($tipoCliente->id); ?>">
                                            <!--[if BLOCK]><![endif]--><?php if($tipoCliente->id == 1): ?>
                                                Cliente A
                                            <?php elseif($tipoCliente->id == 2): ?>
                                                Cliente B
                                            <?php else: ?>
                                                <?php echo e($tipoCliente->nombre); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="1">Cliente A</option>
                                        <option value="2">Cliente B</option>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php if($camposBloqueados && isset($tiposCliente)): ?>
                                    <?php
                                        $tipoClienteSeleccionado = $tiposCliente->firstWhere('id', $tipoClienteId);
                                    ?>
                                    <!--[if BLOCK]><![endif]--><?php if($tipoClienteSeleccionado): ?>
                                        <p class="text-sm text-gray-600">
                                            <!--[if BLOCK]><![endif]--><?php if($tipoClienteSeleccionado->id == 1): ?>
                                                Cliente A
                                            <?php elseif($tipoClienteSeleccionado->id == 2): ?>
                                                Cliente B
                                            <?php else: ?>
                                                <?php echo e($tipoClienteSeleccionado->nombre); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </p>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>

                        <!-- Botones de control -->
                        <div class="flex flex-wrap gap-2">
                            <!--[if BLOCK]><![endif]--><?php if(!$camposBloqueados): ?>
                                <button type="button"
                                    wire:click="guardarClienteManual"
                                    class="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 rounded-lg hover:bg-green-700 focus:ring-4 focus:ring-green-200">
                                    <!-- Icono de check (SVG) -->
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                    </svg>
                                    Guardar Cliente
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            
                            <button type="button"
                                wire:click="limpiarDatosCliente"
                                class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:ring-4 focus:ring-gray-200">
                                <!-- Icono de basura (SVG) -->
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                </svg>
                                Limpiar Datos
                            </button>
                            
                            <!--[if BLOCK]><![endif]--><?php if($camposBloqueados): ?>
                                <div class="inline-flex items-center px-3 py-2 text-sm text-green-700 bg-green-100 border border-green-200 rounded-lg">
                                    <!-- Icono de candado (SVG) -->
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                    </svg>
                                    Datos bloqueados
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. LAYOUT DINÁMICO: FACTURA (ancho completo si no hay catálogo, o 2/3 si hay catálogo) -->
            <div class="grid grid-cols-1 gap-6 <?php echo e($mostrarCatalogoVisual ? 'lg:grid-cols-3' : 'lg:grid-cols-1'); ?>">
                
                <!-- 2.1 FACTURA (ancho completo o 2 columnas según disponibilidad del catálogo) -->
                <div class="<?php echo e($mostrarCatalogoVisual ? 'lg:col-span-2' : 'lg:col-span-1'); ?> bg-white border border-gray-300 rounded-lg shadow-lg" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">
                    <!-- Header -->
                    <div class="flex items-center justify-between px-5 py-3 font-semibold text-white rounded-t"
                        :class="{
                            'bg-emerald-600': theme === 'verde',
                            'bg-blue-600': theme === 'azul',
                            'bg-gray-900': theme === 'oscuro',
                            'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                        }"
                    >
                        <h3 class="mb-0 text-lg">
                            🧾 Facturación
                        </h3>
                    </div>

                    <!-- Content -->
                    <div class="p-4">
                        <!-- Escanear producto -->
                        <div x-data="{
                            init() {
                                this.$el.querySelector('#codigo_barras').focus();
                            }
                        }" class="mb-4">
                            <form wire:submit.prevent="agregarProductoPorCodigo">
                                <div class="mb-4">
                                    <div class="flex-1">
                                        <label for="codigo_barras" class="block mb-1 text-sm font-medium text-gray-700">Escanear código de barras</label>
                                        <input type="text"
                                            id="codigo_barras"
                                            wire:model.defer="codigoBarras"
                                            wire:keydown.enter="agregarProductoPorCodigo"
                                            class="w-full form-control"
                                            placeholder="Escanee el código de barras"
                                            autocomplete="off"
                                            @keydown.enter="$event.target.value = ''; $event.target.focus()"
                                            @enfocar-input-codigo.window="$event.target.focus()"
                                            autofocus>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <!-- Lista de productos agregados a la factura -->
                        <div class="mb-4">
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered text-center" style="font-size: 0.7rem;">
                                    <thead class="table-light">
                                        <tr style="font-size: 0.65rem;">
                                            <th>Producto/Servicio</th>
                                            <th>Código</th>
                                            <th>Tipo</th>
                                            <th>Precio Unit.</th>
                                            <th>Cantidad</th>
                                            <th>Subtotal</th>
                                            <th>ISV</th>
                                            <th>Total</th>
                                            <th>Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody style="font-size: 0.65rem;" class="text-center">
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $productosFactura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            // Cálculo base: cantidad × precio unitario
                                            $subtotalOriginal = $item['precio'] * $item['cantidad'];
                                            
                                            // Descuentos aplicados
                                            $descuentoAplicado = $item['descuento_aplicado'] ?? 0; // Descuento por edad (total)
                                            $descuentoUnitarioBase = $item['descuento_unitario_producto'] ?? 0; // Descuento por unidad base
                                            $descuentoIndividual = $item['descuento_monto'] ?? 0; // Descuento individual por producto
                                            
                                            // El descuento unitario se aplica POR CADA CANTIDAD
                                            $descuentoUnitarioTotal = $descuentoUnitarioBase * $item['cantidad'];
                                            
                                            // Subtotal después de todos los descuentos
                                            $subtotalConDescuento = $subtotalOriginal - $descuentoUnitarioTotal - $descuentoIndividual - $descuentoAplicado;
                                            
                                            // ISV se calcula sobre el subtotal neto (después de descuentos)
                                            $isv = $subtotalConDescuento * ($item['isv']/100);
                                            
                                            // Total final: subtotal neto + ISV
                                            $total = $subtotalConDescuento + $isv;
                                            
                                            // Determinar si es producto o servicio
                                            $esServicio = isset($item['servicio_id']) && $item['servicio_id'] !== null;
                                            $stockDisponible = $esServicio ? null : $this->obtenerStockDisponible($item['id']);
                                        ?>
                                        <tr class="<?php echo e($esServicio ? 'table-info' : ''); ?>" wire:key="item-<?php echo e($loop->index); ?>-<?php echo e($item['cantidad']); ?>">
                                            <td>
                                                <?php echo e($item['nombre']); ?>

                                                <!--[if BLOCK]><![endif]--><?php if(!$esServicio): ?>
                                                    <br>
                                                    <small class="text-gray-500">
                                                        Stock disponible: <?php echo e($stockDisponible); ?>

                                                    </small>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td><?php echo e($item['codigo']); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($esServicio): ?>
                                                    <span class="badge bg-info text-white">
                                                        <i class="fas fa-concierge-bell me-1"></i>
                                                        Servicio
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-primary text-white">
                                                        <i class="fas fa-box me-1"></i>
                                                        Producto
                                                    </span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($esServicio): ?>
                                                    L. <?php echo e(number_format($item['precio'], 2)); ?>

                                                <?php else: ?>
                                                    <!-- Dropdown para seleccionar precio -->
                                                    <select class="form-select form-select-sm" 
                                                            style="min-width: 120px; font-size: 0.875rem;"
                                                            wire:change="cambiarPrecioProducto(<?php echo e($loop->index); ?>, $event.target.value)">
                                                        
                                                        <?php
                                                            $precios = [];
                                                            
                                                            // Si es producto de Paperland (producto_valencia = 0)
                                                            if (($item['producto_valencia'] ?? 1) == 0) {
                                                                $precios['precio_base'] = $item['precio_base'] ?? 0;
                                                            } else {
                                                                // Productos de Valencia: agregar precios 1-4 disponibles
                                                                if (($item['precio1'] ?? 0) > 0) $precios['precio1'] = $item['precio1'];
                                                                if (($item['precio2'] ?? 0) > 0) $precios['precio2'] = $item['precio2'];
                                                                if (($item['precio3'] ?? 0) > 0) $precios['precio3'] = $item['precio3'];
                                                                if (($item['precio4'] ?? 0) > 0) $precios['precio4'] = $item['precio4'];
                                                                
                                                                // Siempre agregar precio_base como opción
                                                                $precios['precio_base'] = $item['precio_base'] ?? 0;
                                                            }
                                                            
                                                            $tipoPrecioActual = $item['tipo_precio'] ?? 'precio_base';
                                                        ?>
                                                        
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $precios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo => $precio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($tipo); ?>" 
                                                                    <?php echo e($tipoPrecioActual == $tipo ? 'selected' : ''); ?>>
                                                                <?php
                                                                    $nombrePrecio = $tipo;
                                                                    switch($tipo) {
                                                                        case 'precio1':
                                                                            $nombrePrecio = 'Precio A';
                                                                            break;
                                                                        case 'precio2':
                                                                            $nombrePrecio = 'Precio B';
                                                                            break;
                                                                        case 'precio3':
                                                                            $nombrePrecio = 'Precio C';
                                                                            break;
                                                                        case 'precio4':
                                                                            $nombrePrecio = 'Precio D';
                                                                            break;
                                                                        case 'precio_base':
                                                                            $nombrePrecio = 'Precio Base';
                                                                            break;
                                                                    }
                                                                ?>
                                                                <?php echo e($nombrePrecio); ?>: L. <?php echo e(number_format($precio, 2)); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </select>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($esServicio): ?>
                                                    <!-- Para servicios, cantidad editable sin restricción de stock -->
                                                    <input type="number"
                                                        wire:key="servicio-<?php echo e($loop->index); ?>-<?php echo e($item['cantidad']); ?>"
                                                        wire:change="modificarCantidad(<?php echo e($loop->index); ?>, $event.target.value)"
                                                        value="<?php echo e($item['cantidad']); ?>"
                                                        min="1"
                                                        class="w-20 text-center form-control"
                                                        style="min-width: 60px;">
                                                <?php else: ?>
                                                    <!-- Para productos, cantidad limitada por stock -->
                                                    <input type="number"
                                                        wire:key="producto-<?php echo e($loop->index); ?>-<?php echo e($item['cantidad']); ?>"
                                                        wire:change="modificarCantidad(<?php echo e($loop->index); ?>, $event.target.value)"
                                                        value="<?php echo e($item['cantidad']); ?>"
                                                        min="1"
                                                        max="<?php echo e($stockDisponible); ?>"
                                                        class="w-20 text-center form-control"
                                                        style="min-width: 60px;"
                                                        title="Stock disponible: <?php echo e($stockDisponible); ?>">
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <!-- Mostrar importe original (precio × cantidad SIN descuentos) -->
                                                <div class="fw-bold">L. <?php echo e(number_format($subtotalOriginal, 2)); ?></div>
                                                
                                                <!-- Mostrar descuentos de productos/servicios guardados primero (si existen) -->
                                                <!--[if BLOCK]><![endif]--><?php if($esServicio && isset($descuentosGuardados[$item['servicio_id']])): ?>
                                                    <div class="text-danger small fw-bold">-L. <?php echo e(number_format($descuentosGuardados[$item['servicio_id']]['monto_total'], 2)); ?></div>
                                                <?php elseif(!$esServicio && isset($descuentosGuardados[$item['id']])): ?>
                                                    <div class="text-danger small fw-bold">-L. <?php echo e(number_format($descuentosGuardados[$item['id']]['monto_total'], 2)); ?></div>
                                                <?php elseif($descuentoUnitarioTotal > 0): ?>
                                                    <!-- Mostrar solo el total del descuento unitario en rojo -->
                                                    <div class="text-danger small fw-bold">-L. <?php echo e(number_format($descuentoUnitarioTotal, 2)); ?></div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                
                                                <!-- Mostrar descuento individual por producto (si existe) -->
                                                <!--[if BLOCK]><![endif]--><?php if($descuentoIndividual > 0): ?>
                                                    <div class="text-warning small fw-bold">
                                                        -L. <?php echo e(number_format($descuentoIndividual, 2)); ?>

                                                        <!--[if BLOCK]><![endif]--><?php if(isset($item['porcentaje_descuento']) && $item['porcentaje_descuento'] > 0): ?>
                                                            (<?php echo e(number_format($item['porcentaje_descuento'], 1)); ?>%)
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                
                                                <!-- Mostrar descuento de tercera/cuarta edad después -->
                                                <!--[if BLOCK]><![endif]--><?php if($descuentoAplicado > 0): ?>
                                                    <div class="text-danger small fw-bold">-L. <?php echo e(number_format($descuentoAplicado, 2)); ?></div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                
                                                <!-- Mostrar subtotal final con descuentos aplicados si hay descuentos -->
                                                <!--[if BLOCK]><![endif]--><?php if($descuentoUnitarioTotal > 0 || $descuentoIndividual > 0 || $descuentoAplicado > 0 || 
                                                    ($esServicio && isset($descuentosGuardados[$item['servicio_id']])) || 
                                                    (!$esServicio && isset($descuentosGuardados[$item['id']]))): ?>
                                                    <div class="text-success fw-bold border-top pt-1 mt-1">L. <?php echo e(number_format($subtotalConDescuento, 2)); ?></div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>L. <?php echo e(number_format($isv, 2)); ?>

                                                <span class="text-xs text-gray-500">(<?php echo e($item['isv']); ?>%)</span>
                                            </td>
                                            <td>L. <?php echo e(number_format($total, 2)); ?></td>
                                            <td class="text-center">
                                                <!-- Botón de descuento por producto -->
                                                <button wire:click="mostrarModalDescuentoProducto(<?php echo e($loop->index); ?>)"
                                                    class="p-1 mr-2 transition-opacity btn btn-link hover:opacity-75"
                                                    title="Aplicar descuento">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2zM10 8.5a.5.5 0 11-1 0 .5.5 0 011 0zm5 5a.5.5 0 11-1 0 .5.5 0 011 0z" style="color:#f59e0b;" />
                                                    </svg>
                                                </button>
                                                
                                                <!-- Botón de eliminar -->
                                                <button wire:click="eliminarProducto(<?php echo e($loop->index); ?>)"
                                                    class="p-0 transition-opacity btn btn-link hover:opacity-75"
                                                    title="Eliminar producto">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 7v12a2 2 0 002 2h8a2 2 0 002-2V7M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2m-7 0h10" style="color:#e3342f;" />
                                                        <line x1="10" y1="11" x2="10" y2="17" stroke="#e3342f" stroke-width="2"/>
                                                        <line x1="14" y1="11" x2="14" y2="17" stroke="#e3342f" stroke-width="2"/>
                                                    </svg>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center text-muted">No hay productos o servicios agregados</td>
                                        </tr>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Botones de Descuento -->
                        <!--[if BLOCK]><![endif]--><?php if(count($productosFactura) > 0): ?>
                        <div class="mb-3 d-flex justify-content-end">
                            <!-- Botón 3ra Edad -->
                            <button
                                wire:click="aplicarDescuentoTerceraEdad"
                                class="btn me-2 <?php echo e($descuentoTerceraEdad ? 'btn-danger' : 'btn-success'); ?> <?php echo e($descuentoCuartaEdad ? 'opacity-50' : ''); ?>"
                                <?php echo e($descuentoCuartaEdad ? 'disabled' : ''); ?>

                                style="<?php echo e($descuentoCuartaEdad ? 'cursor: not-allowed;' : 'cursor: pointer;'); ?>"
                                title="<?php echo e($descuentoCuartaEdad ? 'Deshabilitado: ya hay un descuento de 4ta edad aplicado' : 'Descuento para personas de 60-64 años'); ?>">
                                <i class="fas fa-user-friends me-1"></i>
                                <?php echo e($descuentoTerceraEdad ? 'Remover' : 'Aplicar'); ?> 3ra Edad
                            </button>

                            <!-- Botón 4ta Edad -->
                            <button
                                wire:click="aplicarDescuentoCuartaEdad"
                                class="btn <?php echo e($descuentoCuartaEdad ? 'btn-danger' : 'btn-success'); ?> <?php echo e($descuentoTerceraEdad ? 'opacity-50' : ''); ?>"
                                <?php echo e($descuentoTerceraEdad ? 'disabled' : ''); ?>

                                style="<?php echo e($descuentoTerceraEdad ? 'cursor: not-allowed;' : 'cursor: pointer;'); ?>"
                                title="<?php echo e($descuentoTerceraEdad ? 'Deshabilitado: ya hay un descuento de 3ra edad aplicado' : 'Descuento para personas de 65+ años'); ?>">
                                <i class="fas fa-user-check me-1"></i>
                                <?php echo e($descuentoCuartaEdad ? 'Remover' : 'Aplicar'); ?> 4ta Edad
                            </button>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- Totales -->
                        <div class="flex justify-end mb-4" x-data="{
                            subtotal: <?php if ((object) ('subtotal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('subtotal'->value()); ?>')<?php echo e('subtotal'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('subtotal'); ?>')<?php endif; ?>,
                            subtotalBruto: <?php if ((object) ('subtotalBruto') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('subtotalBruto'->value()); ?>')<?php echo e('subtotalBruto'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('subtotalBruto'); ?>')<?php endif; ?>,
                            totalIsv: <?php if ((object) ('totalIsv') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('totalIsv'->value()); ?>')<?php echo e('totalIsv'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('totalIsv'); ?>')<?php endif; ?>,
                            total: <?php if ((object) ('total') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('total'->value()); ?>')<?php echo e('total'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('total'); ?>')<?php endif; ?>,
                            totalDescuentos: <?php if ((object) ('totalDescuentos') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('totalDescuentos'->value()); ?>')<?php echo e('totalDescuentos'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('totalDescuentos'); ?>')<?php endif; ?>,
                            isvPorTasa: <?php if ((object) ('isvPorTasa') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isvPorTasa'->value()); ?>')<?php echo e('isvPorTasa'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isvPorTasa'); ?>')<?php endif; ?>
                        }">
                            <div class="w-full max-w-md p-4 border border-gray-300 rounded-lg bg-gray-50">
                                <!-- Encabezado -->
                                <div class="mb-3 text-center">
                                    <h6 class="mb-0 font-bold text-gray-700">RESUMEN DE FACTURACIÓN</h6>
                                    <hr class="mt-2">
                                </div>

                                <!-- Subtotal bruto -->
                                <div class="flex justify-between mb-2">
                                    <span class="font-medium text-gray-700">Subtotal bruto:</span>
                                    <span class="font-medium" x-text="'L. ' + parseFloat(subtotalBruto).toFixed(2)">L. <?php echo e(number_format($subtotalBruto, 2)); ?></span>
                                </div>

                                <!-- Desglose de descuentos -->
                                <!--[if BLOCK]><![endif]--><?php if($totalDescuentos > 0): ?>
                                    <div class="mb-2 border-l-4 border-red-400 pl-3 bg-red-50">
                                        <div class="flex justify-between mb-1">
                                            <span class="font-medium text-red-700">
                                                <i class="fas fa-minus-circle mr-1"></i>
                                                Total Descuentos:
                                            </span>
                                            <span class="font-medium text-red-700" x-text="'-L. ' + parseFloat(totalDescuentos).toFixed(2)">-L. <?php echo e(number_format($totalDescuentos, 2)); ?></span>
                                        </div>
                                        
                                        <!-- Desglose por tipo de descuento -->
                                        <div class="ml-2 mt-1 space-y-1">
                                            <!--[if BLOCK]><![endif]--><?php if($descuentoTerceraEdad): ?>
                                                <?php
                                                    $totalDescuentoTerceraEdad = 0;
                                                    foreach($productosFactura as $item) {
                                                        if(($item['descuento_tercera'] ?? 0) == 1) {
                                                            $subtotalItem = $item['precio'] * $item['cantidad'];
                                                            $totalDescuentoTerceraEdad += $subtotalItem * 0.25;
                                                        }
                                                    }
                                                ?>
                                                <div class="flex justify-between text-sm text-red-600">
                                                    <span class="ml-2">• Descuento tercera edad (25%):</span>
                                                    <span class="font-medium">L. <?php echo e(number_format($totalDescuentoTerceraEdad, 2)); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <!--[if BLOCK]><![endif]--><?php if($descuentoCuartaEdad): ?>
                                                <?php
                                                    $totalDescuentoCuartaEdad = 0;
                                                    foreach($productosFactura as $item) {
                                                        if(($item['descuento_cuarta'] ?? 0) == 1) {
                                                            $subtotalItem = $item['precio'] * $item['cantidad'];
                                                            $totalDescuentoCuartaEdad += $subtotalItem * 0.35;
                                                        }
                                                    }
                                                ?>
                                                <div class="flex justify-between text-sm text-red-600">
                                                    <span class="ml-2">• Descuento cuarta edad (35%):</span>
                                                    <span class="font-medium">L. <?php echo e(number_format($totalDescuentoCuartaEdad, 2)); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php
                                                // Calcular total de descuentos de productos individuales
                                                $totalDescuentosIndividuales = 0;
                                                foreach($productosFactura as $item) {
                                                    $totalDescuentosIndividuales += $item['descuento_monto'] ?? 0;
                                                }
                                                // Calcular total de descuentos unitarios
                                                $totalDescuentosUnitarios = array_sum(array_column($productosFactura, 'descuento_unitario_aplicado', 0));
                                                // Suma total de descuentos de productos (unitarios + individuales)
                                                $totalDescuentosProductos = $totalDescuentosIndividuales + $totalDescuentosUnitarios;
                                            ?>
                                            <!--[if BLOCK]><![endif]--><?php if($totalDescuentosProductos > 0): ?>
                                                <div class="flex justify-between text-sm text-red-600">
                                                    <span class="ml-2">• Descuentos unitarios:</span>
                                                    <span class="font-medium">L. <?php echo e(number_format($totalDescuentosProductos, 2)); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>

                                    <!-- Subtotal con descuentos -->
                                    <div class="flex justify-between mb-2 font-medium text-gray-700">
                                        <span>Subtotal con descuentos:</span>
                                        <span x-text="'L. ' + parseFloat(subtotal).toFixed(2)">L. <?php echo e(number_format($subtotal, 2)); ?></span>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <!-- Desglose del ISV -->
                                <!--[if BLOCK]><![endif]--><?php if($totalIsv > 0): ?>
                                    <div class="mb-2 border-l-4 border-blue-400 pl-3 bg-blue-50">
                                        <div class="flex justify-between mb-1">
                                            <span class="font-medium text-blue-700">
                                                <i class="fas fa-plus-circle mr-1"></i>
                                                Total ISV:
                                            </span>
                                            <span class="font-medium text-blue-700" x-text="'L. ' + parseFloat(totalIsv).toFixed(2)">L. <?php echo e(number_format($totalIsv, 2)); ?></span>
                                        </div>
                                        
                                        <!-- Desglose del ISV por tasa si está disponible -->
                                        <?php if(isset($isvPorTasa) && is_array($isvPorTasa) && count($isvPorTasa) > 0): ?>
                                            <?php $__currentLoopData = $isvPorTasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasa => $monto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <!--[if BLOCK]><![endif]--><?php if($monto > 0): ?>
                                                    <div class="flex justify-between text-sm text-blue-600">
                                                        <span class="ml-4">• ISV <?php echo e($tasa); ?>%:</span>
                                                        <span>L. <?php echo e(number_format($monto, 2)); ?></span>
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php else: ?>
                                            <div class="flex justify-between text-sm text-blue-600">
                                                <span class="ml-4">• ISV 15%:</span>
                                                <span x-text="'L. ' + parseFloat(totalIsv).toFixed(2)">L. <?php echo e(number_format($totalIsv, 2)); ?></span>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <hr class="my-3 border-gray-400">
                                
                                <!-- Total final -->
                                <div class="flex justify-between p-3 bg-green-100 border border-green-300 rounded">
                                    <span class="text-xl font-bold text-green-800">
                                        <i class="fas fa-calculator mr-2"></i>
                                        TOTAL A PAGAR:
                                    </span>
                                    <span class="text-xl font-bold text-green-800" x-text="'L. ' + parseFloat(total).toFixed(2)">L. <?php echo e(number_format($total, 2)); ?></span>
                                </div>

                                <!-- Información adicional -->
                                <div class="mt-3 text-xs text-center text-gray-500">
                                    <!--[if BLOCK]><![endif]--><?php if(count($productosFactura) > 0): ?>
                                        <?php echo e(count($productosFactura)); ?> artículo(s) en la factura
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>

                        <!-- Botón Procesar Factura -->
                        <!--[if BLOCK]><![endif]--><?php if(count($productosFactura) > 0): ?>
                        <div class="mt-4 text-center">
                            <button type="button" 
                                wire:click="mostrarModalPago"
                                class="btn btn-primary btn-lg px-5 py-3"
                                style="font-size: 1.1rem; font-weight: 600;">
                                <i class="fas fa-file-invoice-dollar me-2"></i>
                                Procesar Factura
                            </button>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        
                    </div>
                </div>

                <!-- 2.2 CATÁLOGO VISUAL (derecha - 1 columna de espacio) -->
                <!--[if BLOCK]><![endif]--><?php if($mostrarCatalogoVisual): ?>
                <div class="lg:col-span-1 bg-white border border-gray-300 rounded-lg shadow-lg" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">
                    <!-- Header -->
                    <div class="flex items-center justify-between px-4 py-3 font-semibold text-white rounded-t"
                        :class="{
                            'bg-emerald-600': theme === 'verde',
                            'bg-blue-600': theme === 'azul',
                            'bg-gray-900': theme === 'oscuro',
                            'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                        }"
                    >
                        <h3 class="mb-0 text-lg">
                            <i class="fas fa-th-large me-2"></i>
                            Catálogo Visual
                        </h3>
                    </div>

                    <!-- Content -->
                    <div class="p-3">
                        <!-- Filtros de tipo -->
                        <div class="mb-3 btn-group w-100" role="group">
                            <button type="button" 
                                wire:click="$set('tipoSeleccion', 'todos')"
                                class="btn btn-sm <?php echo e($tipoSeleccion === 'todos' ? 'btn-primary' : 'btn-outline-primary'); ?>">
                                <i class="fas fa-th me-1"></i>Todos
                            </button>
                            <button type="button" 
                                wire:click="$set('tipoSeleccion', 'productos')"
                                class="btn btn-sm <?php echo e($tipoSeleccion === 'productos' ? 'btn-success' : 'btn-outline-success'); ?>">
                                <i class="fas fa-box me-1"></i>Productos
                            </button>
                            <button type="button" 
                                wire:click="$set('tipoSeleccion', 'servicios')"
                                class="btn btn-sm <?php echo e($tipoSeleccion === 'servicios' ? 'btn-info' : 'btn-outline-info'); ?>">
                                <i class="fas fa-concierge-bell me-1"></i>Servicios
                            </button>
                        </div>

                        <!-- Búsqueda -->
                        <div class="mb-3">
                            <input type="text"
                                wire:model.live="busquedaProductosServicios"
                                class="form-control form-control-sm"
                                placeholder="Buscar productos y servicios...">
                        </div>

                        <!-- Grid de productos y servicios con scroll vertical - SOLO 2 ITEMS POR FILA -->
                        <div style="height: 650px; overflow-y: auto;" class="border rounded">
                            <div class="row p-2 g-2">
                                <?php
                                    $items = $this->obtenerProductosYServiciosFiltrados();
                                ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Solo 2 items por fila: col-6 -->
                                    <div class="col-6">
                                        <div class="border card h-100 position-relative" 
                                             style="cursor: pointer; transition: transform 0.2s, box-shadow 0.2s;"
                                             wire:click="<?php echo e($item->esServicio ? 'agregarServicio' : 'agregarProductoPorClic'); ?>(<?php echo e($item->id); ?>)"
                                             onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(0,0,0,0.15)';"
                                             onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0,0,0,0.1)';">
                                            
                                            <!-- Badge de tipo -->
                                            <span class="badge <?php echo e($item->esServicio ? 'bg-info' : 'bg-success'); ?> position-absolute top-0 start-0 m-1" style="z-index: 10; font-size: 0.65rem;">
                                                <i class="fas <?php echo e($item->esServicio ? 'fa-concierge-bell' : 'fa-box'); ?> me-1"></i>
                                                <?php echo e($item->esServicio ? 'Servicio' : 'Producto'); ?>

                                            </span>
                                            
                                            <!-- Imagen más grande para mejor visualización -->
                                            <?php
                                                $imagenBase64 = $item->esServicio ? $this->getServicioImagen($item->id) : $this->getProductoImagen($item->id);
                                            ?>
                                            <!--[if BLOCK]><![endif]--><?php if($imagenBase64): ?>
                                                <img src="data:image/jpeg;base64,<?php echo e($imagenBase64); ?>" 
                                                     class="card-img-top" 
                                                     style="height: 140px; object-fit: cover;"
                                                     alt="<?php echo e($item->nombre); ?>">
                                            <?php else: ?>
                                                <div class="bg-light card-img-top d-flex align-items-center justify-content-center" 
                                                     style="height: 140px;">
                                                    <i class="text-muted fas <?php echo e($item->esServicio ? 'fa-concierge-bell' : 'fa-box'); ?> fa-3x"></i>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            
                                            <div class="card-body p-2">
                                                <h6 class="card-title mb-1 fw-bold text-center" style="font-size: 0.8rem; line-height: 1.1;"><?php echo e($item->nombre); ?></h6>
                                                
                                                <!--[if BLOCK]><![endif]--><?php if(!$item->esServicio && !empty($item->codigo_barra)): ?>
                                                    <p class="mb-1 text-center small text-muted" style="font-size: 0.7rem;">
                                                        <i class="fas fa-barcode me-1"></i><?php echo e($item->codigo_barra); ?>

                                                    </p>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                
                                                <div class="text-center">
                                                    <div class="mb-1">
                                                        <span class="text-success fw-bold" style="font-size: 0.9rem;">
                                                            L. <?php echo e(number_format($item->precio_base, 2)); ?>

                                                        </span>
                                                    </div>
                                                    <!--[if BLOCK]><![endif]--><?php if(!$item->esServicio): ?>
                                                        <div class="mb-2">
                                                            <small class="text-muted" style="font-size: 0.7rem;">
                                                                Stock: <?php echo e($item->stockDisponible ?? 0); ?>

                                                            </small>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                
                                <!--[if BLOCK]><![endif]--><?php if($items->isEmpty()): ?>
                                    <div class="col-12 text-center p-4">
                                        <i class="fas fa-search fa-2x text-muted mb-3"></i>
                                        <p class="text-muted">No se encontraron <?php echo e($tipoSeleccion === 'productos' ? 'productos' : ($tipoSeleccion === 'servicios' ? 'servicios' : 'elementos')); ?></p>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="lg:col-span-1 bg-white border border-gray-300 rounded-lg shadow-lg flex items-center justify-center">
                    <div class="text-center p-8">
                        <i class="fas fa-lock fa-3x text-gray-400 mb-4"></i>
                        <h5 class="text-gray-500 mb-2">Catálogo Visual No Disponible</h5>
                        <p class="text-gray-400 text-sm">El menú de servicios está inactivo</p>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div> <!-- End grid de dos columnas -->

        </div> <!-- End contenedor principal -->

    <!-- Modal de Pago -->
    <!-- Modal de métodos de pago -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalPagoFlag): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         @click.self="$wire.cerrarModalPago()"
         @keydown.escape.window="$wire.cerrarModalPago()">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-hidden"
             x-data="{
                totalModal: <?php if ((object) ('total') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('total'->value()); ?>')<?php echo e('total'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('total'); ?>')<?php endif; ?>,
                montosPorMetodo: <?php if ((object) ('montosPorMetodo') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('montosPorMetodo'->value()); ?>')<?php echo e('montosPorMetodo'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('montosPorMetodo'); ?>')<?php endif; ?>,
                get totalDistribuido() {
                    return Object.values(this.montosPorMetodo || {}).reduce((sum, monto) => sum + parseFloat(monto || 0), 0);
                },
                get diferencia() {
                    return this.totalModal - this.totalDistribuido;
                },
                get puedeProceesar() {
                    return this.totalDistribuido >= this.totalModal && this.totalDistribuido > 0;
                },
                get metodosConMonto() {
                    return Object.entries(this.montosPorMetodo || {}).filter(([id, monto]) => parseFloat(monto || 0) > 0);
                }
             }"
             x-init="$watch('theme', t => localStorage.setItem('theme', t))">
            <!-- Header compacto -->
            <div class="flex items-center justify-between px-4 py-3 text-white"
                :class="{
                    'bg-emerald-600': theme === 'verde',
                    'bg-blue-600': theme === 'azul',
                    'bg-gray-900': theme === 'oscuro',
                    'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                }">
                <h2 class="text-lg font-semibold">
                    <i class="fas fa-credit-card me-2"></i>
                    Métodos de Pago
                </h2>
                <button wire:click="cerrarModalPago" class="text-white transition-colors hover:text-gray-200">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <!-- Contenido con scroll -->
            <div class="overflow-y-auto max-h-[calc(90vh-120px)]">
                <div class="p-4">
                    <!-- Total compacto -->
                    <div class="p-3 mb-4 text-center rounded-lg bg-gray-50">
                        <div class="text-sm text-gray-600">Total a Pagar</div>
                        <div class="text-xl font-bold text-gray-800" x-text="'L. ' + parseFloat(totalModal).toFixed(2)">L. <?php echo e(number_format($total, 2)); ?></div>
                    </div>

                    <!-- Métodos de pago compactos -->
                    <div class="mb-4 space-y-3">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tiposPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoPago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex items-center gap-3 p-3 border border-gray-200 rounded-lg <?php echo e(($montosPorMetodo[$tipoPago->id] ?? 0) > 0 ? 'bg-blue-50 border-blue-300' : ''); ?>">
                                <!-- Icono y nombre -->
                                <div class="flex items-center flex-1 min-w-0">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center mr-2 flex-shrink-0
                                        <?php if($tipoPago->nombre == 'Efectivo'): ?> bg-green-100 text-green-600
                                        <?php elseif($tipoPago->nombre == 'Tarjeta(POS)'): ?> bg-blue-100 text-blue-600
                                        <?php elseif($tipoPago->nombre == 'Cheque'): ?> bg-purple-100 text-purple-600
                                        <?php else: ?> bg-gray-100 text-gray-600 <?php endif; ?>">
                                        <!--[if BLOCK]><![endif]--><?php if($tipoPago->nombre == 'Efectivo'): ?>
                                            <i class="text-sm fas fa-money-bill-wave"></i>
                                        <?php elseif($tipoPago->nombre == 'Tarjeta'): ?>
                                            <i class="text-sm fas fa-credit-card"></i>
                                        <?php elseif($tipoPago->nombre == 'Cheque'): ?>
                                            <i class="text-sm fas fa-file-invoice-dollar"></i>
                                        <?php else: ?>
                                            <i class="text-sm fas fa-coins"></i>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <span class="text-sm font-medium text-gray-800"><?php echo e($tipoPago->nombre); ?></span>
                                </div>

                                <!-- Input de monto -->
                                <div class="flex-shrink-0 w-24">
                                    <div class="relative">
                                        <span class="absolute text-xs text-gray-500 transform -translate-y-1/2 left-2 top-1/2">L.</span>
                                        <input type="number"
                                            wire:model.live="montosPorMetodo.<?php echo e($tipoPago->id); ?>"
                                            step="0.01"
                                            min="0"
                                            x-bind:max="totalModal"
                                            class="w-full py-2 pl-6 pr-2 text-sm text-center border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-200"
                                            placeholder="0.00">
                                    </div>
                                </div>

                                <!-- Indicador activo -->
                                <!--[if BLOCK]><![endif]--><?php if(($montosPorMetodo[$tipoPago->id] ?? 0) > 0): ?>
                                    <div class="flex-shrink-0">
                                        <i class="text-green-500 fas fa-check-circle"></i>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="py-4 text-center text-gray-500">
                                <i class="mb-2 fas fa-exclamation-triangle"></i>
                                <p class="text-sm">No hay métodos de pago configurados</p>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Resumen compacto con Alpine.js -->
                    <div x-show="totalDistribuido > 0" class="p-3 mb-4 rounded-lg"
                         x-bind:class="puedeProceesar ? 'bg-green-50 border border-green-200' : 'bg-orange-50 border border-orange-200'">
                        <div class="flex items-center justify-between mb-1 text-sm">
                            <span class="font-medium" x-bind:class="puedeProceesar ? 'text-green-700' : 'text-orange-700'">
                                Distribuido:
                            </span>
                            <span class="font-bold" x-bind:class="puedeProceesar ? 'text-green-700' : 'text-orange-700'"
                                  x-text="'L. ' + totalDistribuido.toFixed(2)">
                            </span>
                        </div>

                        <template x-if="puedeProceesar">
                            <div>
                                <template x-if="diferencia < 0">
                                    <div class="flex items-center text-xs text-green-600">
                                        <i class="mr-1 fas fa-info-circle"></i>
                                        <span x-text="'Cambio: L. ' + Math.abs(diferencia).toFixed(2)"></span>
                                    </div>
                                </template>
                                <template x-if="diferencia >= 0">
                                    <div class="flex items-center text-xs text-green-600">
                                        <i class="mr-1 fas fa-check-circle"></i>
                                        Listo para procesar
                                    </div>
                                </template>
                            </div>
                        </template>

                        <template x-if="!puedeProceesar">
                            <div class="flex items-center text-xs text-orange-600">
                                <i class="mr-1 fas fa-exclamation-triangle"></i>
                                <span x-text="'Falta: L. ' + diferencia.toFixed(2)"></span>
                            </div>
                        </template>

                        <!-- Métodos activos compactos con Alpine.js -->
                        <template x-if="metodosConMonto.length > 0">
                            <div class="flex flex-wrap gap-1 mt-2">
                                <template x-for="[tipoId, monto] in metodosConMonto" :key="tipoId">
                                    <span class="inline-block px-2 py-1 text-xs font-medium text-blue-700 bg-blue-100 rounded"
                                          x-text="'Método ' + tipoId + ': L. ' + parseFloat(monto).toFixed(2)">
                                    </span>
                                </template>
                            </div>
                        </template>
                    </div>
                </div>
            </div>

            <!-- Botones fijos en la parte inferior -->
            <div class="flex items-center justify-between gap-3 p-4 border-t border-gray-200 bg-gray-50">
                <button wire:click="cerrarModalPago"
                    class="px-4 py-2 text-gray-700 transition-colors bg-gray-200 rounded-lg hover:bg-gray-300">
                    Cancelar
                </button>

                <div class="flex gap-2">
                    <!--[if BLOCK]><![endif]--><?php if(count($tiposPago) > 0): ?>
                        <button wire:click="distribuirTotalEnEfectivo"
                            class="px-3 py-2 text-sm text-green-700 transition-colors bg-green-100 rounded-lg hover:bg-green-200">
                            <i class="mr-1 fas fa-money-bill-wave"></i>
                            Efectivo
                        </button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <button wire:click="procesarDistribucionPagos"
                        wire:loading.attr="disabled"
                        wire:loading.class="opacity-50"
                        x-bind:disabled="!puedeProceesar"
                        x-bind:class="puedeProceesar ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'"
                        class="px-4 py-2 text-white transition-colors rounded-lg">
                        <span wire:loading.remove>
                            <i class="mr-1 fas fa-check"></i>
                            <span x-text="puedeProceesar ? 'Procesar' : 'Incompleto'"></span>
                        </span>
                        <span wire:loading>
                            <i class="mr-1 fas fa-spinner fa-spin"></i>
                            ...
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de pago en efectivo -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalEfectivoFlag): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         @click.self="$wire.cerrarModalEfectivo()"
         @keydown.escape.window="$wire.cerrarModalEfectivo()">
        <div class="w-full max-w-lg overflow-hidden bg-white shadow-xl rounded-xl"
             x-data="{ efectivoRecibido: <?php if ((object) ('efectivoRecibido') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('efectivoRecibido'->value()); ?>')<?php echo e('efectivoRecibido'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('efectivoRecibido'); ?>')<?php endif; ?> }"
             x-init="$watch('theme', t => localStorage.setItem('theme', t))">
            <!-- Header con tema -->
            <div class="flex items-center justify-between px-6 py-4 text-white bg-green-600">
                <h2 class="text-xl font-semibold">
                    <i class="fas fa-money-bill-wave me-2"></i>
                    Pago en Efectivo
                </h2>
                <button wire:click="cerrarModalEfectivo" class="text-white transition-colors hover:text-gray-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="p-6">
                <!-- Información del pago -->
                <div class="mb-6">
                    <!--[if BLOCK]><![endif]--><?php if(count($metodosActivosParaPago) > 1): ?>
                        <div class="p-4 mb-4 border border-blue-200 rounded-lg bg-blue-50">
                            <h3 class="mb-2 font-semibold text-blue-800">
                                <i class="mr-2 fas fa-info-circle"></i>
                                Pago Mixto Detectado
                            </h3>
                            <p class="text-sm text-blue-700">
                                Se procesará el efectivo primero, luego continuará con los otros métodos de pago.
                            </p>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Monto que debe recibir en efectivo -->
                    <div class="p-6 mb-6 text-center border-2 border-green-200 bg-green-50 rounded-xl">
                        <div class="mb-1 text-sm font-medium text-green-700">Monto a recibir en efectivo</div>
                        <div class="text-3xl font-bold text-green-800">L. <?php echo e(number_format($montoEfectivo ?? 0, 2)); ?></div>
                        <!--[if BLOCK]><![endif]--><?php if(count($metodosActivosParaPago) > 1): ?>
                            <div class="mt-2 text-sm text-green-600">
                                Restante para otros métodos: L. <?php echo e(number_format($total - ($montoEfectivo ?? 0), 2)); ?>

                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Input de efectivo recibido del cliente -->
                <div class="mb-6">
                    <label for="efectivo_recibido" class="block mb-3 text-lg font-semibold text-gray-800">
                        💵 ¿Cuánto efectivo entregó el cliente?
                    </label>
                    <div class="relative">
                        <span class="absolute text-xl font-bold text-gray-500 transform -translate-y-1/2 left-4 top-1/2">L.</span>
                        <input type="number"
                            id="efectivo_recibido"
                            wire:model.live="efectivoRecibido"
                            step="0.01"
                            min="0"
                            class="w-full py-4 pl-12 pr-6 text-2xl font-bold text-center transition-all border-2 border-gray-300 rounded-xl focus:border-green-500 focus:ring-2 focus:ring-green-200"
                            placeholder="0.00"
                            autofocus>
                    </div>
                    <div class="mt-2 text-sm text-center text-gray-600">
                        Ejemplo: Si el cliente le entrega un billete de L. 100, escriba 100.00
                    </div>
                </div>

                <!-- Cálculo de cambio -->
                <!--[if BLOCK]><![endif]--><?php if($efectivoRecibido > 0): ?>
                    <?php
                        $montoAPagar = $montoEfectivo ?? 0;
                        $cambio = $efectivoRecibido - $montoAPagar;
                        $esSuficiente = $efectivoRecibido >= $montoAPagar;
                    ?>

                    <div class="mb-6 p-6 rounded-xl border-2 <?php echo e($esSuficiente ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300'); ?>">
                        <h3 class="font-bold text-lg <?php echo e($esSuficiente ? 'text-green-800' : 'text-red-800'); ?> mb-4">
                            📊 Resumen del Pago
                        </h3>

                        <div class="space-y-3">
                            <div class="flex items-center justify-between">
                                <span class="font-medium text-gray-700">Monto a cobrar:</span>
                                <span class="font-bold text-gray-800">L. <?php echo e(number_format($montoAPagar, 2)); ?></span>
                            </div>

                            <div class="flex items-center justify-between">
                                <span class="font-medium text-gray-700">Efectivo recibido:</span>
                                <span class="font-bold text-blue-600">L. <?php echo e(number_format($efectivoRecibido, 2)); ?></span>
                            </div>

                            <hr class="border-gray-300">

                            <?php if($esSuficiente): ?>
                                <!--[if BLOCK]><![endif]--><?php if($cambio > 0): ?>
                                    <div class="flex items-center justify-between">
                                        <span class="font-bold text-green-700">💰 Cambio a entregar:</span>
                                        <span class="text-2xl font-bold text-green-600">L. <?php echo e(number_format($cambio, 2)); ?></span>
                                    </div>
                                    <div class="mt-2 text-sm text-center text-green-600">
                                        ✅ Devuelva L. <?php echo e(number_format($cambio, 2)); ?> al cliente
                                    </div>
                                <?php else: ?>
                                    <div class="text-center">
                                        <span class="text-lg font-bold text-green-700">✅ Pago exacto</span>
                                        <div class="mt-1 text-sm text-green-600">No hay cambio que entregar</div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <div class="flex items-center justify-between">
                                    <span class="font-bold text-red-700">❌ Falta por pagar:</span>
                                    <span class="text-2xl font-bold text-red-600">L. <?php echo e(number_format(abs($cambio), 2)); ?></span>
                                </div>
                                <div class="mt-2 text-sm text-center text-red-600">
                                    El efectivo recibido es insuficiente
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Botones de acción -->
                <div class="flex justify-end gap-4">
                    <button wire:click="cerrarModalEfectivo"
                        class="px-6 py-3 font-medium text-gray-700 transition-colors bg-gray-200 rounded-xl hover:bg-gray-300">
                        <i class="mr-2 fas fa-times"></i>
                        Cancelar
                    </button>
                    <button wire:click="confirmarEfectivo"
                        class="px-8 py-3 text-white rounded-xl transition-colors font-medium text-lg <?php echo e(($efectivoRecibido > 0 && $efectivoRecibido >= ($montoEfectivo ?? 0)) ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'); ?>"
                        <?php if($efectivoRecibido <= 0 || $efectivoRecibido < ($montoEfectivo ?? 0)): ?> disabled <?php endif; ?>>
                        <i class="mr-2 fas fa-check"></i>
                        <!--[if BLOCK]><![endif]--><?php if(count($metodosActivosParaPago) > 1): ?>
                            Continuar con otros pagos
                        <?php else: ?>
                            Finalizar Venta
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de Descuento Adulto Mayor -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalDescuentoAdulto): ?>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-user-friends me-2"></i>
                            Descuento Adulto Mayor
                        </h5>
                        <button type="button" class="btn-close" wire:click="$set('mostrarModalDescuentoAdulto', false)"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-3">Por favor, proporcione los datos del cliente para aplicar el descuento:</p>
                        
                        <div class="mb-3">
                            <label class="form-label">Nombre Completo *</label>
                            <input type="text" 
                                class="form-control" 
                                wire:model="nombreAdulto"
                                placeholder="Ingrese el nombre completo">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Número de Identidad *</label>
                            <input type="text" 
                                class="form-control" 
                                wire:model="dniAdulto"
                                placeholder="Ingrese el número de identidad">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Edad *</label>
                            <input type="number" 
                                class="form-control" 
                                wire:model="edadAdulto"
                                placeholder="Ingrese la edad"
                                min="60">
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Información:</strong>
                            <br>• Tercera edad (60-64 años): 25% de descuento
                            <br>• Cuarta edad (65+ años): 35% de descuento
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" 
                            class="btn btn-secondary" 
                            wire:click="$set('mostrarModalDescuentoAdulto', false)">
                            Cancelar
                        </button>
                        <button type="button" 
                            class="btn btn-success" 
                            wire:click="confirmarDescuentoAdulto">
                            Aplicar Descuento
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal Descuento por Producto -->
    <!--[if BLOCK]><![endif]--><?php if($modalDescuentoProductoVisible): ?>
        <div class="modal fade show" tabindex="-1" role="dialog" style="display: block; background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog modal-dialog-centered" role="document" x-data="{ porcentaje: <?php if ((object) ('porcentajeDescuentoProducto') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('porcentajeDescuentoProducto'->value()); ?>')<?php echo e('porcentajeDescuentoProducto'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('porcentajeDescuentoProducto'); ?>')<?php endif; ?> }">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Aplicar Descuento al Producto</h5>
                        <button type="button" class="btn-close" wire:click="$set('modalDescuentoProductoVisible', false)"></button>
                    </div>
                    <div class="modal-body">
                        <!--[if BLOCK]><![endif]--><?php if(isset($productoSeleccionadoDescuento)): ?>
                            <div class="mb-3">
                                <label class="fw-bold">Producto:</label>
                                <p class="mb-2"><?php echo e($productoSeleccionadoDescuento['nombre'] ?? 'N/A'); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold">Precio Unitario:</label>
                                <p class="mb-2">L <?php echo e(number_format($productoSeleccionadoDescuento['precio'] ?? 0, 2)); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold">Cantidad:</label>
                                <p class="mb-2"><?php echo e($productoSeleccionadoDescuento['cantidad'] ?? 0); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold">Total Actual:</label>
                                <p class="mb-2">L <?php echo e(number_format($productoSeleccionadoDescuento['total'] ?? (($productoSeleccionadoDescuento['precio'] ?? 0) * ($productoSeleccionadoDescuento['cantidad'] ?? 0)), 2)); ?></p>
                            </div>
                            <div class="mb-3">
                                <label for="porcentaje_descuento_producto" class="form-label">
                                    Porcentaje de Descuento (%)
                                </label>
                                <input type="number" 
                                    id="porcentaje_descuento_producto"
                                    class="form-control" 
                                    wire:model="porcentajeDescuentoProducto"
                                    min="0" 
                                    max="100" 
                                    step="0.1"
                                    placeholder="Ej: 10.5">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['porcentajeDescuentoProducto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="modal-footer">
                        <button type="button" 
                            class="btn btn-secondary" 
                            wire:click="$set('modalDescuentoProductoVisible', false)">
                            Cancelar
                        </button>
                        <button type="button" 
                            class="btn btn-warning" 
                            wire:click="aplicarDescuentoProducto"
                            x-bind:disabled="!porcentaje || porcentaje <= 0">
                            Aplicar Descuento
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>

<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/sala-de-ventas/ventas.blade.php ENDPATH**/ ?>