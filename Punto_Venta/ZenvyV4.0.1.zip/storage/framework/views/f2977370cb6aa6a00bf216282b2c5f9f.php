<div
    class="overflow-hidden border border-gray-300 rounded shadow"
    x-data="{
        tab: 'datos',
        sinCambiosModal: false
    }"
    x-init="$watch('theme', t => localStorage.setItem('theme', t))"
    x-on:mostrar-sin-cambios.window="sinCambiosModal = true"
>

    <!-- ENCABEZADO CON TEMA -->
    <div
        class="flex items-center justify-between px-4 py-2 font-semibold text-white"
        :class="{
            'bg-emerald-600': theme === 'verde',
            'bg-blue-600': theme === 'azul',
            'bg-gray-900': theme === 'oscuro',
            'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
        }"
    >
        <button wire:click="volver" class="px-3 py-1 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
            ← Volver
        </button>
        <h5><?php echo e($modo === 'crear' ? 'Crear Usuario' : 'Editar Usuario'); ?></h5>
        <button wire:click="guardar" class="px-3 py-1 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
            💾 Guardar
        </button>
    </div>

<!-- DATOS DE INICIO DE SESIÓN -->
<div class="p-4">
    <div class="p-4 bg-white border shadow rounded-xl">
        <h2 class="mb-4 text-lg font-semibold text-gray-700">🗝️ Datos de inicio de sesión</h2>

        <div class="grid grid-cols-1 gap-4 mb-4 md:grid-cols-2">
            <div>
                <label class="block text-sm font-medium text-gray-700">Correo<span class="text-red-600">*</span></label>
                <input type="email" wire:model.defer="form.email"
                    <?php if($modo === 'editar'): ?> disabled class="w-full px-3 py-2 bg-gray-100 border rounded cursor-not-allowed"
                    <?php else: ?> class="w-full px-3 py-2 border rounded" <?php endif; ?>
                />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Contraseña<span class="text-red-600">*</span></label>
                <input type="password" wire:model.defer="form.password" class="w-full px-3 py-2 border rounded" />
                         <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
                <label class="block text-sm font-medium text-gray-700">Rol<span class="text-red-600">*</span></label>
                <select wire:model.lazy="form.rol_id" class="w-full px-3 py-2 border rounded">
                    <option value="">-- Seleccionar --</option>
                    <!--[if BLOCK]><![endif]--><?php if($roles && $roles->count() > 0): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--[if BLOCK]><![endif]--><?php if($rol->estado == 1): ?>
                                <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->txt_nombre); ?></option>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <option value="" disabled>No hay roles disponibles</option>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.rol_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Tienda<span class="text-red-600">*</span></label>
                <select wire:model.defer="form.tienda_id" class="w-full px-3 py-2 border rounded">
                    <option value="">-- Seleccionar --</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tienda->id); ?>"><?php echo e($tienda->denominacion_social); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.tienda_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
                <label class="block text-sm font-medium text-gray-700">Estado<span class="text-red-600">*</span></label>
                <select wire:model.defer="form.estado_id" class="w-full px-3 py-2 border rounded">
                    <option value="1">Activo</option>
                    <option value="2">Inactivo</option>
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.estado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div></div> <!-- Espacio vacío para mantener el grid balanceado -->
        </div>
    </div>
</div>

    <!-- DATOS DE ACTOR -->
<div class="p-4">
    <div class="p-4 bg-white border shadow rounded-xl">
        <h2 class="mb-4 text-lg font-semibold text-gray-700">🧍 Datos de Actor</h2>

        <div class="grid grid-cols-1 gap-4 mb-4 md:grid-cols-2">
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Identificación<span class="text-red-600">*</span></label>
                <input type="text" wire:model.defer="form.txt_identificacion"
                    <?php if($modo === 'editar'): ?> disabled class="w-full px-3 py-2 bg-gray-100 border rounded cursor-not-allowed"
                    <?php else: ?> class="w-full px-3 py-2 border rounded" <?php endif; ?>
                />
                     <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.txt_identificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="grid grid-cols-1 gap-4 mb-4 md:grid-cols-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Primer Nombre<span class="text-red-600">*</span></label>
                <input type="text" wire:model.defer="form.primer_nombre" class="w-full px-3 py-2 border rounded" />
                 <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.primer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Segundo Nombre</label>
                <input type="text" wire:model.defer="form.segundo_nombre" class="w-full px-3 py-2 border rounded" />
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Primer Apellido<span class="text-red-600">*</span></label>
                <input type="text" wire:model.defer="form.primer_apellido" class="w-full px-3 py-2 border rounded" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-sm text-red-600"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Segundo Apellido</label>
                <input type="text" wire:model.defer="form.segundo_apellido" class="w-full px-3 py-2 border rounded" />
            </div>
        </div>

        <div class="grid grid-cols-1 gap-4 mb-4 md:grid-cols-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Teléfono</label>
                <input type="text" wire:model.defer="form.telefono" class="w-full px-3 py-2 border rounded" />
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Fecha de Nacimiento</label>
                <input type="date" wire:model.defer="form.fecha_nacimiento" class="w-full px-3 py-2 border rounded" />
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Género</label>
                <select wire:model.defer="form.genero" class="w-full px-3 py-2 border rounded">
                    <option value="">-- Seleccionar --</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                    <option value="Otro">Otro</option>
                </select>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Dirección</label>
            <input type="text" wire:model.defer="form.direccion" class="w-full px-3 py-2 border rounded" />
        </div>
    </div>
</div>

<!-- ACCESOS -->
<div class="p-4">
    <div class="p-4 bg-white border shadow rounded-xl">
        <h2 class="mb-4 text-lg font-semibold text-gray-700">🔐 Accesos</h2>

        <nav class="flex gap-2 mb-4">
            <button @click="tab = 'empresas'" :class="tab === 'empresas' ? 'border-b-2 border-emerald-600 font-bold' : ''">🏢 Empresa</button>
            <button @click="tab = 'permisos'" :class="tab === 'permisos' ? 'border-b-2 border-emerald-600 font-bold' : ''">🔐 Permisos</button>
        </nav>

        <!-- Empresa -->
        <div x-show="tab === 'empresas'">
            <!--[if BLOCK]><![endif]--><?php if(empty($empresas)): ?>
                <p class="italic text-red-600">No se encuentra una empresa asignada al usuario.</p>
            <?php else: ?>
                <!-- Aquí iría tu tabla o listado de empresas -->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <!-- Permisos -->
        <div x-show="tab === 'permisos'">
<h3 class="mb-2 text-sm font-semibold text-gray-700">Permisos del Rol Seleccionado</h3>

<!--[if BLOCK]><![endif]--><?php if(!empty($form['rol_id'])): ?>
    <!--[if BLOCK]><![endif]--><?php if($permisos->isEmpty()): ?>
        <p class="italic text-gray-600">Este rol no tiene permisos asignados.</p>
    <?php else: ?>
        <table class="w-full text-sm text-left border border-gray-300">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-3 py-2 border">Permiso</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-3 py-2 border"><?php echo e($permiso->txt_comentario); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
    </div>
</div>


<!--[if BLOCK]><![endif]--><?php if($mostrarMensaje): ?>
<div
    x-data="{ show: true }"
    x-show="show"
    class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
    @click.outside="show = false; Livewire.dispatch('cambiarVista', { ruta: 'configuracion.usuarios' })"
    @keydown.window.escape="show = false; Livewire.dispatch('cambiarVista', { ruta: 'configuracion.usuarios' })"
>
    <div class="w-full max-w-sm p-6 text-center bg-white rounded-lg shadow-lg">
        <h2 class="mb-2 text-lg font-semibold text-green-700">✅ Usuario actualizado correctamente</h2>
        <p class="text-sm text-gray-600">Puedes continuar usando el sistema.</p>
        <button
            class="px-4 py-2 mt-4 text-sm text-white rounded bg-emerald-600 hover:bg-emerald-700"
            @click="show = false; Livewire.dispatch('cambiarVista', { ruta: 'configuracion.usuarios' })"
        >
            Cerrar
        </button>
    </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->



<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/configuracion/usuariosform.blade.php ENDPATH**/ ?>