<div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

    <!-- ENCABEZADO -->
    <div class="flex items-center justify-between px-4 py-2 font-semibold text-white"
        :class="{
            'bg-emerald-600': theme === 'verde',
            'bg-blue-600': theme === 'azul',
            'bg-gray-900': theme === 'oscuro',
            'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
        }"
    >
        <h5 class="mb-0">Gestión de Roles</h5>
        <button wire:click="abrirModalCrear" class="px-3 py-1 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
            ➕ Agregar Rol
        </button>
    </div>

    <!-- TABLA -->
    <div class="overflow-x-auto bg-white">
        <table class="min-w-full text-sm text-left border border-gray-300">
            <thead class="bg-gray-100 border-b border-gray-300">
                <tr class="text-xs font-semibold text-gray-700 uppercase">
                    <th class="px-4 py-2 border">ID</th>
                    <th class="px-4 py-2 border">Nombre</th>
                    <th class="px-4 py-2 border">Estado</th>
                </tr>
            </thead>
            <tbody class="text-sm text-gray-800 bg-white divide-y divide-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr wire:click="editar(<?php echo e($rol->id); ?>)" class="transition cursor-pointer hover:bg-gray-100">
                        <td class="px-4 py-2 border-t"><?php echo e($rol->id); ?></td>
                        <td class="px-4 py-2 border-t"><?php echo e($rol->txt_nombre); ?></td>
                        <td class="px-4 py-2 border-t">
                            <!--[if BLOCK]><![endif]--><?php if($rol->estado): ?>
                                <span class="inline-block px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">Activo</span>
                            <?php else: ?>
                                <span class="inline-block px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">Inactivo</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="px-4 py-4 italic text-center text-gray-500">No hay roles registrados.</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <!-- MENSAJE -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('mensaje')): ?>
        <div class="p-3 mt-4 text-green-700 bg-green-100 border border-green-400 rounded">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- MODAL (persistente con wire:key) -->
    <div wire:key="modal-<?php echo e($form['id'] ?? 'nuevo'); ?>">
        <div x-data="{
                open: <?php if ((object) ('modalAbierto') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('modalAbierto'->value()); ?>')<?php echo e('modalAbierto'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('modalAbierto'); ?>')<?php endif; ?>,
                theme: localStorage.getItem('theme') || 'verde',
                modo: <?php if ((object) ('modoEdicion') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('modoEdicion'->value()); ?>')<?php echo e('modoEdicion'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('modoEdicion'); ?>')<?php endif; ?>,
                submitted: <?php if ((object) ('submitted') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('submitted'->value()); ?>')<?php echo e('submitted'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('submitted'); ?>')<?php endif; ?>,
                touched: false
            }"
            x-show="open"
            style="display: none"
            x-transition.opacity
            class="fixed inset-0 z-50 flex items-center justify-center px-4 py-6 overflow-y-auto bg-black bg-opacity-50"
        >
            <div
                class="relative w-full max-w-xl p-6 bg-white rounded shadow-lg"
                @click.outside="$wire.cerrarModal()"
                x-transition:enter="transition ease-out duration-300 transform"
                x-transition:enter-start="scale-95 opacity-0"
                x-transition:enter-end="scale-100 opacity-100"
                x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="scale-100 opacity-100"
                x-transition:leave-end="scale-95 opacity-0"
                :class="{
                    'border-t-4 border-emerald-600': theme === 'verde',
                    'border-t-4 border-blue-600': theme === 'azul',
                    'border-t-4 border-gray-900': theme === 'oscuro',
                    'border-t-4 border-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                }"
            >
                <h2 class="mb-4 text-lg font-semibold">
                    <?php echo e($modoEdicion ? 'Editar Rol' : 'Crear Rol'); ?>

                </h2>

                <!-- Nombre del Rol -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Nombre del Rol</label>
                    <input
                        type="text"
                        wire:model.defer="form.txt_nombre"
                        :disabled="modo"
                        class="w-full px-3 py-2 border rounded"
                        :class="{ 'bg-gray-100 cursor-not-allowed': modo }"
                        placeholder="Ej: Administrador"
                    >
                    <!--[if BLOCK]><![endif]--><?php if($submitted && $errors->has('form.txt_nombre')): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($errors->first('form.txt_nombre')); ?></p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Estado -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Estado</label>
                    <select wire:model.defer="form.estado" class="w-full px-3 py-2 border rounded">
                        <option value="1">Activo</option>
                        <option value="0">Inactivo</option>
                    </select>
                </div>

                <!-- Permisos (Menús) -->
                <div class="mb-4">
                    <label class="block mb-2 text-sm font-medium text-gray-700">Accesos (Menús habilitados)</label>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $menusDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo => $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-2">
                            <strong class="text-sm text-gray-600"><?php echo e($grupo); ?></strong>
                            <div class="grid grid-cols-2 gap-2 mt-1">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center space-x-2">
                                        <input type="checkbox" wire:model="permisos" value="<?php echo e($menu['id']); ?>">
                                        <span><?php echo e($menu['nombre']); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Botón Guardar -->
                <div class="flex justify-end mt-6">
                    <button
                        wire:click="guardar"
                        wire:loading.attr="disabled"
                        class="px-4 py-2 text-white rounded"
                        :class="{
                            'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                            'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                            'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                            'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                        }"
                    >
                        <span wire:loading.remove><?php echo e($modoEdicion ? 'Actualizar' : 'Crear'); ?></span>
                        <span wire:loading>Guardando...</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/configuracion/roles.blade.php ENDPATH**/ ?>