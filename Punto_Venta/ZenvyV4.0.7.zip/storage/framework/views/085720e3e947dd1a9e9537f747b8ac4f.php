<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Zenvy')); ?></title>

    <!-- Animate.css (si la usas para animaciones) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Vite -->
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-CMSJGjZF.css')); ?>">
<script type="module" src="<?php echo e(asset('build/assets/app-BLl8G-P3.js')); ?>"></script>
</head>
<body class="font-sans antialiased bg-gray-100">
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/layouts/guest.blade.php ENDPATH**/ ?>