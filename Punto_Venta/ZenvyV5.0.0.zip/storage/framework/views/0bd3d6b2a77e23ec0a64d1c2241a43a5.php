<div>
    <style>
        /* Alerta flotante personalizada (igual que compra-de-producto) */
        .alert-campo-obligatorio {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            background: #f8d7da;
            color: #721c24;
            padding: 12px 16px;
            border-radius: 6px;
            font-size: 14px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            border-left: 4px solid #dc3545;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    </style>

    <!-- Alerta de validación -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarAlerta): ?>
        <div class="alert-campo-obligatorio">
            <strong>⚠️ Campo Obligatorio</strong>
            <button wire:click="cerrarAlerta" style="float: right; background: none; border: none; font-size: 18px; cursor: pointer;">×</button>
            <br><small><?php echo e($mensajeAlerta); ?></small>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- MENSAJES DE SESIÓN -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>✅ Éxito:</strong> <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>⚠️ Advertencia:</strong> <?php echo e(session('warning')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>❌ Error:</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- CONTENEDOR PRINCIPAL OPTIMIZADO -->
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">📦 Productos Recibidos en Bodega</h5>
            <div class="flex items-center gap-2">
                <span class="text-sm opacity-90">Total: <?php echo e($productosRecibidos->total()); ?></span>
            </div>
        </div>

        <!-- FILTROS Y BÚSQUEDA (Debajo del título) -->
        <div class="px-4 py-3 border-b bg-gray-50">
            <div class="flex gap-2">
                <button wire:click="limpiarFiltros" class="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                    🗑️ Limpiar Filtros
                </button>
                <button wire:click="descargarExcel"
                    class="inline-flex items-center gap-1 px-3 py-2 text-sm text-white bg-green-600 rounded hover:bg-green-700 disabled:opacity-50"
                    wire:loading.attr="disabled"
                    wire:target="descargarExcel"
                    title="Descargar reporte">
                    <span wire:loading.remove wire:target="descargarExcel">📥</span>
                    <span wire:loading wire:target="descargarExcel">
                        <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </span>
                    <span wire:loading.remove wire:target="descargarExcel">Descargar reporte</span>
                    <span wire:loading wire:target="descargarExcel">Generando...</span>
                </button>
            </div>
        </div>

        <!-- INFORMACIÓN DE RESULTADOS -->
        <div class="px-4 py-2 bg-gray-100 border-b">
            <div class="text-sm text-gray-600">
                Showing <?php echo e($productosRecibidos->firstItem() ?? 0); ?> to <?php echo e($productosRecibidos->lastItem() ?? 0); ?>

                of <?php echo e($productosRecibidos->total()); ?> results
                <!--[if BLOCK]><![endif]--><?php if($filtroProducto): ?>
                    | Filtrado por: "<?php echo e($filtroProducto); ?>"
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!-- TABLA OPTIMIZADA -->
        <div class="px-4 py-3">
            <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->count() > 0): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full border border-gray-200 table-auto">
                        <thead class="bg-gray-50">
                            <!-- Encabezados con ordenamiento -->
                            <tr>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('producto_id')">
                                    <div class="flex items-center space-x-1">
                                        <span>Código de Producto</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'producto_id'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('producto_nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Producto</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'producto_nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('codigo_barra')">
                                    <div class="flex items-center space-x-1">
                                        <span>Código de Barras</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'codigo_barra'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('marca_nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Marca</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'marca_nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('bodega_nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Bodega</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'bodega_nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b">Segmento</th>
                                <th class="px-4 py-3 text-left border-b">Sección</th>
                                <th class="px-4 py-3 text-center border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('cantidad_disponible')">
                                    <div class="flex items-center justify-center space-x-1">
                                        <span>Stock</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'cantidad_disponible'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-center border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('fecha_recibido')">
                                    <div class="flex items-center justify-center space-x-1">
                                        <span>Fecha Recibido</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'fecha_recibido'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-center border-b">Fecha Expiración</th>
                                <th class="px-4 py-3 text-center border-b">Estado</th>
                                <th class="px-4 py-3 text-center border-b">Comentario</th>
                                <th class="px-4 py-3 text-center border-b">Acciones</th>
                            </tr>
                            <!-- Fila de filtros -->
                            <tr class="bg-white">
                                <th class="px-2 py-2 border-b">
                                    <input type="text" 
                                           wire:model.live.debounce.300ms="filtroCodigoProducto"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <input type="text" 
                                           wire:model.live.debounce.300ms="filtroProducto"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <input type="text" 
                                           wire:model.live.debounce.300ms="filtroCodigoBarra"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <select wire:model.live="filtroMarca" 
                                            class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                        <option value="">Todas</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <select wire:model.live="filtroBodega" 
                                            class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                        <option value="">Todas</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bodega->id); ?>"><?php echo e($bodega->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <input type="text" 
                                           wire:model.live.debounce.300ms="filtroSegmento"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <input type="text" 
                                           wire:model.live.debounce.300ms="filtroSeccion"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <select wire:model.live="filtroEstado" 
                                            class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                        <option value="">Todos</option>
                                        <option value="disponible">Disponible (&gt; 10)</option>
                                        <option value="poco_stock">Poco Stock (1-10)</option>
                                        <option value="agotado">Agotado (0)</option>
                                    </select>
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <input type="date" 
                                           wire:model.live="filtroFechaRecibido"
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b">
                                    <input type="date" 
                                           wire:model.live="filtroFechaExpiracion"
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent">
                                </th>
                                <th class="px-2 py-2 border-b"></th>
                                <th class="px-2 py-2 border-b"></th>
                                <th class="px-2 py-2 border-b"></th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productosRecibidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50 <?php echo e($item->cantidad_disponible > 10 ? 'bg-green-50' : ($item->cantidad_disponible > 0 ? 'bg-yellow-50' : 'bg-red-50')); ?>">

                                    <!-- Código de Producto -->
                                    <td class="px-4 py-3 border-b">
                                        <code class="px-2 py-1 text-sm font-semibold text-blue-700 bg-blue-100 rounded"><?php echo e($item->producto_id ?? 'N/A'); ?></code>
                                    </td>

                                    <!-- Producto -->
                                    <td class="px-4 py-3 border-b">
                                        <div class="flex flex-col">
                                            <span class="font-semibold text-gray-900"><?php echo e($item->producto_nombre); ?></span>
                                            <!--[if BLOCK]><![endif]--><?php if($item->producto_descripcion): ?>
                                                <small class="text-gray-500"><?php echo e(Str::limit($item->producto_descripcion, 30)); ?></small>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </td>

                                    <!-- Código de Barras -->
                                    <td class="px-4 py-3 border-b">
                                        <code class="px-2 py-1 text-sm bg-gray-100 rounded"><?php echo e($item->codigo_barra ?? 'N/A'); ?></code>
                                    </td>

                                    <!-- Marca -->
                                    <td class="px-4 py-3 text-gray-700 border-b">
                                        <?php echo e($item->marca_nombre ?? 'Sin marca'); ?>

                                    </td>

                                    <!-- Bodega -->
                                    <td class="px-4 py-3 border-b">
                                        <div class="flex flex-col">
                                            <span class="font-semibold text-gray-900"><?php echo e($item->bodega_nombre); ?></span>
                                            <small class="text-gray-500"><?php echo e($item->tienda_nombre); ?></small>
                                        </div>
                                    </td>

                                    <!-- Segmento -->
                                    <td class="px-4 py-3 text-gray-700 border-b">
                                        <?php echo e($item->segmento_descripcion ?? 'N/A'); ?>

                                    </td>

                                    <!-- Sección -->
                                    <td class="px-4 py-3 text-gray-700 border-b">
                                        <?php echo e($item->seccion_descripcion ?? 'N/A'); ?>

                                    </td>

                                    <!-- Stock -->
                                    <td class="px-4 py-3 text-center border-b">
                                        <span class="font-bold <?php echo e($item->cantidad_disponible > 10 ? 'text-green-600' : ($item->cantidad_disponible > 0 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                            <?php echo e(number_format($item->cantidad_disponible, 0)); ?>

                                        </span>
                                        <div class="text-xs text-gray-500"><?php echo e($item->unidad_medida ?? 'Unidad'); ?></div>
                                    </td>

                                    <!-- Fecha Recibido -->
                                    <td class="px-4 py-3 text-sm text-center text-gray-600 border-b">
                                        <?php echo e(\Carbon\Carbon::parse($item->fecha_recibido)->format('d/m/Y')); ?>

                                    </td>

                                    <!-- Fecha Expiración -->
                                    <td class="px-4 py-3 text-sm text-center border-b">
                                        <!--[if BLOCK]><![endif]--><?php if($item->fecha_expiracion): ?>
                                            <?php
                                                $fechaExpiracion = \Carbon\Carbon::parse($item->fecha_expiracion);
                                                $diasRestantes = $fechaExpiracion->diffInDays(now(), false);
                                            ?>
                                            <span class="<?php echo e($diasRestantes > 30 ? 'text-green-600' : ($diasRestantes > 7 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                                <?php echo e($fechaExpiracion->format('d/m/Y')); ?>

                                                <!--[if BLOCK]><![endif]--><?php if($diasRestantes <= 30): ?>
                                                    <div class="text-xs">(<?php echo e(abs($diasRestantes)); ?> días)</div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">N/A</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <!-- Estado -->
                                    <td class="px-4 py-3 text-center border-b">
                                        <!--[if BLOCK]><![endif]--><?php if($item->cantidad_disponible > 10): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold text-white bg-green-500 rounded-full">Disponible</span>
                                        <?php elseif($item->cantidad_disponible > 0): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold text-white bg-yellow-500 rounded-full">Poco Stock</span>
                                        <?php else: ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold text-white bg-red-500 rounded-full">Agotado</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <!-- Comentario -->
                                    <td class="px-4 py-3 text-sm border-b">
                                        <!--[if BLOCK]><![endif]--><?php if($item->comentario): ?>
                                            <span title="<?php echo e($item->comentario); ?>" class="text-gray-700"><?php echo e(Str::limit($item->comentario, 20)); ?></span>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>

                                    <!-- Acciones -->
                                    <td class="px-4 py-3 text-center border-b" x-data="{ open: false }">
                                        <div class="relative inline-block text-left">
                                            <button @click="open = !open"
                                                    @click.away="open = false"
                                                    type="button"
                                                    class="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                                </svg>
                                            </button>

                                            <!-- Dropdown Menu -->
                                            <div x-show="open"
                                                 x-transition:enter="transition ease-out duration-100"
                                                 x-transition:enter-start="transform opacity-0 scale-95"
                                                 x-transition:enter-end="transform opacity-100 scale-100"
                                                 x-transition:leave="transition ease-in duration-75"
                                                 x-transition:leave-start="transform opacity-100 scale-100"
                                                 x-transition:leave-end="transform opacity-0 scale-95"
                                                 class="absolute right-0 z-10 w-48 mt-2 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
                                                 style="display: none;">
                                                <div class="py-1">
                                                    <button wire:click="editarProducto(<?php echo e($item->producto_id); ?>)"
                                                            @click="open = false"
                                                            class="flex items-center w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 hover:text-gray-900">
                                                        <svg class="w-4 h-4 mr-3 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                                        </svg>
                                                        Editar Producto
                                                    </button>
                                                    <button wire:click="editarStock(<?php echo e($item->id); ?>)"
                                                            @click="open = false"
                                                            class="flex items-center w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 hover:text-gray-900">
                                                        <svg class="w-4 h-4 mr-3 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                                                        </svg>
                                                        Traslados o regalías
                                                    </button>
                                                    <button wire:click="abrirModalCambiarUnidad(<?php echo e($item->id); ?>)"
                                                            @click="open = false"
                                                            class="flex items-center w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 hover:text-gray-900">
                                                        <svg class="w-4 h-4 mr-3 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                                                        </svg>
                                                        Cambiar unidad
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="py-12 text-center">
                    <div class="flex flex-col items-center">
                        <svg class="w-16 h-16 mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-4.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 009.586 13H7"></path>
                        </svg>
                        <span class="text-xl font-medium text-gray-500">No hay productos recibidos en bodega</span>
                        <small class="mt-1 text-gray-400">Los productos aparecerán aquí cuando sean distribuidos a las bodegas</small>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- PAGINACIÓN PERSONALIZADA CON SELECTOR -->
            <div class="mt-4">
                <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->hasPages()): ?>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-4">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($productosRecibidos->firstItem()); ?> to <?php echo e($productosRecibidos->lastItem()); ?> of <?php echo e($productosRecibidos->total()); ?> results
                            </div>
                            <div class="flex items-center gap-2">
                                <label class="text-sm text-gray-600">Show:</label>
                                <select wire:model.live="registrosPorPagina" class="px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                        </div>
                        <div class="flex space-x-1">
                            
                            <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->onFirstPage()): ?>
                                <span class="px-3 py-2 text-sm text-gray-400 bg-gray-200 border border-gray-300 rounded cursor-not-allowed">Previous</span>
                            <?php else: ?>
                                <button wire:click="previousPage" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50">Previous</button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <?php
                                $currentPage = $productosRecibidos->currentPage();
                                $lastPage = $productosRecibidos->lastPage();
                                $start = max(1, min($currentPage - 2, $lastPage - 4));
                                $end = min($start + 4, $lastPage);
                            ?>

                            <!--[if BLOCK]><![endif]--><?php for($page = $start; $page <= min($end, $lastPage); $page++): ?>
                                <!--[if BLOCK]><![endif]--><?php if($page == $currentPage): ?>
                                    <span class="px-3 py-2 text-sm font-medium text-blue-600 border border-blue-300 rounded bg-blue-50"><?php echo e($page); ?></span>
                                <?php else: ?>
                                    <button wire:click="gotoPage(<?php echo e($page); ?>)" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50"><?php echo e($page); ?></button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <!--[if BLOCK]><![endif]--><?php if($end < $lastPage): ?>
                                <!--[if BLOCK]><![endif]--><?php if($end < $lastPage - 1): ?>
                                    <span class="px-3 py-2 text-sm text-gray-400">...</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <button wire:click="gotoPage(<?php echo e($lastPage); ?>)" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50"><?php echo e($lastPage); ?></button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <!--[if BLOCK]><![endif]--><?php if($productosRecibidos->hasMorePages()): ?>
                                <button wire:click="nextPage" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50">Next</button>
                            <?php else: ?>
                                <span class="px-3 py-2 text-sm text-gray-400 bg-gray-200 border border-gray-300 rounded cursor-not-allowed">Next</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                <?php else: ?>
                    <div class="flex items-center gap-4">
                        <div class="text-sm text-gray-700">
                            Showing <?php echo e($productosRecibidos->firstItem() ?? 0); ?> to <?php echo e($productosRecibidos->lastItem() ?? 0); ?> of <?php echo e($productosRecibidos->total()); ?> results
                        </div>
                        <div class="flex items-center gap-2">
                            <label class="text-sm text-gray-600">Show:</label>
                            <select wire:model.live="registrosPorPagina" class="px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalCambiarUnidad): ?>
        <div class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
            <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" wire:click="cerrarModalCambiarUnidad"></div>

                <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

                <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                        <div class="sm:flex sm:items-start">
                            <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-purple-100 sm:mx-0 sm:h-10 sm:w-10">
                                <svg class="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                                </svg>
                            </div>
                            <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                                <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                    Cambiar Unidad de Medida
                                </h3>
                                <div class="mt-4">
                                    <!--[if BLOCK]><![endif]--><?php if($stockSeleccionado): ?>
                                        <div class="grid grid-cols-1 gap-4">
                                            
                                            <div class="bg-gray-50 p-3 rounded-lg">
                                                <h4 class="font-medium text-gray-900 mb-2">Stock Actual</h4>
                                                <p class="text-sm text-gray-600">
                                                    <strong>Producto:</strong> <?php echo e($stockSeleccionado->producto->nombre ?? 'N/A'); ?>

                                                </p>
                                                <p class="text-sm text-gray-600">
                                                    <strong>Cantidad disponible total:</strong> <?php echo e($cantidadTotalDisponible ?? 0); ?>

                                                </p>
                                                <p class="text-sm text-gray-600">
                                                    <strong>Unidad actual:</strong>
                                                    <!--[if BLOCK]><![endif]--><?php if($stockSeleccionado->unidad_medida): ?>
                                                        <?php echo e($stockSeleccionado->unidad_medida); ?>

                                                    <?php elseif($stockSeleccionado->unidadMedida): ?>
                                                        <?php echo e($stockSeleccionado->unidadMedida->nombre); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </p>
                                                <p class="text-sm text-gray-600">
                                                    <strong>Ubicación:</strong>
                                                    <!--[if BLOCK]><![endif]--><?php if($stockSeleccionado->seccion && $stockSeleccionado->seccion->segmento && $stockSeleccionado->seccion->segmento->bodega): ?>
                                                        <?php echo e($stockSeleccionado->seccion->segmento->bodega->nombre ?? 'N/A'); ?> /
                                                        <?php echo e($stockSeleccionado->seccion->segmento->descripcion ?? 'N/A'); ?> /
                                                        <?php echo e($stockSeleccionado->seccion->descripcion ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </p>
                                            </div>

                                            
                                            <div class="space-y-4">
                                                
                                                <div>
                                                    <label class="block text-sm font-medium text-gray-700 mb-1">
                                                        Cantidad a rebajar
                                                        <span class="text-red-500">*</span>
                                                    </label>
                                                    <input type="number"
                                                           wire:model.live="cantidadVerificacion"
                                                           step="0.01"
                                                           min="0.01"
                                                           max="<?php echo e($cantidadTotalDisponible); ?>"
                                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                                           placeholder="Ingrese la cantidad a rebajar (máx: <?php echo e($cantidadTotalDisponible); ?>)">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['cantidadVerificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                    <!--[if BLOCK]><![endif]--><?php if($cantidadVerificacion > $cantidadTotalDisponible): ?>
                                                        <div class="mt-1 text-xs text-red-600">
                                                            ⚠️ La cantidad no puede exceder <?php echo e($cantidadTotalDisponible); ?>

                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>

                                                
                                                <div>
                                                    <label class="block text-sm font-medium text-gray-700 mb-1">
                                                        Unidad de medida a convertir
                                                        <span class="text-red-500">*</span>
                                                    </label>
                                                    <select wire:model="nuevaUnidadMedida"
                                                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                                                        <option value="">Seleccione una unidad</option>
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $unidadesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($unidad['nombre']); ?>"><?php echo e($unidad['nombre']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </select>
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevaUnidadMedida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>

                                                
                                                <div>
                                                    <label class="block text-sm font-medium text-gray-700 mb-1">
                                                        Cantidad a convertir
                                                        <span class="text-red-500">*</span>
                                                    </label>
                                                    <input type="number"
                                                           wire:model.live="cantidadAConvertir"
                                                           step="0.01"
                                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                                                           placeholder="Ingrese la cantidad a convertir">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['cantidadAConvertir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                        <button type="button"
                                wire:click="procesarCambioUnidad"
                                wire:loading.attr="disabled"
                                wire:target="procesarCambioUnidad"
                                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-purple-600 text-base font-medium text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed">
                            <span wire:loading.remove wire:target="procesarCambioUnidad">Procesar Cambio</span>
                            <span wire:loading wire:target="procesarCambioUnidad" class="flex items-center">
                                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Procesando...
                            </span>
                        </button>
                        <button type="button"
                                wire:click="cerrarModalCambiarUnidad"
                                wire:loading.attr="disabled"
                                wire:target="procesarCambioUnidad"
                                class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed">
                            Cancelar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div> 
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/lista-de-productos.blade.php ENDPATH**/ ?>