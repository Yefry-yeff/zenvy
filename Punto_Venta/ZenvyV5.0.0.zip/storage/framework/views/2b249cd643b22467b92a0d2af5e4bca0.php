<table>
    <thead>
        <tr>
            <th colspan="10" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #4472C4; color: white;">
                📦 LISTADO DE PRODUCTOS RECIBIDOS EN BODEGA
            </th>
        </tr>
        <tr>
            <th colspan="10" style="font-size: 12px; text-align: center; color: #666;">
                Sistema ZENVY - Gestión de Inventario
            </th>
        </tr>
        <tr><th colspan="10"></th></tr>
        <tr>
            <th colspan="10" style="font-size: 10px; text-align: center; background-color: #F8F9FA;">
                📅 Generado el: <?php echo e($fechaGeneracion); ?> | 👤 Usuario: <?php echo e($usuarioReporte ?? '-'); ?> | 📊 Total: <?php echo e($totalProductos); ?> productos | 🔍 Filtros: <?php echo e($filtrosAplicados); ?>

            </th>
        </tr>
        <tr>
            <th style="background:#4472C4;color:#fff;">#</th>
            <th style="background:#4472C4;color:#fff;">ID Producto</th>
            <th style="background:#4472C4;color:#fff;">Producto</th>
            <th style="background:#4472C4;color:#fff;">Código de Barras</th>
            <th style="background:#4472C4;color:#fff;">Marca</th>
            <th style="background:#4472C4;color:#fff;">Bodega</th>
            <th style="background:#4472C4;color:#fff;">Estado</th>
            <th style="background:#4472C4;color:#fff;">Cantidad</th>
            <th style="background:#4472C4;color:#fff;">Unidad</th>
            <th style="background:#4472C4;color:#fff;">Fecha recibido</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i+1); ?></td>
            <td><?php echo e($producto->producto_id ?? '-'); ?></td>
            <td><?php echo e($producto->producto_nombre ?? '-'); ?></td>
            <td><?php echo e(isset($producto->codigo_barra) && $producto->codigo_barra !== '' ? "'" . $producto->codigo_barra : '-'); ?></td>
            <td><?php echo e($producto->marca_nombre ?? '-'); ?></td>
            <td><?php echo e($producto->bodega_nombre ?? '-'); ?></td>
            <td>
                <?php if(isset($producto->cantidad_disponible)): ?>
                    <?php if($producto->cantidad_disponible > 10): ?>
                        Disponible
                    <?php elseif($producto->cantidad_disponible > 0): ?>
                        Poco stock
                    <?php else: ?>
                        Agotado
                    <?php endif; ?>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td><?php echo e($producto->cantidad_disponible ?? 0); ?></td>
            <td><?php echo e($producto->unidad_medida ?? '-'); ?></td>
            <td><?php echo e($producto->fecha_recibido ? \Carbon\Carbon::parse($producto->fecha_recibido)->format('d/m/Y') : '-'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/exports/lista-de-productos.blade.php ENDPATH**/ ?>