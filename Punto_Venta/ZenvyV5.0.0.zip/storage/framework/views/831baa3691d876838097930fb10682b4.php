<div class="container-fluid p-4" x-data="{ ejemplosAbierto: false, cargando: <?php if ((object) ('cargando') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('cargando'->value()); ?>')<?php echo e('cargando'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('cargando'); ?>')<?php endif; ?> }"
    x-init="$watch('cargando', value => { if (!value) { setTimeout(() => { const el = document.getElementById('resultado-reporte'); if (el) el.scrollIntoView({behavior: 'smooth', block: 'start'}); }, 200); } })">
    <style>
        .markdown-content {
            font-size: 15px;
            line-height: 1.6;
        }

        .markdown-content h1,
        .markdown-content h2,
        .markdown-content h3 {
            margin-top: 1rem;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }

        .markdown-content table {
            width: 100%;
            margin: 1rem 0;
            border-collapse: collapse;
        }

        .markdown-content table th,
        .markdown-content table td {
            padding: 8px 12px;
            border: 1px solid #dee2e6;
        }

        .markdown-content table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }

        .markdown-content pre {
            background-color: #f8f9fa;
            padding: 1rem;
            border-radius: 4px;
            overflow-x: auto;
        }

        .markdown-content code {
            background-color: #f8f9fa;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }

        .markdown-content ul,
        .markdown-content ol {
            padding-left: 2rem;
        }

        /* Animación de carga personalizada */
        .loading-dots {
            display: inline-flex;
            gap: 4px;
        }

        .loading-dots span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #0d6efd;
            animation: bounce 1.4s infinite ease-in-out both;
        }

        .loading-dots span:nth-child(1) {
            animation-delay: -0.32s;
        }

        .loading-dots span:nth-child(2) {
            animation-delay: -0.16s;
        }

        @keyframes bounce {
            0%, 80%, 100% {
                transform: scale(0);
            }
            40% {
                transform: scale(1);
            }
        }

        .pulse-animation {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }

        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: .5;
            }
        }
    </style>

    <div class="row">
        <!-- Panel Principal -->
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">
                        <i class="fas fa-robot me-2"></i>
                        Reportes con Inteligencia Artificial
                    </h4>
                    <small>Genera reportes personalizados usando lenguaje natural</small>
                </div>
                <div class="card-body">
                    <!-- Área de Consulta -->
                    <div class="mb-4">
                        <label for="prompt" class="form-label fw-bold">¿Qué deseas saber?</label>
                        <textarea
                            wire:model="prompt"
                            id="prompt"
                            class="form-control <?php $__errorArgs = ['prompt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            rows="4"
                            placeholder="Ejemplo: Dame un reporte de las ventas del último mes agrupadas por día"
                            <?php if($cargando): ?> disabled <?php endif; ?>
                        ></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['prompt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Botones de Acción -->
                    <div class="d-flex gap-2 mb-4">
                        <button
                            wire:click="generarReporte"
                            class="btn btn-primary d-inline-flex align-items-center"
                            wire:loading.attr="disabled"
                            wire:target="generarReporte"
                        >
                            <span wire:loading.remove wire:target="generarReporte">
                                <i class="fas fa-magic me-2"></i>
                                Generar Reporte
                            </span>
                            <span wire:loading wire:target="generarReporte">
                                <svg class="me-2" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
                                </svg>
                                Generando...
                            </span>
                        </button>
                        <button
                            wire:click="limpiar"
                            class="btn btn-outline-secondary"
                            wire:loading.attr="disabled"
                            wire:target="generarReporte"
                        >
                            <i class="fas fa-eraser me-2"></i>
                            Limpiar
                        </button>
                    </div>

                    <!-- Indicador de Carga -->
                    <!--[if BLOCK]><![endif]--><?php if($cargando): ?>
                        <div class="card border-primary shadow-sm mb-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="spinner-border text-primary me-3" role="status" style="width: 3rem; height: 3rem;">
                                        <span class="visually-hidden">Cargando...</span>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h5 class="mb-2">
                                            <strong>Generando tu reporte</strong>
                                            <span class="loading-dots ms-2">
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                            </span>
                                        </h5>
                                        <p class="mb-1 text-muted">
                                            <i class="fas fa-brain me-2"></i>
                                            La IA está analizando tu consulta
                                        </p>
                                        <p class="mb-0 text-muted">
                                            <i class="fas fa-database me-2"></i>
                                            Obteniendo datos de la base de datos
                                        </p>
                                    </div>
                                </div>
                                <div class="progress mt-3" style="height: 4px;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                         role="progressbar" 
                                         style="width: 100%"
                                         aria-valuenow="100" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Ejemplos de Consultas (Desplegable) -->
                    <div class="card mb-4 border-info">
                        <div class="card-header bg-light border-bottom cursor-pointer" @click="ejemplosAbierto = !ejemplosAbierto" style="cursor: pointer;">
                            <h6 class="mb-0">
                                <i class="fas" :class="ejemplosAbierto ? 'fa-chevron-up' : 'fa-chevron-down'" style="transition: transform 0.3s;"></i>
                                <strong>Ejemplos de consultas (con tablas descargables)</strong>
                            </h6>
                        </div>
                        <div x-show="ejemplosAbierto" x-transition class="card-body">
                            <div class="row">
                                <!-- Ejemplos sugeridos -->
                                <div class="col-md-6 mb-3">
                                    <h6 class="fw-bold text-secondary mb-2">Sugerencias:</h6>
                                    <div class="list-group list-group-sm">
                                        <a href="#" class="list-group-item list-group-item-action small" wire:click.prevent="$set('prompt', 'Dame los productos más vendidos del último mes con sus cantidades')">
                                            📊 Productos más vendidos
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action small" wire:click.prevent="$set('prompt', 'Muestra las ventas del día de hoy con detalle')">
                                            💰 Ventas de hoy
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action small" wire:click.prevent="$set('prompt', 'Lista los clientes con más compras este año')">
                                            👥 Clientes frecuentes
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action small" wire:click.prevent="$set('prompt', '¿Qué productos tienen stock bajo? Muestra una tabla')">
                                            ⚠️ Stock bajo
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action small" wire:click.prevent="$set('prompt', 'Reporte de ventas por método de pago de esta semana')">
                                            💳 Ventas por pago
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action small" wire:click.prevent="$set('prompt', 'Top 20 productos por ingresos generados')">
                                            🏆 Top productos
                                        </a>
                                    </div>
                                </div>
                                <!-- Consultas más frecuentes -->
                                <div class="col-md-6 mb-3">
                                    <!--[if BLOCK]><![endif]--><?php if(count($topConsultas) > 0): ?>
                                        <h6 class="fw-bold text-secondary mb-2">Más frecuentes:</h6>
                                        <div class="list-group list-group-sm">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $topConsultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="#" class="list-group-item list-group-item-action small d-flex justify-content-between align-items-center" wire:click.prevent="$set('prompt', '<?php echo e($top->pregunta); ?>')">
                                                    <span class="text-truncate" style="max-width: 150px;"><?php echo e($top->pregunta); ?></span>
                                                    <span class="badge bg-secondary"><?php echo e($top->total); ?></span>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <small class="text-muted d-block mt-2">
                                💡 <strong>Tip:</strong> Los reportes se generan automáticamente como tablas y puedes descargarlos en Excel
                            </small>
                        </div>
                    </div>

                    <!-- Mensaje de Error -->
                    <!--[if BLOCK]><![endif]--><?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo e($error); ?>

                            <button type="button" class="btn-close" wire:click="$set('error', '')"></button>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Respuesta de la AI -->
                    <!--[if BLOCK]><![endif]--><?php if($respuesta && !$cargando): ?>
                        <div class="card border-success mt-4" id="resultado-reporte">
                            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="fas fa-check-circle me-2"></i>
                                    Resultado
                                </h5>
                                <!--[if BLOCK]><![endif]--><?php if($datosTabla): ?>
                                    <button wire:click="descargarExcel" class="btn btn-light btn-sm">
                                        <i class="fas fa-file-excel me-1"></i>
                                        Descargar Excel
                                    </button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="card-body">
                                <!-- Solo mostrar respuesta si hay texto además del SQL -->
                                <?php
                                    $textoSinSql = preg_replace('/```sql.*?```/s', '', $respuesta);
                                    $markdownHtml = \Illuminate\Support\Str::markdown($textoSinSql);
                                    // Eliminar cualquier tabla generada por Markdown para mostrar sólo la tabla resultante desde la consulta
                                    $markdownSinTablas = preg_replace('/<table.*?>.*?<\/table>/is', '', $markdownHtml);
                                ?>

                                <!--[if BLOCK]><![endif]--><?php if(trim(strip_tags($markdownSinTablas))): ?>
                                    <div class="markdown-content mb-3">
                                        <?php echo $markdownSinTablas; ?>

                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <!-- Tabla de Datos si existe -->
                                <!--[if BLOCK]><![endif]--><?php if($datosTabla && count($datosTabla) > 0): ?>
                                    <div>
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h6 class="text-primary mb-0">
                                                <i class="fas fa-table me-2"></i>
                                                <?php echo e(count($datosTabla)); ?> registro<?php echo e(count($datosTabla) != 1 ? 's' : ''); ?> encontrado<?php echo e(count($datosTabla) != 1 ? 's' : ''); ?>

                                            </h6>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover table-bordered table-sm">
                                                <thead class="table-dark">
                                                    <tr>
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = array_keys($datosTabla[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $columna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th class="text-nowrap"><?php echo e(ucfirst(str_replace('_', ' ', $columna))); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        // Calcular paginación
                                                        $totalFilas = count($datosTabla);
                                                        $totalPaginas = ceil($totalFilas / $filasPerPagina);
                                                        $inicio = ($paginaActual - 1) * $filasPerPagina;
                                                        $datosActuales = array_slice($datosTabla, $inicio, $filasPerPagina);
                                                    ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $datosActuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td>
                                                                    <!--[if BLOCK]><![endif]--><?php if(is_numeric($valor) && !is_string($valor)): ?>
                                                                        <?php echo e(number_format($valor, 2)); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($valor); ?>

                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                </td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </tbody>
                                            </table>
                                        </div>

                                        <!--[if BLOCK]><![endif]--><?php if($totalPaginas > 1): ?>
                                            <nav aria-label="Page navigation" class="mt-3">
                                                <ul class="pagination pagination-sm justify-content-center">
                                                    <li class="page-item <?php echo e($paginaActual == 1 ? 'disabled' : ''); ?>">
                                            <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

                                                        <button wire:click="$set('paginaActual', 1)" class="page-link">Primera</button>
                                                    </li>
                                                    <li class="page-item <?php echo e($paginaActual == 1 ? 'disabled' : ''); ?>">
                                                        <button wire:click="$set('paginaActual', <?php echo e($paginaActual - 1); ?>)" class="page-link">Anterior</button>
                                                    </li>

                                                    <?php for($i = 1; $i <= $totalPaginas; $i++): ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($i == 1 || $i == $totalPaginas || ($i >= $paginaActual - 1 && $i <= $paginaActual + 1)): ?>
                                                            <!--[if BLOCK]><![endif]--><?php if($i == $paginaActual - 2 || $i == $paginaActual + 2): ?>
                                                                <li class="page-item disabled"><span class="page-link">...</span></li>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <li class="page-item <?php echo e($i == $paginaActual ? 'active' : ''); ?>">
                                                                <button wire:click="$set('paginaActual', <?php echo e($i); ?>)" class="page-link"><?php echo e($i); ?></button>
                                                            </li>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

                                                    <li class="page-item <?php echo e($paginaActual == $totalPaginas ? 'disabled' : ''); ?>">
                                                        <button wire:click="$set('paginaActual', <?php echo e($paginaActual + 1); ?>)" class="page-link">Siguiente</button>
                                                    </li>
                                                    <li class="page-item <?php echo e($paginaActual == $totalPaginas ? 'disabled' : ''); ?>">
                                                        <button wire:click="$set('paginaActual', <?php echo e($totalPaginas); ?>)" class="page-link">Última</button>
                                                    </li>
                                                </ul>
                                            </nav>

                                            <div class="text-center text-muted small mt-2">
                                                Página <?php echo e($paginaActual); ?> de <?php echo e($totalPaginas); ?> | Mostrando <?php echo e(count($datosActuales)); ?> de <?php echo e($totalFilas); ?> registros
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                <?php elseif(!$datosTabla): ?>
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        <?php echo \Illuminate\Support\Str::markdown($respuesta); ?>

                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        No se encontraron datos para esta consulta.
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <!-- Panel de Historial -->
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-history me-2"></i>
                        Historial de Consultas
                    </h5>
                </div>
                <div class="card-body p-0">
                    <!--[if BLOCK]><![endif]--><?php if(count($historial) > 0): ?>
                        <div class="list-group list-group-flush">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a
                                    href="#"
                                    wire:click.prevent="usarHistorial(<?php echo e($consulta->id); ?>)"
                                    class="list-group-item list-group-item-action"
                                >
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1 text-truncate" style="max-width: 250px;">
                                            <?php echo e(\Illuminate\Support\Str::limit($consulta->pregunta, 50)); ?>

                                        </h6>
                                        <small class="text-muted">
                                            <?php echo e(\Carbon\Carbon::parse($consulta->created_at)->diffForHumans()); ?>

                                        </small>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <div class="p-4 text-center text-muted">
                            <i class="fas fa-inbox fa-3x mb-3"></i>
                            <p>No hay consultas previas</p>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <!-- Tarjeta de Configuración (Solo para Admins) -->
            <!--[if BLOCK]><![endif]--><?php if($isAdmin): ?>
                <div class="card shadow-sm mt-3">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0">
                            <i class="fas fa-cog me-2"></i>
                            Configuración
                        </h6>
                    </div>
                    <div class="card-body">
                        <p class="small mb-2">
                            <strong>API:</strong> Groq (Gemma 7B)
                        </p>
                        <p class="small mb-2">
                            <strong>Estado:</strong>
                            <!--[if BLOCK]><![endif]--><?php if(env('GROQ_API_KEY')): ?>
                                <span class="badge bg-success">Configurado</span>
                            <?php else: ?>
                                <span class="badge bg-danger">No configurado</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </p>
                        <!--[if BLOCK]><![endif]--><?php if(!env('GROQ_API_KEY')): ?>
                            <hr>
                            <div class="alert alert-warning small mb-0">
                                <strong>Configuración requerida:</strong>
                                <ol class="mb-0 ps-3">
                                    <li>Visita <a href="https://console.groq.com" target="_blank">console.groq.com</a></li>
                                    <li>Crea una cuenta gratuita</li>
                                    <li>Genera una API Key</li>
                                    <li>Agrega en .env:<br>
                                        <code>GROQ_API_KEY=tu_key_aqui</code>
                                    </li>
                                </ol>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>

<!-- Scroll automático manejado por Alpine (no hay scripts vanilla adicionales) -->
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/reporte/ai.blade.php ENDPATH**/ ?>