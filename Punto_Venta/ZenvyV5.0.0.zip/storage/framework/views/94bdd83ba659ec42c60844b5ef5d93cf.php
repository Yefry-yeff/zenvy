<div>
    <!-- MENSAJES DE SESIÓN -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>✅ Éxito:</strong> <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>⚠️ Advertencia:</strong> <?php echo e(session('warning')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>❌ Error:</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- CONTENEDOR PRINCIPAL OPTIMIZADO -->
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">📦 Gestión de Productos</h5>
            <div class="flex gap-2">
                <button wire:click="sincronizarProductosValencia"
                    class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-orange-200 rounded hover:bg-orange-300 disabled:opacity-50"
                    wire:loading.attr="disabled"
                    wire:target="sincronizarProductosValencia">
                    <span wire:loading.remove wire:target="sincronizarProductosValencia">🔄</span>
                    <span wire:loading wire:target="sincronizarProductosValencia">
                        <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </span>
                    <span wire:loading.remove wire:target="sincronizarProductosValencia">Sincronizar</span>
                    <span wire:loading wire:target="sincronizarProductosValencia">Sincronizando...</span>
                </button>

                <button wire:click="abrirModalCrear"
                    class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                    <span>➕</span> Nuevo Producto
                </button>

                <!-- Botones de descarga -->
                <!-- Botón de descarga de reporte (Excel) junto al filtro de Origen -->
                <!-- ...existing code... -->
            </div>
        </div>

        <!-- BARRA DE PROGRESO -->
        <!--[if BLOCK]><![endif]--><?php if($sincronizandoValencia): ?>
        <div class="px-5 py-3 bg-blue-50">
            <div class="mb-2">
                <div class="flex justify-between text-sm">
                    <span class="font-medium text-blue-700">Sincronizando productos de Valencia...</span>
                    <span class="text-blue-600"><?php echo e($progreso); ?>%</span>
                </div>
            </div>
            <div class="w-full h-2 bg-blue-200 rounded-full">
                <div class="h-2 transition-all duration-500 ease-out bg-blue-600 rounded-full"
                     style="width: <?php echo e($progreso); ?>%"></div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- FILTROS Y BÚSQUEDA -->
        <div class="px-4 py-3 border-b bg-gray-50">
            <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
                <!-- Búsqueda -->
                <div class="md:col-span-2">
                    <label class="block mb-1 text-sm font-medium text-gray-700">Buscar</label>
                    <input type="text"
                           wire:model.live.debounce.300ms="buscar"
                           placeholder="Buscar por nombre, código o descripción..."
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Filtro de Origen -->
                <div class="flex items-end gap-2">
                    <div class="flex-1">
                        <label class="block mb-1 text-sm font-medium text-gray-700">Origen</label>
                        <select wire:model.live="filtroOrigen" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            <option value="todos">Todos</option>
                            <option value="paperland">🏠 Paperland</option>
                            <option value="valencia">🏢 Valencia</option>
                        </select>
                    </div>
                    <button wire:click="descargarExcel"
                        class="inline-flex items-center gap-1 px-3 py-2 text-sm text-white bg-green-600 rounded hover:bg-green-700 disabled:opacity-50"
                        wire:loading.attr="disabled"
                        wire:target="descargarExcel"
                        title="Descargar reporte">
                        <span wire:loading.remove wire:target="descargarExcel">📥</span>
                        <span wire:loading wire:target="descargarExcel">
                            <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </span>
                        <span wire:loading.remove wire:target="descargarExcel">Descargar reporte</span>
                        <span wire:loading wire:target="descargarExcel">Generando...</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- INFORMACIÓN DE RESULTADOS -->
        <div class="px-4 py-2 bg-gray-100 border-b">
            <div class="text-sm text-gray-600">
                Showing <?php echo e($productos->firstItem() ?? 0); ?> to <?php echo e($productos->lastItem() ?? 0); ?>

                of <?php echo e($productos->total()); ?> results
                <!--[if BLOCK]><![endif]--><?php if($buscar): ?>
                    | Filtrado por: "<?php echo e($buscar); ?>"
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!-- TABLA OPTIMIZADA -->
        <div class="px-4 py-3">
            <div class="overflow-x-auto">
                <table class="min-w-full border border-gray-200 table-auto">
                        <thead class="bg-gray-50">
                            <!-- Encabezados con ordenamiento -->
                            <tr>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('id')">
                                    <div class="flex items-center space-x-1">
                                        <span>Código Producto</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'id'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('nombre')">
                                    <div class="flex items-center space-x-1">
                                        <span>Producto</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'nombre'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b">
                                    <div class="flex items-center space-x-1">
                                        <span>Código de Barras</span>
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b">
                                    <div class="flex items-center space-x-1">
                                        <span>Unidad de Medida</span>
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('subcategoria_id')">
                                    <div class="flex items-center space-x-1">
                                        <span>Categoría</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'subcategoria_id'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-left border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('marca_id')">
                                    <div class="flex items-center space-x-1">
                                        <span>Marca</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'marca_id'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-center border-b cursor-pointer hover:bg-gray-100"
                                    wire:click="ordenar('producto_valencia')">
                                    <div class="flex items-center justify-center space-x-1">
                                        <span>Origen</span>
                                        <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'producto_valencia'): ?>
                                            <span class="text-blue-500">
                                                <!--[if BLOCK]><![endif]--><?php if($direccionOrden === 'asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </th>
                                <th class="px-4 py-3 text-center border-b">Acciones</th>
                            </tr>
                            <!-- Fila de filtros -->
                            <tr class="bg-gray-100">
                                <th class="px-4 py-2 border-b">
                                    <input type="text"
                                           wire:model.live.debounce.300ms="filtroId"
                                           placeholder="Filtrar ID..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                </th>
                                <th class="px-4 py-2 border-b">
                                    <input type="text"
                                           wire:model.live.debounce.300ms="filtroNombre"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                </th>
                                <th class="px-4 py-2 border-b">
                                    <input type="text"
                                           wire:model.live.debounce.300ms="filtroCodigoBarras"
                                           placeholder="Filtrar código..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                </th>
                                <th class="px-4 py-2 border-b">
                                    <input type="text"
                                           wire:model.live.debounce.300ms="filtroUnidadMedida"
                                           placeholder="Filtrar unidad..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                </th>
                                    <input type="text"
                                           wire:model.live.debounce.300ms="filtroCategoria"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                </th>
                                <th class="px-4 py-2 border-b">
                                    <input type="text"
                                           wire:model.live.debounce.300ms="filtroMarca"
                                           placeholder="Filtrar..."
                                           class="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-blue-500">
                                </th>
                                <th class="px-4 py-2 border-b">
                                    <!-- Sin filtro para origen -->
                                </th>
                                <th class="px-4 py-2 border-b">
                                    <!-- Sin filtro para acciones -->
                                </th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php if($productos->count() > 0): ?>
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $numPresentaciones = !empty($producto->presentaciones) ? count($producto->presentaciones) : 1;
                                        $primeraPresentacion = true;
                                    ?>
                                    
                                    <!--[if BLOCK]><![endif]--><?php if(!empty($producto->presentaciones) && count($producto->presentaciones) > 0): ?>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $producto->presentaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $presentacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="transition-colors duration-150 cursor-pointer hover:bg-gray-50"
                                            wire:key="producto-<?php echo e($producto->id); ?>-presentacion-<?php echo e($index); ?>">
                                            <!--[if BLOCK]><![endif]--><?php if($index === 0): ?>
                                                <!-- Código del Producto (ID) - solo en primera fila -->
                                                <td class="px-4 py-3 text-sm font-semibold text-gray-900 border-r" 
                                                    rowspan="<?php echo e($numPresentaciones); ?>"
                                                    wire:click="editar(<?php echo e($producto->id); ?>)">
                                                    #<?php echo e($producto->id); ?>

                                                </td>
                                                <!-- Producto - solo en primera fila -->
                                                <td class="px-4 py-3 border-r" 
                                                    rowspan="<?php echo e($numPresentaciones); ?>"
                                                    wire:click="editar(<?php echo e($producto->id); ?>)">
                                                    <div>
                                                        <div class="font-medium text-gray-900"><?php echo e($producto->nombre); ?></div>
                                                        <!--[if BLOCK]><![endif]--><?php if($producto->descripcion): ?>
                                                            <div class="max-w-xs text-sm text-gray-500 truncate">
                                                                <?php echo e(Str::limit($producto->descripcion, 60)); ?>

                                                            </div>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </td>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <!-- Código de Barras -->
                                            <td class="px-4 py-3 text-sm text-gray-700" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-mono bg-blue-100 text-blue-800">
                                                    <?php echo e($presentacion->codigo_barra); ?>

                                                </span>
                                            </td>
                                            <!-- Unidad de Medida -->
                                            <td class="px-4 py-3 text-sm text-gray-700" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                <!--[if BLOCK]><![endif]--><?php if($presentacion->unidad_medida): ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                        <?php echo e($presentacion->unidad_medida); ?>

                                                        <!--[if BLOCK]><![endif]--><?php if($presentacion->unidad_simbolo): ?>
                                                            (<?php echo e($presentacion->unidad_simbolo); ?>)
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-gray-400 text-xs">N/A</span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <!--[if BLOCK]><![endif]--><?php if($index === 0): ?>
                                                <!-- Categoría - solo en primera fila -->
                                                <td class="px-4 py-3 text-sm text-gray-700 border-l" 
                                                    rowspan="<?php echo e($numPresentaciones); ?>"
                                                    wire:click="editar(<?php echo e($producto->id); ?>)">
                                                    <div>
                                                        <div class="font-medium"><?php echo e($producto->subcategoria->categoria->nombre ?? 'N/A'); ?></div>
                                                        <div class="text-xs text-gray-500"><?php echo e($producto->subcategoria->nombre ?? ''); ?></div>
                                                    </div>
                                                </td>
                                                <!-- Marca - solo en primera fila -->
                                                <td class="px-4 py-3 text-sm text-gray-700" 
                                                    rowspan="<?php echo e($numPresentaciones); ?>"
                                                    wire:click="editar(<?php echo e($producto->id); ?>)">
                                                    <?php echo e($producto->marca->nombre ?? 'Sin marca'); ?>

                                                </td>
                                                <!-- Origen - solo en primera fila -->
                                                <td class="px-4 py-3 text-center" 
                                                    rowspan="<?php echo e($numPresentaciones); ?>"
                                                    wire:click="editar(<?php echo e($producto->id); ?>)">
                                                    <!--[if BLOCK]><![endif]--><?php if($producto->producto_valencia): ?>
                                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                                            🏢 Valencia
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                            🏠 Paperland
                                                        </span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <!-- Acciones - solo en primera fila -->
                                                <td class="px-4 py-3 text-center" rowspan="<?php echo e($numPresentaciones); ?>">
                                                    <!--[if BLOCK]><![endif]--><?php if(!$producto->producto_valencia): ?>
                                                        <button type="button"
                                                                class="p-1 text-red-600 transition-colors hover:text-red-800"
                                                                wire:click="confirmarEliminar(<?php echo e($producto->id); ?>)"
                                                                onclick="event.stopPropagation();"
                                                                title="Eliminar producto">
                                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                            </svg>
                                                        </button>
                                                    <?php else: ?>
                                                        <span class="text-xs text-gray-400">Solo lectura</span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php else: ?>
                                        <!-- Producto sin presentaciones -->
                                        <tr class="transition-colors duration-150 cursor-pointer hover:bg-gray-50"
                                            wire:key="producto-<?php echo e($producto->id); ?>-sin-presentacion">
                                            <!-- Código del Producto (ID) -->
                                            <td class="px-4 py-3 text-sm font-semibold text-gray-900" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                #<?php echo e($producto->id); ?>

                                            </td>
                                            <!-- Producto -->
                                            <td class="px-4 py-3" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                <div>
                                                    <div class="font-medium text-gray-900"><?php echo e($producto->nombre); ?></div>
                                                    <!--[if BLOCK]><![endif]--><?php if($producto->descripcion): ?>
                                                        <div class="max-w-xs text-sm text-gray-500 truncate">
                                                            <?php echo e(Str::limit($producto->descripcion, 60)); ?>

                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </td>
                                            <!-- Sin Código de Barras -->
                                            <td class="px-4 py-3 text-sm text-gray-400" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                Sin código
                                            </td>
                                            <!-- Sin Unidad de Medida -->
                                            <td class="px-4 py-3 text-sm text-gray-400" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                N/A
                                            </td>
                                            <!-- Categoría -->
                                            <td class="px-4 py-3 text-sm text-gray-700" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                <div>
                                                    <div class="font-medium"><?php echo e($producto->subcategoria->categoria->nombre ?? 'N/A'); ?></div>
                                                    <div class="text-xs text-gray-500"><?php echo e($producto->subcategoria->nombre ?? ''); ?></div>
                                                </div>
                                            </td>
                                            <!-- Marca -->
                                            <td class="px-4 py-3 text-sm text-gray-700" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                <?php echo e($producto->marca->nombre ?? 'Sin marca'); ?>

                                            </td>
                                            <!-- Origen -->
                                            <td class="px-4 py-3 text-center" wire:click="editar(<?php echo e($producto->id); ?>)">
                                                <!--[if BLOCK]><![endif]--><?php if($producto->producto_valencia): ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                                        🏢 Valencia
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                        🏠 Paperland
                                                    </span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <!-- Acciones -->
                                            <td class="px-4 py-3 text-center">
                                                <!--[if BLOCK]><![endif]--><?php if(!$producto->producto_valencia): ?>
                                                    <button type="button"
                                                            class="p-1 text-red-600 transition-colors hover:text-red-800"
                                                            wire:click="confirmarEliminar(<?php echo e($producto->id); ?>)"
                                                            onclick="event.stopPropagation();"
                                                            title="Eliminar producto">
                                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                        </svg>
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-xs text-gray-400">Solo lectura</span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <!-- Mensaje cuando no hay productos -->
                            <tr>
                                <td colspan="8" class="px-4 py-12 text-center">
                                    <div class="mb-4 text-6xl text-gray-400">📦</div>
                                    <h3 class="mb-2 text-lg font-medium text-gray-900">No se encontraron productos</h3>
                                    <p class="mb-4 text-gray-500">
                                        <!--[if BLOCK]><![endif]--><?php if($buscar || $filtroOrigen !== 'todos' || $filtroNombre || $filtroCodigo || $filtroCategoria || $filtroMarca || $filtroPrecio): ?>
                                            No hay productos que coincidan con los filtros aplicados
                                        <?php else: ?>
                                            No hay productos registrados en el sistema
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </p>
                                    <!--[if BLOCK]><![endif]--><?php if($buscar || $filtroOrigen !== 'todos' || $filtroNombre || $filtroCodigo || $filtroCategoria || $filtroMarca || $filtroPrecio): ?>
                                        <button wire:click="limpiarFiltros"
                                                class="px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600">
                                            Limpiar filtros
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <!-- PAGINACIÓN PERSONALIZADA CON SELECTOR -->
                <div class="mt-4">
                    <!--[if BLOCK]><![endif]--><?php if($productos->hasPages()): ?>
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-4">
                                <div class="text-sm text-gray-700">
                                    Showing <?php echo e($productos->firstItem()); ?> to <?php echo e($productos->lastItem()); ?> of <?php echo e($productos->total()); ?> results
                                </div>
                                <div class="flex items-center gap-2">
                                    <label class="text-sm text-gray-600">Show:</label>
                                    <select wire:model.live="registrosPorPagina" class="px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500">
                                        <option value="10">10</option>
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                </div>
                            </div>
                            <div class="flex space-x-1">
                                
                                <!--[if BLOCK]><![endif]--><?php if($productos->onFirstPage()): ?>
                                    <span class="px-3 py-2 text-sm text-gray-400 bg-gray-200 border border-gray-300 rounded cursor-not-allowed">Previous</span>
                                <?php else: ?>
                                    <button wire:click="previousPage" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50">Previous</button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <?php
                                    $currentPage = $productos->currentPage();
                                    $lastPage = $productos->lastPage();
                                    $start = max(1, min($currentPage - 2, $lastPage - 4));
                                    $end = min($start + 4, $lastPage);
                                ?>

                                <!--[if BLOCK]><![endif]--><?php for($page = $start; $page <= min($end, $lastPage); $page++): ?>
                                    <!--[if BLOCK]><![endif]--><?php if($page == $currentPage): ?>
                                        <span class="px-3 py-2 text-sm font-medium text-blue-600 border border-blue-300 rounded bg-blue-50"><?php echo e($page); ?></span>
                                    <?php else: ?>
                                        <button wire:click="gotoPage(<?php echo e($page); ?>)" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50"><?php echo e($page); ?></button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <!--[if BLOCK]><![endif]--><?php if($end < $lastPage): ?>
                                    <!--[if BLOCK]><![endif]--><?php if($end < $lastPage - 1): ?>
                                        <span class="px-3 py-2 text-sm text-gray-400">...</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <button wire:click="gotoPage(<?php echo e($lastPage); ?>)" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50"><?php echo e($lastPage); ?></button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <!--[if BLOCK]><![endif]--><?php if($productos->hasMorePages()): ?>
                                    <button wire:click="nextPage" class="px-3 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50">Next</button>
                                <?php else: ?>
                                    <span class="px-3 py-2 text-sm text-gray-400 bg-gray-200 border border-gray-300 rounded cursor-not-allowed">Next</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-4">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($productos->firstItem() ?? 0); ?> to <?php echo e($productos->lastItem() ?? 0); ?> of <?php echo e($productos->total()); ?> results
                            </div>
                            <div class="flex items-center gap-2">
                                <label class="text-sm text-gray-600">Show:</label>
                                <select wire:model.live="registrosPorPagina" class="px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Confirmar Eliminación (simplificado) -->
    <!--[if BLOCK]><![endif]--><?php if($modalEliminarAbierto): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         wire:click.self="cerrarModalEliminar">
        <div class="w-full max-w-md p-6 mx-4 bg-white rounded-lg shadow-xl">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-red-600">⚠️ Confirmar Eliminación</h3>
                <button wire:click="cerrarModalEliminar" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($productoSeleccionado): ?>
                <div class="p-3 mb-4 rounded bg-gray-50">
                    <h6 class="font-medium"><?php echo e($productoSeleccionado->nombre ?? ''); ?></h6>
                    <p class="text-sm text-gray-600"><?php echo e($productoSeleccionado->codigo_barra ?? 'Sin código'); ?></p>
                </div>

                <!--[if BLOCK]><![endif]--><?php if($puedeEliminar): ?>
                    <p class="mb-4 text-gray-700">¿Estás seguro que deseas eliminar este producto?</p>
                    <div class="flex justify-end gap-2">
                        <button wire:click="cerrarModalEliminar" class="px-4 py-2 text-gray-700 bg-gray-300 rounded hover:bg-gray-400">
                            Cancelar
                        </button>
                        <button wire:click="eliminarProducto" class="px-4 py-2 text-white bg-red-500 rounded hover:bg-red-600">
                            Eliminar
                        </button>
                    </div>
                <?php else: ?>
                    <div class="mb-4 text-red-600">
                        <p class="font-medium">No se puede eliminar este producto:</p>
                        <ul class="mt-2 space-y-1 text-sm">
                            <!--[if BLOCK]><![endif]--><?php if($tieneCodigoBarras): ?><li>• Tiene código de barras asignado</li><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($stockDisponible > 0): ?><li>• Tiene stock disponible (<?php echo e($stockDisponible); ?>)</li><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($tieneComprasActivas): ?><li>• Tiene compras pendientes</li><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                    <div class="flex justify-end">
                        <button wire:click="cerrarModalEliminar" class="px-4 py-2 text-gray-700 bg-gray-300 rounded hover:bg-gray-400">
                            Cerrar
                        </button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal Detalles de Sincronización -->
    <!--[if BLOCK]><![endif]--><?php if($detallesSincronizacion): ?>
        <div class="fixed inset-0 z-50 flex items-center justify-center">
            <div class="fixed inset-0 bg-black bg-opacity-50" wire:click="cerrarDetallesSincronizacion"></div>
            <div class="relative w-full max-w-md p-6 mx-4 bg-white rounded-lg shadow-xl">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-900">📊 Sincronización Completada</h3>
                    <button wire:click="cerrarDetallesSincronizacion" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>

                <div class="space-y-3">
                    <div class="flex items-center justify-between p-3 rounded bg-green-50">
                        <span class="font-medium text-green-800">✅ Procesados:</span>
                        <span class="font-bold text-green-600"><?php echo e($detallesSincronizacion['productos_sincronizados'] ?? 0); ?></span>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if(($detallesSincronizacion['errores'] ?? 0) > 0): ?>
                        <div class="flex items-center justify-between p-3 rounded bg-red-50">
                            <span class="font-medium text-red-800">❌ Errores:</span>
                            <span class="font-bold text-red-600"><?php echo e($detallesSincronizacion['errores']); ?></span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="mt-6 text-center">
                    <button wire:click="cerrarDetallesSincronizacion"
                            class="px-4 py-2 text-white transition-colors bg-blue-600 rounded hover:bg-blue-700">
                        Cerrar
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<script>
// Escuchar el evento de descarga de archivos
document.addEventListener('DOMContentLoaded', function() {
    // Para Livewire v3
    if (typeof Livewire !== 'undefined') {
        Livewire.on('descargarArchivo', (data) => {
            console.log('Evento descargarArchivo recibido:', data);
            const eventData = Array.isArray(data) ? data[0] : data;
            const { url, filename } = eventData;

            console.log('URL de descarga:', url);

            // Crear un enlace temporal para descargar el archivo
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            link.style.display = 'none';

            // Agregar al DOM, hacer click y remover
            document.body.appendChild(link);
            link.click();

            // Remover después de un pequeño delay
            setTimeout(() => {
                document.body.removeChild(link);
            }, 100);
        });
    }
});

// También intentar escuchar cuando Livewire esté completamente cargado
document.addEventListener('livewire:init', () => {
    Livewire.on('descargarArchivo', (data) => {
        console.log('Evento descargarArchivo recibido (livewire:init):', data);
        const eventData = Array.isArray(data) ? data[0] : data;
        const { url, filename } = eventData;

        // Crear un enlace temporal para descargar el archivo
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.style.display = 'none';

        // Agregar al DOM, hacer click y remover
        document.body.appendChild(link);
        link.click();

        setTimeout(() => {
            document.body.removeChild(link);
        }, 100);
    });
});
</script>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/producto.blade.php ENDPATH**/ ?>