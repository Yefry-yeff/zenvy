<div>
    <!-- Configuración de Sincronización de Base de Datos -->
    <div class="container-fluid px-4 py-4">
        
        <!-- Encabezado -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="h3 mb-1">
                            <i class="fas fa-database text-primary me-2"></i>
                            Configuración de Sincronización
                        </h2>
                        <p class="text-muted mb-0">Gestionar las configuraciones de sincronización entre bases de datos</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mensajes de estado -->
        <!--[if BLOCK]><![endif]--><?php if($mensajeExito): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo e($mensajeExito); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if($mensajeError): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo e($mensajeError); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Configuración de Bases de Datos -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-server me-2"></i>Configuración de Bases de Datos
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="border rounded p-3 bg-light">
                                    <h6 class="text-primary mb-3">
                                        <i class="fas fa-upload me-2"></i>Base de Datos Origen (Valencia)
                                    </h6>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold"><?php echo e($nombreBaseDatosOrigen); ?></span>
                                        <button wire:click="abrirEdicionBaseDatos" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i> Cambiar
                                        </button>
                                    </div>
                                    <small class="text-muted">
                                        <strong>Host:</strong> <?php echo e($hostOrigen); ?>:<?php echo e($puertoOrigen); ?><br>
                                        <strong>Usuario:</strong> <?php echo e($usuarioOrigen); ?><br>
                                        <strong>Estado:</strong> <span class="text-success">Configurado</span>
                                    </small>
                                </div>
                            </div>
                            <div class="col-md-2 text-center d-flex align-items-center justify-content-center">
                                <i class="fas fa-arrow-right text-success fa-2x"></i>
                            </div>
                            <div class="col-md-5">
                                <div class="border rounded p-3 bg-light">
                                    <h6 class="text-success mb-3">
                                        <i class="fas fa-download me-2"></i>Base de Datos Destino (Zenvy)
                                    </h6>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold"><?php echo e($nombreBaseDatosDestino); ?></span>
                                        <button wire:click="abrirEdicionBaseDatos" class="btn btn-sm btn-outline-success">
                                            <i class="fas fa-edit"></i> Cambiar
                                        </button>
                                    </div>
                                    <small class="text-muted">Conexión de base de datos configurada en config/database.php</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="d-flex gap-2">
                                    <button wire:click="abrirConfiguracionTablas" class="btn btn-primary">
                                        <i class="fas fa-table me-2"></i>Ver Configuraciones de Sincronización
                                    </button>
                                    <button wire:click="abrirVisorLogs" class="btn btn-info">
                                        <i class="fas fa-file-alt me-2"></i>Ver Logs del Sistema
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Vista de Configuraciones de Sincronización -->
        <!--[if BLOCK]><![endif]--><?php if($mostrarConfiguracionTablas): ?>
            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-sync me-2"></i>Configuraciones de Sincronización Activas
                            </h5>
                            <button wire:click="cerrarConfiguracionTablas" class="btn btn-sm btn-light">
                                <i class="fas fa-times"></i> Cerrar
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $configuraciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card h-100 <?php echo e($config['activo'] ? 'border-success' : 'border-warning'); ?>">
                                            <div class="card-header <?php echo e($config['activo'] ? 'bg-success' : 'bg-warning'); ?> text-white">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <h6 class="card-title mb-0"><?php echo e($config['nombre']); ?></h6>
                                                    <button wire:click="toggleSincronizacion('<?php echo e($key); ?>')" 
                                                            class="btn btn-sm <?php echo e($config['activo'] ? 'btn-light' : 'btn-dark'); ?>">
                                                        <i class="fas <?php echo e($config['activo'] ? 'fa-pause' : 'fa-play'); ?>"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text small"><?php echo e($config['descripcion']); ?></p>
                                                
                                                <div class="mb-3">
                                                    <strong>Servicio:</strong><br>
                                                    <code class="text-primary"><?php echo e($config['servicio']); ?></code>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <strong>Comando:</strong><br>
                                                    <code class="text-success">php artisan <?php echo e($config['comando']); ?></code>
                                                </div>
                                                
                                                <div class="row">
                                                    <div class="col-6">
                                                        <strong>Tabla Origen:</strong><br>
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <small class="text-muted"><?php echo e($config['tabla_origen']); ?></small>
                                                            <button wire:click="abrirEdicionTabla('<?php echo e($key); ?>')" 
                                                                    class="btn btn-xs btn-outline-primary" 
                                                                    style="padding: 2px 6px; font-size: 10px;"
                                                                    title="Editar tablas">
                                                                <i class="fas fa-edit fa-xs"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <strong>Tabla Destino:</strong><br>
                                                        <small class="text-muted"><?php echo e($config['tabla_destino']); ?></small>
                                                    </div>
                                                </div>
                                                
                                                <div class="mt-3">
                                                    <button wire:click="probarComando('<?php echo e($config['comando']); ?>')" 
                                                            class="btn btn-sm btn-outline-primary w-100"
                                                            <?php echo e(!$config['activo'] ? 'disabled' : ''); ?>>
                                                        <i class="fas fa-play me-2"></i>Probar Comando
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="card-footer text-center">
                                                <span class="badge <?php echo e($config['activo'] ? 'bg-success' : 'bg-warning'); ?>">
                                                    <?php echo e($config['activo'] ? 'ACTIVO' : 'INACTIVO'); ?>

                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            
                            <div class="alert alert-info mt-4">
                                <h6><i class="fas fa-info-circle me-2"></i>Información Importante</h6>
                                <ul class="mb-0">
                                    <li>Al cambiar las configuraciones de base de datos, se actualizarán automáticamente todos los servicios de sincronización.</li>
                                    <li>Los cambios se aplican directamente en el código de los servicios (archivos PHP).</li>
                                    <li>No se modifican las tablas de la base de datos, solo las configuraciones de conexión.</li>
                                    <li>Asegúrate de que las conexiones de base de datos estén configuradas correctamente en <code>config/database.php</code>.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Visor de Logs -->
        <!--[if BLOCK]><![endif]--><?php if($mostrarLogs): ?>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-file-alt me-2"></i>Logs del Sistema (Laravel)
                            </h5>
                            <div class="d-flex gap-2">
                                <button wire:click="actualizarLogs" class="btn btn-sm btn-light" title="Actualizar logs">
                                    <i class="fas fa-sync-alt"></i> Actualizar
                                </button>
                                <button wire:click="descargarLogs" class="btn btn-sm btn-success" title="Descargar logs">
                                    <i class="fas fa-download"></i> Descargar
                                </button>
                                <button wire:click="limpiarArchivoLogs" class="btn btn-sm btn-warning" title="Limpiar archivo de logs" 
                                        onclick="return confirm('¿Estás seguro de que deseas limpiar todos los logs?')">
                                    <i class="fas fa-trash"></i> Limpiar
                                </button>
                                <button wire:click="cerrarVisorLogs" class="btn btn-sm btn-light">
                                    <i class="fas fa-times"></i> Cerrar
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <!-- Filtros -->
                            <div class="p-3 bg-light border-bottom">
                                <div class="d-flex gap-2 align-items-center">
                                    <span class="fw-bold me-2">Filtrar por nivel:</span>
                                    <button wire:click="filtrarPorNivel('')" 
                                            class="btn btn-sm <?php echo e($filtroNivelLog === '' ? 'btn-primary' : 'btn-outline-secondary'); ?>">
                                        Todos
                                    </button>
                                    <button wire:click="filtrarPorNivel('ERROR')" 
                                            class="btn btn-sm <?php echo e($filtroNivelLog === 'ERROR' ? 'btn-danger' : 'btn-outline-danger'); ?>">
                                        <i class="fas fa-times-circle"></i> ERROR
                                    </button>
                                    <button wire:click="filtrarPorNivel('WARNING')" 
                                            class="btn btn-sm <?php echo e($filtroNivelLog === 'WARNING' ? 'btn-warning' : 'btn-outline-warning'); ?>">
                                        <i class="fas fa-exclamation-triangle"></i> WARNING
                                    </button>
                                    <button wire:click="filtrarPorNivel('INFO')" 
                                            class="btn btn-sm <?php echo e($filtroNivelLog === 'INFO' ? 'btn-info' : 'btn-outline-info'); ?>">
                                        <i class="fas fa-info-circle"></i> INFO
                                    </button>
                                    <button wire:click="filtrarPorNivel('DEBUG')" 
                                            class="btn btn-sm <?php echo e($filtroNivelLog === 'DEBUG' ? 'btn-secondary' : 'btn-outline-secondary'); ?>">
                                        <i class="fas fa-bug"></i> DEBUG
                                    </button>
                                    <span class="ms-auto text-muted">
                                        <i class="fas fa-list"></i> <?php echo e(count($logs)); ?> registro(s)
                                    </span>
                                </div>
                                <div class="mt-2">
                                    <label for="cantidadLineasLogs" class="form-label small mb-1">Líneas a mostrar:</label>
                                    <select wire:model.live="cantidadLineasLogs" id="cantidadLineasLogs" class="form-select form-select-sm w-auto d-inline-block">
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                        <option value="200">200</option>
                                        <option value="500">500</option>
                                        <option value="1000">1000</option>
                                    </select>
                                </div>
                            </div>
                            
                            <!-- Lista de Logs -->
                            <div class="p-3" style="max-height: 600px; overflow-y: auto;">
                                <!--[if BLOCK]><![endif]--><?php if(count($logs) > 0): ?>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card mb-2 border-start border-3 
                                            <?php echo e($log['nivel'] === 'ERROR' ? 'border-danger' : ''); ?>

                                            <?php echo e($log['nivel'] === 'WARNING' ? 'border-warning' : ''); ?>

                                            <?php echo e($log['nivel'] === 'INFO' ? 'border-info' : ''); ?>

                                            <?php echo e($log['nivel'] === 'DEBUG' ? 'border-secondary' : ''); ?>">
                                            <div class="card-body p-2">
                                                <div class="d-flex justify-content-between align-items-start">
                                                    <div class="flex-grow-1">
                                                        <div class="d-flex align-items-center gap-2 mb-1">
                                                            <span class="badge 
                                                                <?php echo e($log['nivel'] === 'ERROR' ? 'bg-danger' : ''); ?>

                                                                <?php echo e($log['nivel'] === 'WARNING' ? 'bg-warning text-dark' : ''); ?>

                                                                <?php echo e($log['nivel'] === 'INFO' ? 'bg-info' : ''); ?>

                                                                <?php echo e($log['nivel'] === 'DEBUG' ? 'bg-secondary' : ''); ?>">
                                                                <?php echo e($log['nivel']); ?>

                                                            </span>
                                                            <small class="text-muted">
                                                                <i class="fas fa-clock"></i> <?php echo e($log['fecha'] ?? 'Sin fecha'); ?>

                                                            </small>
                                                        </div>
                                                        <div class="mb-1">
                                                            <strong><?php echo e($log['mensaje'] ?? 'Sin mensaje'); ?></strong>
                                                        </div>
                                                        <!--[if BLOCK]><![endif]--><?php if(!empty($log['contexto'])): ?>
                                                            <div class="mt-2">
                                                                <button class="btn btn-sm btn-outline-secondary" 
                                                                        type="button" 
                                                                        data-bs-toggle="collapse" 
                                                                        data-bs-target="#contexto-<?php echo e($index); ?>"
                                                                        aria-expanded="false">
                                                                    <i class="fas fa-code"></i> Ver contexto/stack trace
                                                                </button>
                                                                <div class="collapse mt-2" id="contexto-<?php echo e($index); ?>">
                                                                    <pre class="bg-dark text-light p-3 rounded small" style="max-height: 400px; overflow-y: auto;"><code><?php echo e(trim($log['contexto'])); ?></code></pre>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                <?php else: ?>
                                    <div class="text-center text-muted py-5">
                                        <i class="fas fa-inbox fa-3x mb-3"></i>
                                        <p>No hay logs disponibles o no hay logs que coincidan con el filtro.</p>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <div class="card-footer bg-light">
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="fas fa-folder"></i> Ubicación: <code>storage/logs/laravel.log</code>
                                </small>
                                <small class="text-muted">
                                    Mostrando últimas <?php echo e($cantidadLineasLogs); ?> líneas
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <!-- Modal de Edición de Base de Datos -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalEdicion): ?>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-database me-2"></i>Configurar Conexiones de Base de Datos
                        </h5>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Atención:</strong> Este cambio modificará automáticamente:
                            <ul class="mb-0 mt-2">
                                <li>Variables de configuración en el archivo <code>.env</code></li>
                                <li>Conexiones en <code>config/database.php</code></li>
                                <li>Todos los servicios de sincronización (6 archivos)</li>
                                <li>Todos los modelos externos (6 archivos)</li>
                                <li>Cache de configuración de Laravel</li>
                            </ul>
                            <small class="text-muted">Ejemplo: si cambias a <code>cadssf2t_valencia_pruebas</code>, se creará automáticamente esa conexión.</small>
                        </div>
                        
                        <form wire:submit.prevent="guardarConfiguracionBaseDatos">
                            <h6 class="text-primary mb-3">
                                <i class="fas fa-upload me-2"></i>Configuración Base de Datos Origen (Valencia)
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="hostOrigen" class="form-label">Host</label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['hostOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="hostOrigen"
                                           wire:model="hostOrigen" 
                                           placeholder="127.0.0.1">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['hostOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="puertoOrigen" class="form-label">Puerto</label>
                                    <input type="number" 
                                           class="form-control <?php $__errorArgs = ['puertoOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="puertoOrigen"
                                           wire:model="puertoOrigen" 
                                           placeholder="3306">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['puertoOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="nombreBaseDatosOrigen" class="form-label">Nombre de Base de Datos</label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['nombreBaseDatosOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="nombreBaseDatosOrigen"
                                       wire:model="nombreBaseDatosOrigen" 
                                       placeholder="profac_app">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombreBaseDatosOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <small class="form-text text-muted">Ejemplo: profac_app, cadssf2t_valencia_pruebas</small>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="usuarioOrigen" class="form-label">Usuario</label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['usuarioOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="usuarioOrigen"
                                           wire:model="usuarioOrigen" 
                                           placeholder="root">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['usuarioOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="passwordOrigen" class="form-label">Contraseña</label>
                                    <input type="password" 
                                           class="form-control" 
                                           id="passwordOrigen"
                                           wire:model="passwordOrigen" 
                                           placeholder="Contraseña (opcional)">
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            
                            <h6 class="text-success mb-3">
                                <i class="fas fa-download me-2"></i>Configuración Base de Datos Destino (Zenvy)
                            </h6>
                            
                            <div class="mb-3">
                                <label for="nombreBaseDatosDestino" class="form-label">Conexión de Destino</label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['nombreBaseDatosDestino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="nombreBaseDatosDestino"
                                       wire:model="nombreBaseDatosDestino" 
                                       placeholder="mysql">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombreBaseDatosDestino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <small class="form-text text-muted">Normalmente 'mysql' (conexión por defecto de Laravel)</small>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cancelarEdicion" class="btn btn-secondary">
                            <i class="fas fa-times me-2"></i>Cancelar
                        </button>
                        <button type="button" wire:click="probarConexion" class="btn btn-info">
                            <i class="fas fa-wifi me-2"></i>Probar Conexión
                        </button>
                        <button type="button" wire:click="guardarConfiguracionBaseDatos" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Actualizar Configuración
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de Edición de Tablas -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalEdicionTabla): ?>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-table me-2"></i>Configurar Tablas de Sincronización
                        </h5>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Editando configuración de tablas</strong>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Atención:</strong> Este cambio modificará las consultas SQL en el archivo del servicio correspondiente.
                        </div>
                            
                            <form wire:submit.prevent="guardarConfiguracionTabla">
                                <div class="mb-3">
                                    <label for="nuevaTablaOrigen" class="form-label">
                                        <i class="fas fa-upload me-2"></i>Tabla de Origen (Valencia)
                                    </label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['nuevaTablaOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="nuevaTablaOrigen"
                                           wire:model="nuevaTablaOrigen" 
                                           placeholder="nombre_tabla_origen">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevaTablaOrigen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    <small class="form-text text-muted">Nombre de la tabla en la base de datos de Valencia</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="nuevaTablaDestino" class="form-label">
                                        <i class="fas fa-download me-2"></i>Tabla de Destino (Zenvy)
                                    </label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['nuevaTablaDestino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="nuevaTablaDestino"
                                           wire:model="nuevaTablaDestino" 
                                           placeholder="nombre_tabla_destino">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevaTablaDestino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    <small class="form-text text-muted">Nombre de la tabla en la base de datos de Zenvy</small>
                                </div>
                            </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cancelarEdicionTabla" class="btn btn-secondary">
                            <i class="fas fa-times me-2"></i>Cancelar
                        </button>
                        <button type="button" wire:click="guardarConfiguracionTabla" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Actualizar Tablas
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/sincronizacion/base-de-datos.blade.php ENDPATH**/ ?>