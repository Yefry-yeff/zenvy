<table>
    <thead>
        <tr>
            <th colspan="11" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #4472C4; color: white;">
                📦 LISTADO DE PRODUCTOS
            </th>
        </tr>
        <tr>
            <th colspan="11" style="font-size: 12px; text-align: center; color: #666;">
                Sistema ZENVY - Gestión de Inventario
            </th>
        </tr>
        <tr>
            <th colspan="11"></th>
        </tr>
        <tr>
            <th colspan="11" style="font-size: 10px; text-align: center; background-color: #F8F9FA;">
                📅 Generado el: <?php echo e($fechaGeneracion); ?> | 👤 Usuario: <?php echo e($usuarioReporte ?? '-'); ?> | 📊 Total: <?php echo e($totalProductos); ?> productos | 🔍 Filtros: <?php echo e($filtrosAplicados); ?>

            </th>
        </tr>
        <tr>
            <th colspan="11"></th>
        </tr>
        <tr>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">ID</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Código de Barras</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Nombre</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Marca</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Categoría</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Subcategoría</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Precio Base</th>
            <th style="background-color: #28A745; color: white; font-weight: bold; text-align: center;">Unidad de Medida</th>
            <th style="background-color: #28A745; color: white; font-weight: bold; text-align: center;">Precio de Venta</th>
            <th style="background-color: #28A745; color: white; font-weight: bold; text-align: center;">Cantidad por Unidad</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Origen</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Obtener precios de venta activos (ya filtrados en la consulta)
                $preciosVenta = $producto->preciosVenta;
                $totalPrecios = $preciosVenta->count();
            ?>
            
            <?php if($totalPrecios > 0): ?>
                <?php $__currentLoopData = $preciosVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $precioVenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($index == 0): ?>
                            <td style="text-align: center;" rowspan="<?php echo e($totalPrecios); ?>"><?php echo e($producto->id); ?></td>
                            <td rowspan="<?php echo e($totalPrecios); ?>"><?php echo e($precioVenta->codigo_barra ?? 'Sin código'); ?></td>
                            <td rowspan="<?php echo e($totalPrecios); ?>"><?php echo e($producto->nombre); ?></td>
                            <td rowspan="<?php echo e($totalPrecios); ?>"><?php echo e($producto->marca->nombre ?? 'Sin marca'); ?></td>
                            <td rowspan="<?php echo e($totalPrecios); ?>"><?php echo e($producto->subcategoria->categoria->nombre ?? 'N/A'); ?></td>
                            <td rowspan="<?php echo e($totalPrecios); ?>"><?php echo e($producto->subcategoria->nombre ?? 'N/A'); ?></td>
                            <td style="text-align: right; font-weight: bold; color: #6C757D;" rowspan="<?php echo e($totalPrecios); ?>">L. <?php echo e(number_format($producto->precio_base, 2)); ?></td>
                        <?php endif; ?>
                        <td style="text-align: center; background-color: #E7F3FF; font-weight: bold;"><?php echo e($precioVenta->unidadMedida->nombre ?? 'N/A'); ?></td>
                        <td style="text-align: right; background-color: #D4EDDA; font-weight: bold; color: #28A745;">L. <?php echo e(number_format($precioVenta->precio, 2)); ?></td>
                        <td style="text-align: center; background-color: #FFF3CD;"><?php echo e($precioVenta->cantidad ?? 1); ?></td>
                        <?php if($index == 0): ?>
                            <td style="text-align: center; background-color: <?php echo e($producto->producto_valencia ? '#FFF3CD' : '#D4EDDA'); ?>;" rowspan="<?php echo e($totalPrecios); ?>">
                                <?php echo e($producto->producto_valencia ? '🏢 Valencia' : '🏠 Paperland'); ?>

                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td style="text-align: center;"><?php echo e($producto->id); ?></td>
                    <td>Sin código</td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->marca->nombre ?? 'Sin marca'); ?></td>
                    <td><?php echo e($producto->subcategoria->categoria->nombre ?? 'N/A'); ?></td>
                    <td><?php echo e($producto->subcategoria->nombre ?? 'N/A'); ?></td>
                    <td style="text-align: right; font-weight: bold; color: #6C757D;">L. <?php echo e(number_format($producto->precio_base, 2)); ?></td>
                    <td style="text-align: center; background-color: #F8D7DA; color: #721C24;">Sin precio de venta</td>
                    <td style="text-align: center; background-color: #F8D7DA; color: #721C24;">-</td>
                    <td style="text-align: center; background-color: #F8D7DA; color: #721C24;">-</td>
                    <td style="text-align: center; background-color: <?php echo e($producto->producto_valencia ? '#FFF3CD' : '#D4EDDA'); ?>;">
                        <?php echo e($producto->producto_valencia ? '🏢 Valencia' : '🏠 Paperland'); ?>

                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\exports\productos.blade.php ENDPATH**/ ?>