<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/favicon/favicon.ico')); ?>">
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('img/favicon/favicon.svg')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('img/favicon/favicon-96x96.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/favicon/apple-touch-icon.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('img/favicon/site.webmanifest')); ?>">

    
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-Sto7K4qC.css')); ?>">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet" />

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body
    x-data="{ theme: localStorage.getItem('theme') || 'verde', sidebarOpen: true }"
    x-init="document.documentElement.className = theme"
    x-effect="localStorage.setItem('theme', theme); document.documentElement.className = theme"
    class="flex flex-col h-screen font-sans antialiased"
>
    
    <header
    :class="theme === 'verde' ? 'bg-emerald-600/80' :
            theme === 'azul' ? 'bg-blue-600/80' :
            theme === 'oscuro' ? 'bg-gray-900/80' : 'bg-slate-700/80'"
    class="flex items-center justify-between px-6 py-2 text-white transition-all duration-300 shadow-md backdrop-blur-md"
>
    
    <div class="flex items-center gap-3">
        <button @click="sidebarOpen = !sidebarOpen" class="text-white focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>

        <div class="flex items-center gap-2 text-base font-semibold">
            <div class="flex flex-col items-start gap-0">
                <div class="flex items-center gap-2">
                    <img src="<?php echo e(asset('img/Logo_Paperland2.png')); ?>" alt="Logo Paperland" class="object-contain w-8 h-8">
                    <span class="text-xl font-semibold text-white">Paperland</span>
                </div>
                <span class="text-[0.65rem] text-white/80 -mt-1 ml-10">imagina · crea · diviértete</span>
            </div>
        </div>
    </div>

    
    <div x-data="{ open: false }" class="relative">
        <button @click="open = !open" class="flex items-center gap-2 text-white focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 15c2.5 0 4.847.655 6.879 1.804M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span class="font-medium"><?php echo e(Auth::user()->name); ?></span>
        </button>

        <div x-show="open" @click.outside="open = false" x-transition class="absolute right-0 z-50 w-48 mt-2 text-gray-800 bg-white rounded shadow-md">
            <div class="px-4 py-2 border-b">
                <p class="text-sm font-semibold text-gray-600">Tema</p>
                <button @click="theme = 'verde'" class="w-full px-2 py-1 text-sm text-left rounded hover:bg-green-100">Verde</button>
                <button @click="theme = 'azul'" class="w-full px-2 py-1 text-sm text-left rounded hover:bg-blue-100">Azul</button>
                <button @click="theme = 'oscuro'" class="w-full px-2 py-1 text-sm text-left rounded hover:bg-gray-100">Oscuro</button>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="flex items-center w-full gap-2 px-4 py-2 text-sm text-gray-700 rounded-b hover:bg-gray-100">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1m0-10V5" />
                    </svg>
                    Cerrar sesión
                </button>
            </form>
        </div>
    </div>
</header>
    
    <div class="flex flex-1 overflow-hidden">
        <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => ['menu' => $sidebarMenu]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['menu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sidebarMenu)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
        <main :class="sidebarOpen ? 'ml-0' : 'ml-0 w-full'" class="flex-1 p-6 overflow-y-auto transition-all duration-200 bg-white">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dynamic-content');

$__html = app('livewire')->mount($__name, $__params, 'lw-811150391-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </main>
    </div>


    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    
    <script>
        document.addEventListener('livewire:init', () => {
            // Escuchar eventos de Livewire
            Livewire.on('dashboardRenderizado', () => {
                if (typeof window.chartsInitialized !== 'undefined' && window.chartsInitialized) {
                    if (typeof destroyCharts === 'function') {
                        destroyCharts();
                    }
                }
                setTimeout(() => {
                    if (typeof initCharts === 'function') {
                        initCharts();
                    }
                }, 150);
            });

            Livewire.on('datosActualizados', () => {
                if (typeof window.chartsInitialized !== 'undefined' && window.chartsInitialized) {
                    if (typeof destroyCharts === 'function') {
                        destroyCharts();
                    }
                }
                setTimeout(() => {
                    if (typeof initCharts === 'function') {
                        initCharts();
                    }
                }, 150);
            });
        });
    </script>

    
    <script type="module" src="<?php echo e(asset('build/assets/app-BLl8G-P3.js')); ?>"></script>

    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>

    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/listafacturas.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/compra.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/sucursales.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/clientes.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/departamento.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/municipios.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/producto-seccion.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/marca.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/cai.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/categoria.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/subcategoria.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/unidades.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/Script/TablasBoostrap/productos.js')); ?>"></script>
    <!-- MODAL DE SESIÓN EXPIRADA -->
    <div
        x-show="showModal"
        x-data="{
            showModal: false,
            timeout: null,
            lastActivity: Date.now(),
            sessionTimeout: 8 * 60 * 60 * 60 * 60 * 60 * 60 * 1000, // 2 horas
            resetTimer() {
                if (this.timeout) {
                    clearTimeout(this.timeout);
                    this.timeout = null;
                }
                this.lastActivity = Date.now();
                this.timeout = setTimeout(() => {
                    // Verificar si realmente pasó el tiempo sin optimizar
                    if (Date.now() - this.lastActivity >= this.sessionTimeout) {
                        this.showModal = true;
                    }
                }, this.sessionTimeout);
            },
            cerrarSesion() {
                window.location.href = '<?php echo e(route('logout')); ?>';
            },
            init() {
                this.resetTimer();
                // Usar throttling para evitar resetear el timer muy frecuentemente
                let throttle = false;
                const throttledReset = () => {
                    if (!throttle) {
                        throttle = true;
                        this.resetTimer();
                        setTimeout(() => { throttle = false; }, 1000); // Throttle de 1 segundo
                    }
                };
                ['mousemove', 'keydown', 'click', 'scroll'].forEach(evt =>
                    window.addEventListener(evt, throttledReset, { passive: true })
                );
            }
        }"
        x-init="init()"
        x-on:keydown.escape.window="if (showModal) cerrarSesion()"
        x-on:keydown.enter.window="if (showModal) cerrarSesion()"
        @click.outside="cerrarSesion()"
        class="fixed inset-0 z-[100] flex items-center justify-center bg-black bg-opacity-50"
        style="display: none;"
    >
        <div class="w-full max-w-sm p-6 text-center bg-white rounded-lg shadow-lg">
            <h2 class="mb-2 text-lg font-semibold text-red-700">⏳ Sesión Expirada</h2>
            <p class="text-sm text-gray-600">Tu sesión ha expirado por inactividad.</p>
            <button
                class="px-4 py-2 mt-4 text-sm text-white rounded"
                :class="{
                    'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                    'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                    'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                    'bg-slate-700 hover:bg-slate-600': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                }"
                @click="cerrarSesion()"
            >
                Aceptar
            </button>
        </div>
    </div>


    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/layouts/app.blade.php ENDPATH**/ ?>