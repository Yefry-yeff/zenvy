<div>
    <h2 class="mb-4 text-xl font-semibold leading-tight text-gray-800">
        <?php echo e(__('Dashboard')); ?>

    </h2>

    <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
            <?php echo e(__("You're logged in!")); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\livewire\dashboard.blade.php ENDPATH**/ ?>