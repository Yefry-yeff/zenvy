<table>
    <thead>
        <tr>
            <th colspan="9" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #4472C4; color: white;">
                🧾 LISTADO DE FACTURAS
            </th>
        </tr>
        <tr>
            <th colspan="9" style="font-size: 12px; text-align: center; color: #666;">
                Sistema ZENVY - Gestión de Ventas
            </th>
        </tr>
        <tr><th colspan="9"></th></tr>
        <tr>
            <th colspan="9" style="font-size: 10px; text-align: center; background-color: #F8F9FA;">
                📅 Generado el: <?php echo e($fechaGeneracion); ?> | 👤 Usuario: <?php echo e($usuarioReporte ?? '-'); ?> | 📊 Total: <?php echo e($totalFacturas); ?> facturas | 🔍 Filtros: <?php echo e($filtrosAplicados); ?>

            </th>
        </tr>
        <tr><th colspan="9"></th></tr>
        <tr>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">ID</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">No. Factura</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Cliente</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">RTN</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Fecha</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Subtotal</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">ISV</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Total</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($factura['id']); ?></td>
                <td><?php echo e($factura['numero_factura']); ?></td>
                <td><?php echo e($factura['nombre_cliente'] ?? 'Cliente General'); ?></td>
                <td><?php echo e($factura['rtn']); ?></td>
                <td><?php echo e(!empty($factura['fecha_emision']) ? \Carbon\Carbon::parse($factura['fecha_emision'])->format('d/m/Y') : '-'); ?></td>
                <td style="text-align: right;">L. <?php echo e(number_format($factura['sub_total'] ?? 0, 2)); ?></td>
                <td style="text-align: right;">L. <?php echo e(number_format($factura['isv'] ?? 0, 2)); ?></td>
                <td style="text-align: right; font-weight: bold;">L. <?php echo e(number_format($factura['total'] ?? 0, 2)); ?></td>
                <td style="text-align: center;">
                    <?php if($factura['estado_factura_id'] == 1): ?>
                        Pagada
                    <?php elseif($factura['estado_factura_id'] == 2): ?>
                        Pendiente
                    <?php elseif($factura['estado_factura_id'] == 3): ?>
                        Anulada
                    <?php else: ?>
                        Desconocido
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\exports\facturas.blade.php ENDPATH**/ ?>