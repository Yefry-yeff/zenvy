<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th colspan="11" style="background-color: #4CAF50; color: white; font-size: 16px; text-align: center; padding: 10px;">
                🎁 HISTORIAL DE REGALÍAS Y REQUISICIONES (BODEGA 2)
            </th>
        </tr>
        <tr>
            <th colspan="11" style="background-color: #f5f5f5; text-align: left; padding: 8px;">
                <strong>Fecha de generación:</strong> <?php echo e($fechaGeneracion); ?>

            </th>
        </tr>
        <tr>
            <th colspan="11" style="background-color: #f5f5f5; text-align: left; padding: 8px;">
                <strong>Usuario:</strong> <?php echo e($usuarioReporte); ?>

            </th>
        </tr>
        <tr>
            <th colspan="11" style="background-color: #f5f5f5; text-align: left; padding: 8px;">
                <strong>Total de registros:</strong> <?php echo e($totalRegistros); ?>

            </th>
        </tr>
        <tr>
            <th colspan="11" style="background-color: #f5f5f5; text-align: left; padding: 8px;">
                <strong>Filtros aplicados:</strong> <?php echo e($filtrosAplicados); ?>

            </th>
        </tr>
        <tr style="background-color: #2196F3; color: white; font-weight: bold;">
            <th>Producto</th>
            <th>Código</th>
            <th>Marca</th>
            <th>Origen</th>
            <th>Proveedor</th>
            <th>Segmento</th>
            <th>Sección</th>
            <th>Cantidad Inicial</th>
            <th>Cantidad Actual</th>
            <th>Unidad</th>
            <th>Fecha Ingreso</th>
            <th>Usuario</th>
            <th>Comentario</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($item->producto_nombre); ?></td>
                <td><?php echo e($item->codigo_barra ?? 'N/A'); ?></td>
                <td><?php echo e($item->marca_nombre ?? 'Sin marca'); ?></td>
                <td><?php echo e($item->origen); ?></td>
                <td><?php echo e($item->proveedor ?? 'N/A'); ?></td>
                <td><?php echo e($item->segmento_descripcion ?? 'N/A'); ?></td>
                <td><?php echo e($item->seccion_descripcion ?? 'N/A'); ?></td>
                <td style="text-align: center;"><?php echo e(number_format($item->cantidad_inicial_seccion, 2)); ?></td>
                <td style="text-align: center;"><?php echo e(number_format($item->cantidad_disponible, 2)); ?></td>
                <td><?php echo e($item->unidad_medida_venta ?? $item->unidad_medida ?? 'Unidad'); ?></td>
                <td style="text-align: center;"><?php echo e(\Carbon\Carbon::parse($item->fecha_recibido)->format('d/m/Y H:i')); ?></td>
                <td><?php echo e($item->usuario_registro); ?></td>
                <td><?php echo e($item->comentario ?? '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="13" style="text-align: center; padding: 20px; color: #999;">
                    No hay registros para mostrar
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr style="background-color: #f5f5f5; font-weight: bold;">
            <td colspan="7" style="text-align: right;">TOTAL DE REGISTROS:</td>
            <td colspan="6" style="text-align: left;"><?php echo e($totalRegistros); ?></td>
        </tr>
    </tfoot>
</table>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\exports\regalias-y-requisiciones.blade.php ENDPATH**/ ?>