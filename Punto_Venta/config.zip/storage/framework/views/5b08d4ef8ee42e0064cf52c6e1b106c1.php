<table>
    <thead>
        <tr>
            <th colspan="7" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #4472C4; color: white;">
                🛒 LISTADO DE COMPRAS DE PRODUCTOS
            </th>
        </tr>
        <tr>
            <th colspan="7" style="font-size: 12px; text-align: center; color: #666;">
                Sistema ZENVY - Gestión de Compras
            </th>
        </tr>
        <tr><th colspan="7"></th></tr>
        <tr>
            <th colspan="7" style="font-size: 10px; text-align: center; background-color: #F8F9FA;">
                📅 Generado el: <?php echo e($fechaGeneracion); ?> | 👤 Usuario: <?php echo e($usuarioReporte ?? '-'); ?> | 📊 Total: <?php echo e($totalCompras); ?> compras | 🔍 Filtros: <?php echo e($filtrosAplicados); ?>

            </th>
        </tr>
        <tr><th colspan="7"></th></tr>
        <tr>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;"># Factura</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Proveedor</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Fecha Emisión</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Fecha Recepción</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Estado</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Cantidad Productos</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($compra['numero_factura'] ?? '-'); ?></td>
                <td><?php echo e($compra['proveedor_nombre'] ?? 'N/A'); ?></td>
                <td><?php echo e(!empty($compra['fecha_emision']) ? \Carbon\Carbon::parse($compra['fecha_emision'])->format('d/m/Y') : '-'); ?></td>
                <td><?php echo e(!empty($compra['fecha_recepcion']) ? \Carbon\Carbon::parse($compra['fecha_recepcion'])->format('d/m/Y') : '-'); ?></td>
                <td><?php echo e($compra['estado'] ?? 'N/A'); ?></td>
                <td style="text-align: right;"><?php echo e($compra['cantidad_productos'] ?? 0); ?></td>
                <td style="text-align: right;">L. <?php echo e(number_format($compra['total'] ?? 0, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\exports\compra-de-productos.blade.php ENDPATH**/ ?>