<div>
    
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\livewire\gestion\historico.blade.php ENDPATH**/ ?>