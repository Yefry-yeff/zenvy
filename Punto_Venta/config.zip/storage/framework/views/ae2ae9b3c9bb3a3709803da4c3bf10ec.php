<div> 

    
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 mb-4 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">Gestión de Sucursales</h5>
            <button wire:click="abrirModalCrear"
                class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                <span>➕</span> Agregar Sucursal
            </button>
        </div>

        <!-- TABLA -->
        <div class="px-4 py-3 pt-0 card-body">
            <div class="table-responsive">
                <table id="sucursalesTable" class="table mb-0 align-middle table-sm table-hover table-bordered">
                    <thead class="table-light">
                        <tr class="text-center align-middle">
                            <th>Empresa</th>
                            <th>Nombre Sucursal</th>
                            <th>Identificador Legal</th>
                            <th>Tipo Tienda</th>
                            <th>Teléfono</th>
                            <th>Dirección Tributaria</th>
                            <th>Estado</th>
                            <th style="width: 150px;">Fecha Creación</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center align-middle hover:bg-gray-50">
                                <td class="text-start cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->empresa->nombre ?? 'N/A'); ?></td>
                                <td class="text-start cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->denominacion_social); ?></td>
                                <td class="cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->identificador_legal ?? 'N/A'); ?></td>
                                <td class="cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->tipoTienda->nombre ?? 'N/A'); ?></td>
                                <td class="cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->telefono ?? 'N/A'); ?></td>
                                <td class="text-start cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->direccion->domicilio_tributario ?? 'N/A'); ?></td>
                                <td class="cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)">
                                    <span class="badge <?php echo e($sucursal->estado_id == 1 ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e($sucursal->estado->descripcion ?? 'N/A'); ?>

                                    </span>
                                </td>
                                <td class="cursor-pointer" wire:click="editar(<?php echo e($sucursal->id); ?>)"><?php echo e($sucursal->created_at ? $sucursal->created_at->format('d/m/Y') : 'N/A'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="py-4 text-center text-muted">No hay sucursales disponibles.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <?php if(session()->has('mensaje')): ?>
        <div x-data="{ show: true }" x-show="show"
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="mt-3 mb-0 transition-opacity duration-300 alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div x-data="{ show: true }" x-show="show"
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="mt-3 mb-0 transition-opacity duration-300 alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($alertMessage): ?>
        <div x-data="{ show: true }" x-show="show"
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="alert alert-<?php echo e($alertType == 'success' ? 'success' : ($alertType == 'error' ? 'danger' : 'warning')); ?> mt-3 mb-0 transition-opacity duration-300">
            <i class="fas fa-<?php echo e($alertType == 'success' ? 'check-circle' : ($alertType == 'error' ? 'exclamation-triangle' : 'exclamation-circle')); ?>"></i>
            <?php echo e($alertMessage); ?>

        </div>
    <?php endif; ?>

</div> 
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\livewire\gestion-de-sucursales\sucursales.blade.php ENDPATH**/ ?>