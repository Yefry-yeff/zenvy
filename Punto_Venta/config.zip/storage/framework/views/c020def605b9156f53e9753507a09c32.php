<div> 

    
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 mb-4 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">
                Gestión de Secciones
                <?php if($segmento): ?>
                    - <?php echo e($segmento->descripcion); ?>

                    <?php if($segmento->bodega): ?>
                        (<?php echo e($segmento->bodega->nombre); ?>)
                    <?php endif; ?>
                <?php endif; ?>
            </h5>
            <div class="flex gap-2">
                <button wire:click="volverASegmentos"
                    class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                    <span>←</span> Volver a Segmentos
                </button>
                <button wire:click="crearNuevaSeccion"
                    class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                    <span>➕</span> Nueva Sección
                </button>
            </div>
        </div>

        <!-- CONTENIDO -->
        <div class="px-4 py-3 pt-0 card-body">
            <!-- Barra de búsqueda -->
            <div class="mb-4 row">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text"
                               class="form-control"
                               placeholder="Buscar por descripción de sección..."
                               wire:model.live="buscar">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" wire:model.live="filtroEstado">
                        <option value="">Todos los estados</option>
                        <option value="1">Activas</option>
                        <option value="0">Inactivas</option>
                    </select>
                </div>
            </div>

            <?php if($segmento): ?>
                <div class="mb-4 alert alert-info">
                    <strong>📦 Segmento:</strong> <?php echo e($segmento->descripcion); ?><br>
                    <strong>📍 Bodega:</strong> <?php echo e($segmento->bodega->nombre ?? 'N/A'); ?><br>
                    <strong>🏪 Tienda:</strong> <?php echo e($segmento->bodega->tienda->denominacion_social ?? 'N/A'); ?>

                </div>
            <?php endif; ?>

            <!-- Tarjetas de secciones -->
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="mb-4 col-md-4" wire:key="seccion-<?php echo e($seccion->id); ?>">
                        <div class="shadow-sm card h-100">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0 card-title">
                                    <i class="fas fa-th-large me-2"></i><?php echo e($seccion->descripcion); ?>

                                </h5>
                                <span class="badge <?php echo e($seccion->estado_id == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($seccion->estado_id == 1 ? 'Activa' : 'Inactiva'); ?>

                                </span>
                            </div>
                            <div class="card-body">
                                <p class="card-text">
                                    <strong>Numeración:</strong> <?php echo e($seccion->numeracion ?? 'N/A'); ?><br>
                                    <strong>📦 Productos:</strong>
                                    <span class="badge <?php echo e($seccion->productos_count > 0 ? 'bg-primary' : 'bg-secondary'); ?>">
                                        <?php echo e($seccion->productos_count ?? 0); ?>

                                    </span><br>
                                    <strong>Creado:</strong> <?php echo e($seccion->created_at ? $seccion->created_at->format('d/m/Y') : 'N/A'); ?>

                                </p>
                            </div>
                            <div class="card-footer">
                                <div class="btn-group w-100" role="group">
                                    <button wire:click="editarSeccion(<?php echo e($seccion->id); ?>)"
                                            class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button wire:click="verProductos(<?php echo e($seccion->id); ?>)"
                                            class="btn btn-outline-info btn-sm">
                                        <i class="fas fa-box"></i> Productos
                                    </button>
                                    <button wire:click="eliminarSeccion(<?php echo e($seccion->id); ?>)"
                                            class="btn btn-outline-danger btn-sm"
                                            onclick="return confirm('¿Está seguro de eliminar esta sección? También se eliminarán todos sus productos.')">
                                        <i class="fas fa-trash"></i> Eliminar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="text-center alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <?php if($segmento): ?>
                                No se encontraron secciones para el segmento "<?php echo e($segmento->descripcion); ?>" con los criterios especificados.
                            <?php else: ?>
                                No se encontraron secciones con los criterios de búsqueda especificados.
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Paginación -->
            <?php if($secciones->hasPages()): ?>
                <div class="mt-3 d-flex justify-content-center">
                    <?php echo e($secciones->links()); ?>

                </div>
            <?php endif; ?>

        </div> 
    </div> 
</div> 
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\livewire\inventario\secciones.blade.php ENDPATH**/ ?>