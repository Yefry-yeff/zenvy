<div>
    <!-- Encabezado del reporte -->
    <table>
        <tr>
            <td colspan="8" style="font-size: 14px; font-weight: bold; background-color: #1F4E78; color: white;">
                REPORTE DE ACTORES
            </td>
        </tr>
        <tr>
            <td colspan="8"></td>
        </tr>
        <!-- Información del reporte -->
        <tr>
            <td colspan="8" style="font-size: 11px;">
                Fecha de exportación: <?php echo e($fechaExportacion); ?>

                <?php if($filtrosAplicados !== 'Ninguno'): ?>
                    <br>Filtros aplicados: <?php echo e($filtrosAplicados); ?>

                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td colspan="8"></td>
        </tr>
        <!-- Encabezados de columna -->
        <tr style="background-color: #2C7BE5; color: white; font-weight: bold;">
            <td>ID</td>
            <td>Actor</td>
            <td>Identidad</td>
            <td>Correo</td>
            <td>Tipo Persona</td>
            <td>Tipo Actor</td>
            <td>Estado</td>
        </tr>
        <!-- Datos -->
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cliente->id); ?></td>
            <td><?php echo e($cliente->nombre); ?></td>
            <td><?php echo e($cliente->identidad); ?></td>
            <td><?php echo e($cliente->correo); ?></td>
            <td><?php echo e(optional($cliente->tipoPersona)->nombre); ?></td>
            <td><?php echo e(optional($cliente->tipoCliente)->nombre); ?></td>
            <td><?php echo e(optional($cliente->estado)->nombre); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views\exports\clientes.blade.php ENDPATH**/ ?>