<div class="container mx-auto p-6">
    <div class="bg-white rounded-lg shadow-lg">
        <!-- Header -->
        <div class="bg-gradient-to-r from-orange-600 to-orange-700 text-white p-6 rounded-t-lg">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold flex items-center">
                        <i class="fas fa-balance-scale mr-3"></i>
                        Gestión de Diferencias
                    </h1>
                    <p class="text-orange-100 mt-1">Administrar diferencias de caja por tienda</p>
                </div>
                <div class="text-right">
                    <div class="text-sm text-orange-100">Usuario</div>
                    <div class="font-semibold"><?php echo e(Auth::user()->name); ?></div>
                    <!--[if BLOCK]><![endif]--><?php if($nombreTienda): ?>
                        <div class="text-xs text-orange-200 mt-1">
                            <i class="fas fa-store mr-1"></i>
                            <?php echo e($nombreTienda); ?>

                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <!-- Contenido Principal -->
        <div class="p-6">
            <!-- Mensajes -->
            <!--[if BLOCK]><![endif]--><?php if($mensaje): ?>
                <div class="mb-6 p-4 rounded-lg <?php echo e($tipoMensaje === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : ($tipoMensaje === 'error' ? 'bg-red-50 border border-red-200 text-red-800' : 'bg-blue-50 border border-blue-200 text-blue-800')); ?>">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <i class="fas <?php echo e($tipoMensaje === 'success' ? 'fa-check-circle text-green-500' : ($tipoMensaje === 'error' ? 'fa-exclamation-triangle text-red-500' : 'fa-info-circle text-blue-500')); ?> mr-3"></i>
                            <span class="font-medium"><?php echo e($mensaje); ?></span>
                        </div>
                        <button wire:click="limpiarMensaje" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($tiendaUsuario && $mensaje === ''): ?>
                <!-- Información de la Tienda -->
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                    <h4 class="font-semibold text-blue-800 mb-2">
                        <i class="fas fa-info-circle text-blue-500 mr-2"></i>
                        Diferencias de <?php echo e($nombreTienda); ?>

                    </h4>
                    <p class="text-sm text-blue-700">
                        Mostrando todas las cajas con diferencias de efectivo de su tienda. Haga clic en una fila para gestionar la diferencia.
                    </p>
                </div>

                <!-- Filtros -->
                <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-800">
                            <i class="fas fa-filter mr-2 text-orange-500"></i>
                            Filtros de Búsqueda
                        </h3>
                        <button wire:click="limpiarFiltros" class="px-3 py-1.5 text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition-colors">
                            <i class="fas fa-times mr-1"></i>
                            Limpiar Filtros
                        </button>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                        <!-- Filtro por Caja -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Caja</label>
                            <input type="text"
                                   wire:model.live.debounce.300ms="filtroCaja"
                                   placeholder="ID de caja..."
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                        </div>

                        <!-- Filtro por Usuario -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Usuario</label>
                            <input type="text"
                                   wire:model.live.debounce.300ms="filtroUsuario"
                                   placeholder="Nombre del usuario..."
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                        </div>

                        <!-- Filtro por Tipo de Cierre -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Tipo de Cierre</label>
                            <select wire:model.live="filtroTipoCierre" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500">
                                <option value="">Todos</option>
                                <option value="caja">Cierre de Caja</option>
                                <option value="jornada">Cierre de Jornada</option>
                            </select>
                        </div>

                        <!-- Filtro por Estado -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Estado</label>
                            <select wire:model.live="filtroEstado" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500">
                                <option value="">Todos</option>
                                <option value="pendiente">Pendiente</option>
                                <option value="resuelto">Resuelto</option>
                            </select>
                        </div>

                        <!-- Filtro por Fecha Desde -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Fecha Desde</label>
                            <input type="date"
                                   wire:model.live="filtroFechaDesde"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                        </div>

                        <!-- Filtro por Fecha Hasta -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Fecha Hasta</label>
                            <input type="date"
                                   wire:model.live="filtroFechaHasta"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                        </div>
                    </div>
                </div>

                <!-- Lista de Diferencias -->
                <!--[if BLOCK]><![endif]--><?php if($diferencias->count() > 0): ?>
                    <div class="bg-white border border-gray-200 rounded-lg overflow-hidden">
                        <div class="bg-gray-50 px-6 py-3 border-b border-gray-200 flex items-center justify-between">
                            <h3 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-list mr-2 text-orange-500"></i>
                                Cajas con Diferencias (<?php echo e($diferencias->total()); ?>)
                            </h3>
                            <button wire:click="descargarExcel"
                                    class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition-colors">
                                <i class="fas fa-file-excel mr-2"></i>
                                Exportar a Excel
                            </button>
                        </div>

                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-cash-register mr-1"></i>
                                            Caja
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-user mr-1"></i>
                                            Usuario
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-door-closed mr-1"></i>
                                            Tipo de Cierre
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-calendar mr-1"></i>
                                            Fecha del Cierre
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-calculator mr-1"></i>
                                            Diferencia Original
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-check-circle mr-1"></i>
                                            Gestionado
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-exclamation-triangle mr-1"></i>
                                            Pendiente
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <i class="fas fa-cogs mr-1"></i>
                                            Estado
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $diferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diferencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-orange-50 cursor-pointer transition-colors duration-150" 
                                            wire:click="abrirModal(<?php echo e($diferencia->cierre_id); ?>)">
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <div class="flex-shrink-0 h-8 w-8">
                                                        <div class="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center">
                                                            <i class="fas fa-cash-register text-orange-600 text-sm"></i>
                                                        </div>
                                                    </div>
                                                    <div class="ml-3">
                                                        <div class="text-sm font-medium text-gray-900">
                                                            Caja #<?php echo e($diferencia->caja_id); ?>

                                                        </div>
                                                        <div class="text-sm text-gray-500">
                                                            ID Cierre: <?php echo e($diferencia->cierre_id); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo e($diferencia->nombre_usuario); ?>

                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    ID: <?php echo e($diferencia->users_id); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <!--[if BLOCK]><![endif]--><?php if($diferencia->tipo_cierre == 1): ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                        <i class="fas fa-cash-register mr-1"></i>
                                                        Cierre de Caja
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                                        <i class="fas fa-calendar-day mr-1"></i>
                                                        Cierre de Jornada
                                                    </span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e(\Carbon\Carbon::parse($diferencia->created_at)->format('d/m/Y')); ?>

                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    <?php echo e(\Carbon\Carbon::parse($diferencia->created_at)->format('H:i:s')); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($diferencia->diferencia_efectivo > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                                    <i class="fas <?php echo e($diferencia->diferencia_efectivo > 0 ? 'fa-plus' : 'fa-minus'); ?> mr-1"></i>
                                                    L. <?php echo e(number_format(abs($diferencia->diferencia_efectivo), 2)); ?>

                                                </span>
                                                <div class="text-xs text-gray-500 mt-1">
                                                    <?php echo e($diferencia->diferencia_efectivo > 0 ? 'Sobrante' : 'Faltante'); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-blue-600">
                                                    L. <?php echo e(number_format($diferencia->total_gestionado, 2)); ?>

                                                </div>
                                                <div class="text-xs text-gray-500">
                                                    <?php echo e($diferencia->gestiones_realizadas); ?> gestión(es)
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e(abs($diferencia->diferencia_pendiente) < 0.01 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                    <i class="fas <?php echo e(abs($diferencia->diferencia_pendiente) < 0.01 ? 'fa-check' : 'fa-clock'); ?> mr-1"></i>
                                                    L. <?php echo e(number_format(abs($diferencia->diferencia_pendiente), 2)); ?>

                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <!--[if BLOCK]><![endif]--><?php if(abs($diferencia->diferencia_pendiente) < 0.01): ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                        <i class="fas fa-check-circle mr-1"></i>
                                                        Resuelto
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                                        <i class="fas fa-exclamation-circle mr-1"></i>
                                                        Pendiente
                                                    </span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>

                        <!-- Paginación -->
                        <div class="bg-gray-50 px-6 py-3 border-t border-gray-200">
                            <?php echo e($diferencias->links()); ?>

                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                        <i class="fas fa-balance-scale text-gray-400 text-4xl mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900 mb-2">No hay diferencias pendientes</h3>
                        <p class="text-gray-600 mb-4">No se encontraron cajas con diferencias de efectivo en su tienda con los filtros aplicados.</p>
                        <button 
                            wire:click="limpiarFiltros"
                            class="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                        >
                            <i class="fas fa-sync-alt mr-2"></i>
                            Limpiar Filtros
                        </button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- Modal de Gestión de Diferencia -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModal && $diferenciaSeleccionada): ?>
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" wire:click="cerrarModal">
            <div class="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-96 overflow-y-auto" wire:click.stop>
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold text-gray-900 flex items-center">
                        <i class="fas fa-edit text-orange-500 mr-3"></i>
                        Ajustar Diferencia
                    </h3>
                    <button wire:click="cerrarModal" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>

                <!-- Información de la Transacción -->
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                    <h4 class="font-semibold text-blue-800 mb-3">
                        <i class="fas fa-info-circle text-blue-500 mr-2"></i>
                        Información de la Transacción
                    </h4>
                    <div class="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <strong class="text-gray-700">Caja:</strong>
                            <span class="text-gray-900">#<?php echo e($diferenciaSeleccionada->caja_id); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Usuario:</strong>
                            <span class="text-gray-900"><?php echo e($diferenciaSeleccionada->nombre_usuario); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Fecha del cierre:</strong>
                            <span class="text-gray-900"><?php echo e(\Carbon\Carbon::parse($diferenciaSeleccionada->created_at)->format('d/m/Y H:i:s')); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Total esperado:</strong>
                            <span class="text-gray-900">L. <?php echo e(number_format($diferenciaSeleccionada->total_efectivo, 2)); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Total contado:</strong>
                            <span class="text-gray-900">L. <?php echo e(number_format($diferenciaSeleccionada->conteo_efectivo, 2)); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Diferencia original:</strong>
                            <span class="font-bold <?php echo e($diferenciaSeleccionada->diferencia_efectivo > 0 ? 'text-green-600' : 'text-red-600'); ?>">
                                <?php echo e($diferenciaSeleccionada->diferencia_efectivo > 0 ? '+' : ''); ?>L. <?php echo e(number_format($diferenciaSeleccionada->diferencia_efectivo, 2)); ?>

                                (<?php echo e($diferenciaSeleccionada->diferencia_efectivo > 0 ? 'Sobrante' : 'Faltante'); ?>)
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Estado Actual -->
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                    <h4 class="font-semibold text-yellow-800 mb-3">
                        <i class="fas fa-chart-line text-yellow-500 mr-2"></i>
                        Estado Actual de la Diferencia
                    </h4>
                    <div class="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <strong class="text-gray-700">Total gestionado:</strong>
                            <span class="text-blue-600 font-medium">L. <?php echo e(number_format($diferenciaSeleccionada->total_gestionado, 2)); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Diferencia pendiente:</strong>
                            <span class="font-bold <?php echo e(abs($diferenciaSeleccionada->diferencia_pendiente) < 0.01 ? 'text-green-600' : 'text-orange-600'); ?>">
                                L. <?php echo e(number_format(abs($diferenciaSeleccionada->diferencia_pendiente), 2)); ?>

                            </span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Gestiones realizadas:</strong>
                            <span class="text-gray-900"><?php echo e($diferenciaSeleccionada->gestiones_realizadas); ?></span>
                        </div>
                        <div>
                            <strong class="text-gray-700">Estado:</strong>
                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php echo e(abs($diferenciaSeleccionada->diferencia_pendiente) < 0.01 ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'); ?>">
                                <?php echo e(abs($diferenciaSeleccionada->diferencia_pendiente) < 0.01 ? 'Resuelto' : 'Pendiente'); ?>

                            </span>
                        </div>
                    </div>
                </div>

                <!-- Historial de Gestiones -->
                <!--[if BLOCK]><![endif]--><?php if(count($historialGestiones) > 0): ?>
                    <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
                        <h4 class="font-semibold text-gray-800 mb-3">
                            <i class="fas fa-history text-purple-500 mr-2"></i>
                            Historial de Gestiones (<?php echo e(count($historialGestiones)); ?>)
                        </h4>
                        <div class="space-y-3 max-h-40 overflow-y-auto">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $historialGestiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="bg-white border border-gray-100 rounded-lg p-3">
                                    <div class="flex items-start justify-between">
                                        <div class="flex-1">
                                            <div class="flex items-center space-x-3 mb-2">
                                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php echo e($gestion->monto > 0 ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'); ?>">
                                                    <i class="fas <?php echo e($gestion->monto > 0 ? 'fa-plus' : 'fa-minus'); ?> mr-1"></i>
                                                    <?php echo e($gestion->monto > 0 ? '+' : ''); ?>L. <?php echo e(number_format($gestion->monto, 2)); ?>

                                                </span>
                                                <span class="text-sm text-gray-600">
                                                    <?php echo e($gestion->monto > 0 ? 'Reduce diferencia' : 'Aumenta diferencia'); ?>

                                                </span>
                                            </div>
                                            <p class="text-sm text-gray-700 mb-2"><?php echo e($gestion->descripcion); ?></p>
                                            <div class="flex items-center space-x-4 text-xs text-gray-500">
                                                <span>
                                                    <i class="fas fa-user mr-1"></i>
                                                    <?php echo e($gestion->gestor_nombre); ?>

                                                </span>
                                                <span>
                                                    <i class="fas fa-clock mr-1"></i>
                                                    <?php echo e(\Carbon\Carbon::parse($gestion->created_at)->format('d/m/Y H:i:s')); ?>

                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if(abs($diferenciaSeleccionada->diferencia_pendiente) >= 0.01): ?>
                    <!-- Formulario de Gestión -->
                    <form wire:submit.prevent="gestionarDiferencia" class="space-y-4">
                        <div>
                            <label for="monto" class="block text-sm font-medium text-gray-700 mb-2">
                                <i class="fas fa-dollar-sign text-green-500 mr-2"></i>
                                Monto del Ajuste
                            </label>
                            <input 
                                type="number" 
                                id="monto"
                                wire:model="monto"
                                step="0.01"
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 <?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="<?php echo e($diferenciaSeleccionada->diferencia_efectivo > 0 ? 'Para reducir sobrante: -50' : 'Para reducir faltante: +100'); ?>"
                                required
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="mt-2 p-3 border rounded-lg <?php echo e($diferenciaSeleccionada->diferencia_efectivo > 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'); ?>">
                                <!--[if BLOCK]><![endif]--><?php if($diferenciaSeleccionada->diferencia_efectivo > 0): ?>
                                    <!-- SOBRANTE -->
                                    <h5 class="text-sm font-semibold text-green-800 mb-2">
                                        <i class="fas fa-arrow-up mr-1"></i>
                                        SOBRANTE de L. <?php echo e(number_format(abs($diferenciaSeleccionada->diferencia_efectivo), 2)); ?>

                                    </h5>
                                    <ul class="text-xs text-green-700 space-y-1">
                                        <li><strong>Para REDUCIR el sobrante:</strong> Ingrese valor negativo (ej: <code>-50</code> para reducir L. 50.00)</li>
                                        <li><strong>Para AUMENTAR el sobrante:</strong> Ingrese valor positivo (ej: <code>+25</code> para aumentar L. 25.00)</li>
                                        <li><em>💡 Ejemplo: Si tiene L. 100 de sobrante y aplica -100, la diferencia queda en L. 0.00</em></li>
                                    </ul>
                                <?php else: ?>
                                    <!-- FALTANTE -->
                                    <h5 class="text-sm font-semibold text-red-800 mb-2">
                                        <i class="fas fa-arrow-down mr-1"></i>
                                        FALTANTE de L. <?php echo e(number_format(abs($diferenciaSeleccionada->diferencia_efectivo), 2)); ?>

                                    </h5>
                                    <ul class="text-xs text-red-700 space-y-1">
                                        <li><strong>Para REDUCIR el faltante:</strong> Ingrese valor positivo (ej: <code>+100</code> para reducir L. 100.00)</li>
                                        <li><strong>Para AUMENTAR el faltante:</strong> Ingrese valor negativo (ej: <code>-50</code> para aumentar L. 50.00)</li>
                                        <li><em>💡 Ejemplo: Si faltan L. 100 y aplica +100, la diferencia queda en L. 0.00</em></li>
                                    </ul>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="mt-2 pt-2 border-t border-gray-200">
                                    <p class="text-xs text-gray-600">🔄 Puede realizar múltiples ajustes hasta cerrar completamente la diferencia</p>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label for="descripcion" class="block text-sm font-medium text-gray-700 mb-2">
                                <i class="fas fa-comment text-blue-500 mr-2"></i>
                                Descripción / Justificación del Ajuste
                            </label>
                            <textarea 
                                id="descripcion"
                                wire:model="descripcion"
                                rows="4"
                                maxlength="400"
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Describa la justificación para este ajuste en la diferencia. Explique si es un ajuste positivo (reduce diferencia) o negativo (aumenta diferencia) y el motivo..."
                                required
                            ></textarea>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <p class="text-xs text-gray-500 mt-1">
                                Máximo 400 caracteres. Explique claramente el motivo del ajuste y su tipo.
                            </p>
                        </div>

                        <!-- Botones del Modal -->
                        <div class="flex justify-end space-x-4 pt-4">
                            <button 
                                type="button"
                                wire:click="cerrarModal"
                                class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium transition-colors"
                            >
                                <i class="fas fa-times mr-2"></i>
                                Cancelar
                            </button>
                            <button 
                                type="submit"
                                class="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 font-medium transition-colors"
                                wire:loading.attr="disabled"
                            >
                                <i class="fas fa-save mr-2"></i>
                                <span wire:loading.remove>Registrar Ajuste</span>
                                <span wire:loading>Procesando...</span>
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-check-circle text-green-500 text-3xl mb-2"></i>
                        <p class="text-green-700 font-medium">Esta diferencia ya ha sido completamente gestionada.</p>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de Éxito -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarModalExito): ?>
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" wire:click="cerrarModalExito">
            <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4" wire:click.stop>
                <!-- Header del Modal -->
                <div class="bg-gradient-to-r <?php echo e($diferenciaTotalmenteResuelta ? 'from-green-600 to-green-700' : 'from-blue-600 to-blue-700'); ?> text-white p-6 rounded-t-lg">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <i class="fas <?php echo e($diferenciaTotalmenteResuelta ? 'fa-check-circle' : 'fa-info-circle'); ?> text-3xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold"><?php echo e($tituloExito); ?></h3>
                            <p class="text-sm opacity-90 mt-1">Gestión de Diferencia</p>
                        </div>
                    </div>
                </div>

                <!-- Contenido del Modal -->
                <div class="p-6">
                    <div class="mb-6">
                        <p class="text-gray-700 leading-relaxed"><?php echo e($mensajeExito); ?></p>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($diferenciaTotalmenteResuelta): ?>
                        <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                            <div class="flex items-center">
                                <i class="fas fa-check-circle text-green-500 mr-3"></i>
                                <div>
                                    <h4 class="font-semibold text-green-800">Transacción Cerrada</h4>
                                    <p class="text-sm text-green-700">La diferencia ha sido completamente resuelta y la transacción se ha cerrado exitosamente.</p>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                            <div class="flex items-center">
                                <i class="fas fa-clock text-blue-500 mr-3"></i>
                                <div>
                                    <h4 class="font-semibold text-blue-800">Transacción Abierta</h4>
                                    <p class="text-sm text-blue-700">La diferencia aún tiene monto pendiente por gestionar. La transacción permanece abierta para futuras gestiones.</p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Footer del Modal -->
                <div class="bg-gray-50 px-6 py-4 rounded-b-lg">
                    <div class="flex justify-end">
                        <button 
                            wire:click="cerrarModalExito"
                            class="px-6 py-2 bg-gradient-to-r <?php echo e($diferenciaTotalmenteResuelta ? 'from-green-600 to-green-700 hover:from-green-700 hover:to-green-800' : 'from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800'); ?> text-white rounded-lg font-medium shadow-lg transform hover:scale-105 transition-all duration-200"
                        >
                            <i class="fas fa-check mr-2"></i>
                            Aceptar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/caja/gestion-de-diferencias.blade.php ENDPATH**/ ?>