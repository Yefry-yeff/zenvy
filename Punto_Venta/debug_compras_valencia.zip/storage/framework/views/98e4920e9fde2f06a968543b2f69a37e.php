<table>
    <thead>
        <tr>
            <th colspan="8" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #4472C4; color: white;">
                📦 LISTADO DE PRODUCTOS
            </th>
        </tr>
        <tr>
            <th colspan="8" style="font-size: 12px; text-align: center; color: #666;">
                Sistema ZENVY - Gestión de Inventario
            </th>
        </tr>
        <tr>
            <th colspan="8"></th>
        </tr>
        <tr>
            <th colspan="8" style="font-size: 10px; text-align: center; background-color: #F8F9FA;">
                📅 Generado el: <?php echo e($fechaGeneracion); ?> | 👤 Usuario: <?php echo e($usuarioReporte ?? '-'); ?> | 📊 Total: <?php echo e($totalProductos); ?> productos | 🔍 Filtros: <?php echo e($filtrosAplicados); ?>

            </th>
        </tr>
        <tr>
            <th colspan="8"></th>
        </tr>
        <tr>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">ID</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Código de Barras</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Nombre</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Marca</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Categoría</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Subcategoría</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Precio Base</th>
            <th style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">Origen</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: center;"><?php echo e($producto->id); ?></td>
                <td><?php echo e(isset($producto->codigo_barra) && $producto->codigo_barra !== '' ? "'" . $producto->codigo_barra : 'Sin código'); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->marca->nombre ?? 'Sin marca'); ?></td>
                <td><?php echo e($producto->subcategoria->categoria->nombre ?? 'N/A'); ?></td>
                <td><?php echo e($producto->subcategoria->nombre ?? 'N/A'); ?></td>
                <td style="text-align: right; font-weight: bold; color: #28A745;">L. <?php echo e(number_format($producto->precio_base, 2)); ?></td>
                <td style="text-align: center; background-color: <?php echo e($producto->producto_valencia ? '#FFF3CD' : '#D4EDDA'); ?>;">
                    <?php echo e($producto->producto_valencia ? '🏢 Valencia' : '🏠 Paperland'); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/exports/productos.blade.php ENDPATH**/ ?>