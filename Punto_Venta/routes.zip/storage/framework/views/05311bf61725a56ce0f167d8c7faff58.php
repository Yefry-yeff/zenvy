<div> 

    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 mb-4 font-semibold text-white rounded-t"
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <h5 class="mb-0 text-lg">
                <i class="fas fa-cubes me-2"></i>
                <!--[if BLOCK]><![endif]--><?php if($isEditing): ?>
                    Editar Stock de Producto
                <?php else: ?>
                    Gestión de Stock
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </h5>
            <button wire:click="volverAProductos"
                class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                <span>←</span> Volver
            </button>
        </div>

        <!-- FORMULARIO -->
        <div class="px-5 py-4">
            <form wire:submit.prevent="guardar">

                <!-- Información del Producto -->
                <!--[if BLOCK]><![endif]--><?php if($producto): ?>
                <div class="p-4 mb-4">
                    <div class="p-4 bg-white border shadow rounded-xl">
                        <h2 class="mb-4 text-lg font-semibold text-gray-700">📦 Información del Producto</h2>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <strong><i class="fas fa-tag text-primary me-2"></i>Producto:</strong><br>
                                    <?php echo e($producto->nombre); ?>

                                </div>
                                <div class="mb-3">
                                    <strong><i class="fas fa-align-left text-info me-2"></i>Descripción:</strong><br>
                                    <?php echo e($producto->descripcion ?? 'Sin descripción'); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <strong><i class="fas fa-copyright text-warning me-2"></i>Marca:</strong><br>
                                    <?php echo e($producto->marca->nombre ?? 'Sin marca'); ?>

                                </div>
                                <div class="mb-3">
                                    <strong><i class="fas fa-balance-scale text-success me-2"></i>Unidad de Medida:</strong><br>
                                    <?php echo e($producto->unidadMedidaCompra->nombre ?? 'N/A'); ?>

                                </div>
                            </div>
                        </div>

                        <!--[if BLOCK]><![endif]--><?php if($recibido && $recibido->seccion): ?>
                        <div class="p-3 mt-3 rounded bg-light">
                            <h6 class="mb-2 text-muted"><i class="fas fa-map-marker-alt me-2"></i>Ubicación en Inventario:</h6>
                            <div class="flex-wrap gap-2 d-flex">
                                <span class="badge bg-primary">
                                    <i class="fas fa-store me-1"></i><?php echo e($recibido->seccion->segmento->bodega->tienda->denominacion_social ?? 'N/A'); ?>

                                </span>
                                <span class="badge bg-info">
                                    <i class="fas fa-warehouse me-1"></i><?php echo e($recibido->seccion->segmento->bodega->nombre ?? 'N/A'); ?>

                                </span>
                                <span class="badge bg-success">
                                    <i class="fas fa-layer-group me-1"></i><?php echo e($recibido->seccion->segmento->descripcion ?? 'N/A'); ?>

                                </span>
                                <span class="badge bg-warning">
                                    <i class="fas fa-cube me-1"></i><?php echo e($recibido->seccion->descripcion); ?> (<?php echo e($recibido->seccion->numeracion); ?>)
                                </span>
                            </div>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Gestión de Stock -->
                <div class="p-4">
                    <div class="p-4 bg-white border shadow rounded-xl">
                        <h2 class="mb-4 text-lg font-semibold text-gray-700">📊 Nueva Distribución de Stock</h2>

                        <!-- Primera fila: Cantidad asignada en bodega, Asignación Inicial en Sección, Stock Disponible en sección -->
                        <div class="row">
                            <!-- Cantidad Asignada en Bodega (Clickeable para ver detalle) -->
                            <div class="mb-3 col-md-4">
                                <label for="cantidad_asignada_bodega" class="form-label">
                                    Cantidad Asignada en Bodega
                                    <small class="text-muted d-block">Suma de todas las secciones</small>
                                </label>
                                <div class="input-group">
                                    <input type="number"
                                           id="cantidad_asignada_bodega"
                                           class="form-control bg-light"
                                           value="<?php echo e($cantidadTotalBodega); ?>"
                                           readonly>
                                    <button class="btn btn-outline-primary"
                                            type="button"
                                            wire:click="mostrarModalSecciones"
                                            title="Ver distribución por secciones">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <small class="text-info">
                                    <i class="fas fa-warehouse me-1"></i>Total en bodega - <i class="fas fa-mouse-pointer me-1"></i>Clic en 🔍 para ver distribución
                                </small>
                            </div>

                            <!-- Asignación Inicial en Sección -->
                            <div class="mb-3 col-md-4">
                                <label for="asignacion_inicial_seccion" class="form-label">
                                    Asignación Inicial en Sección
                                    <small class="text-muted d-block">Cantidad inicialmente asignada</small>
                                </label>
                                <input type="number"
                                       id="asignacion_inicial_seccion"
                                       class="form-control bg-light"
                                       value="<?php echo e($recibido->cantidad_inicial_seccion ?? 0); ?>"
                                       readonly>
                                <small class="text-info">
                                    <i class="fas fa-layer-group me-1"></i>Asignación inicial en esta sección
                                </small>
                            </div>

                            <!-- Stock Disponible en sección -->
                            <div class="mb-3 col-md-4">
                                <label for="stock_disponible_seccion" class="form-label">
                                    Stock Disponible en Sección
                                    <small class="text-muted d-block">Cantidad disponible actual</small>
                                </label>
                                <input type="number"
                                       id="stock_disponible_seccion"
                                       class="form-control bg-light"
                                       value="<?php echo e($recibido->cantidad_disponible ?? 0); ?>"
                                       readonly>
                                <small class="text-info">
                                    <i class="fas fa-box me-1"></i>Stock actual disponible en sección
                                </small>
                            </div>
                        </div>
                        <!-- Segunda fila: Cantidad a distribuir, Precio unitario, Medida de unidad, Precio total -->
                        <div class="row">
                            <!-- Cantidad a Distribuir -->
                            <div class="mb-3 col-md-3">
                                <label for="cantidad_distribuir" class="form-label">
                                    Cantidad a Distribuir <span class="text-red-600">*</span>
                                    <small class="text-muted d-block">Cantidad para esta distribución</small>
                                </label>
                                <input type="number"
                                       id="cantidad_distribuir"
                                       class="form-control <?php echo e($this->getClaseCampo('cantidad_distribuir')); ?>"
                                       wire:model.live="form.cantidad_distribuir"
                                       placeholder="Ej: 25"
                                       min="1"
                                       max="<?php echo e($stockDisponible ?? 999999); ?>">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.cantidad_distribuir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="mt-1 text-sm text-danger">❌ <?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($stockDisponible > 0): ?>
                                    <small class="text-info">Máximo disponible: <?php echo e($stockDisponible); ?></small>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!-- Precio Unitario -->
                            <div class="mb-3 col-md-3">
                                <label for="precio_unitario" class="form-label">
                                    Precio Unitario (LPS)
                                    <small class="text-muted d-block">Precio base del producto (no editable)</small>
                                </label>
                                <input type="text"
                                       id="precio_unitario"
                                       class="form-control bg-light"
                                       value="L. <?php echo e(number_format($producto->precio_base ?? 0, 2)); ?>"
                                       readonly>
                            </div>

                            <!-- Medida de unidad (readonly, del producto) -->
                            <div class="mb-3 col-md-3">
                                <label for="unidad_medida" class="form-label">
                                    Medida de Unidad
                                    <small class="text-muted d-block">Del producto (no editable)</small>
                                </label>
                                <input type="text"
                                       id="unidad_medida"
                                       class="form-control bg-light"
                                       value="<?php echo e($producto->unidadMedidaCompra->nombre ?? 'N/A'); ?>"
                                       readonly>
                            </div>

                            <!-- Precio Total (Calculado) -->
                            <div class="mb-3 col-md-3">
                                <label for="precio_total" class="form-label">
                                    Precio Total (LPS)
                                    <small class="text-muted d-block">Calculado automáticamente</small>
                                </label>
                                <input type="text"
                                       id="precio_total"
                                       class="form-control bg-light"
                                       value="L. <?php echo e(number_format((float)($form['cantidad_distribuir'] ?? 0) * (float)($producto->precio_base ?? 0), 2)); ?>"
                                       readonly>
                                <small class="text-info">
                                    <i class="fas fa-calculator me-1"></i><?php echo e($form['cantidad_distribuir'] ?? 0); ?> × L. <?php echo e(number_format((float)($producto->precio_base ?? 0), 2)); ?>

                                </small>
                            </div>
                        </div>

                        <!-- Tercera fila: Selección de destino (Bodega, Segmento, Sección) -->
                        <div class="row">
                            <div class="col-12">
                                <h6 class="text-primary mb-3">
                                    <i class="fas fa-map-marker-alt me-2"></i>Destino de la Distribución
                                </h6>
                            </div>

                            <!-- Bodega -->
                            <div class="mb-3 col-md-4">
                                <label for="bodega_destino" class="form-label">
                                    Bodega Destino <span class="text-red-600">*</span>
                                    <small class="text-muted d-block">Selecciona la bodega destino</small>
                                </label>
                                <select id="bodega_destino"
                                        class="form-select <?php echo e($this->getClaseCampo('bodega_destino')); ?>"
                                        wire:model.live="form.bodega_destino"
                                        wire:change="cargarSegmentosPorBodega">
                                    <option value="">Seleccionar bodega...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bodega->id); ?>"><?php echo e($bodega->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.bodega_destino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="mt-1 text-sm text-danger">❌ <?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!-- Segmento -->
                            <div class="mb-3 col-md-4">
                                <label for="segmento_destino" class="form-label">
                                    Segmento Destino <span class="text-red-600">*</span>
                                    <small class="text-muted d-block">Selecciona el segmento destino</small>
                                </label>
                                <select id="segmento_destino"
                                        class="form-select <?php echo e($this->getClaseCampo('segmento_destino')); ?>"
                                        wire:model.live="form.segmento_destino"
                                        wire:change="cargarSeccionesPorSegmento"
                                        <?php echo e(empty($segmentosDestino) ? 'disabled' : ''); ?>>
                                    <option value="">Seleccionar segmento...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $segmentosDestino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($segmento->id); ?>"><?php echo e($segmento->descripcion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.segmento_destino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="mt-1 text-sm text-danger">❌ <?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if(empty($segmentosDestino)): ?>
                                    <small class="text-muted">Selecciona una bodega primero</small>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <!-- Sección -->
                            <div class="mb-3 col-md-4">
                                <label for="seccion_destino" class="form-label">
                                    Sección Destino <span class="text-red-600">*</span>
                                    <small class="text-muted d-block">Selecciona la sección destino</small>
                                </label>
                                <select id="seccion_destino"
                                        class="form-select <?php echo e($this->getClaseCampo('seccion_destino')); ?>"
                                        wire:model.live="form.seccion_destino"
                                        <?php echo e(empty($seccionesDestino) ? 'disabled' : ''); ?>>
                                    <option value="">Seleccionar sección...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $seccionesDestino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($seccion->id); ?>"><?php echo e($seccion->descripcion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.seccion_destino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="mt-1 text-sm text-danger">❌ <?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if(empty($seccionesDestino)): ?>
                                    <small class="text-muted">Selecciona un segmento primero</small>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>

                        <!-- Comentario -->
                        <div class="mb-3">
                            <label for="comentario" class="form-label">
                                Comentario de la Distribución
                                <small class="text-muted">(Opcional)</small>
                            </label>
                            <textarea id="comentario"
                                      class="form-control <?php echo e($this->getClaseCampo('comentario')); ?>"
                                      wire:model.live="form.comentario"
                                      placeholder="Observaciones sobre esta distribución de stock..."
                                      rows="3"
                                      maxlength="400"></textarea>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="mt-1 text-sm text-danger">❌ <?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <small class="text-muted"><?php echo e(strlen($form['comentario'] ?? '')); ?>/400 caracteres</small>
                        </div>

                        <!-- Indicadores visuales -->
                        <!--[if BLOCK]><![endif]--><?php if(isset($form['cantidad_asignada_bodega']) && $form['cantidad_asignada_bodega'] > 0): ?>
                        <div class="p-3 mt-4 rounded bg-light">
                            <h6 class="mb-2 text-success"><i class="fas fa-chart-bar me-2"></i>Resumen de Stock:</h6>
                            <div class="text-center row">
                                <div class="col-md-3">
                                    <div class="p-2 text-white rounded bg-primary">
                                        <strong><?php echo e($form['cantidad_asignada_bodega'] ?? 0); ?></strong><br>
                                        <small>Total Recibido</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="p-2 text-white rounded bg-success">
                                        <strong><?php echo e($totalDistribuido ?? 0); ?></strong><br>
                                        <small>Total Distribuido</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="p-2 text-white rounded bg-info">
                                        <strong><?php echo e($stockDisponible ?? 0); ?></strong><br>
                                        <small>Disponible</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="p-2 text-white rounded bg-warning">
                                        <strong><?php echo e(count($distribuciones ?? [])); ?></strong><br>
                                        <small>Distribuciones</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Historial de Distribuciones -->
                <!--[if BLOCK]><![endif]--><?php if(!empty($distribuciones) && count($distribuciones) > 0): ?>
                <div class="p-4">
                    <div class="p-4 bg-white border shadow rounded-xl">
                        <h2 class="mb-4 text-lg font-semibold text-gray-700">📋 Historial de Distribuciones</h2>

                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th class="text-center">ID</th>
                                        <th class="text-center">Estado</th>
                                        <th class="text-center">Fecha Distribución</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio Unit.</th>
                                        <th class="text-center">Unidad de Venta</th>
                                        <th class="text-center">Total</th>
                                        <th class="text-center">Origen/Destino (Bodega → Segmento → Sección)</th>
                                        <th class="text-center">Usuario</th>
                                        <th class="text-center">Creado</th>
                                        <th class="text-center">Comentario</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $distribuciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $distribucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center">
                                            <span class="badge bg-secondary"><?php echo e($loop->iteration); ?></span>
                                        </td>
                                        <td class="text-center">
                                            <!--[if BLOCK]><![endif]--><?php if(isset($distribucion['estado'])): ?>
                                                <!--[if BLOCK]><![endif]--><?php if($distribucion['estado'] === 'enviado'): ?>
                                                    <span class="badge bg-warning text-dark">
                                                        <i class="fas fa-paper-plane me-1"></i>Enviado
                                                    </span>
                                                <?php elseif($distribucion['estado'] === 'recibido'): ?>
                                                    <span class="badge bg-success">
                                                        <i class="fas fa-inbox me-1"></i>Recibido
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">
                                                        <i class="fas fa-question me-1"></i><?php echo e($distribucion['estado']); ?>

                                                    </span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php else: ?>
                                                <span class="badge bg-info">
                                                    <i class="fas fa-history me-1"></i>Histórico
                                                </span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                        <td class="text-center"><?php echo e(\Carbon\Carbon::parse($distribucion['fecha_distribucion'])->format('d/m/Y')); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-primary"><?php echo e($distribucion['cantidad_distribuida']); ?></span>
                                        </td>
                                        <td class="text-center">L. <?php echo e(number_format((float)$distribucion['precio_unitario'], 2)); ?></td>
                                        <td class="text-center"><?php echo e($distribucion['unidad_medida'] ?? 'N/A'); ?></td>
                                        <td class="text-center">
                                            <strong>L. <?php echo e(number_format((float)$distribucion['cantidad_distribuida'] * (float)$distribucion['precio_unitario'], 2)); ?></strong>
                                        </td>
                                        <td class="text-center">
                                            <small class="text-muted">
                                                <i class="fas fa-route me-1"></i><?php echo e($distribucion['traslado_a'] ?? 'N/A'); ?>

                                            </small>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info">
                                                <i class="fas fa-user me-1"></i><?php echo e($distribucion['usuario_nombre'] ?? 'N/A'); ?>

                                            </span>
                                        </td>
                                        <td class="text-center text-muted small">
                                            <i class="fas fa-clock me-1"></i><?php echo e($distribucion['created_at'] ?? 'Sin fecha'); ?>

                                        </td>
                                        <td class="text-center"><?php echo e($distribucion['comentario'] ?? 'Sin comentario'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                                <tfoot class="table-info">
                                    <tr>
                                        <th class="text-center">-</th>
                                        <th class="text-center">-</th>
                                        <th class="text-center">TOTALES:</th>
                                        <th class="text-center"><?php echo e($totalDistribuido ?? 0); ?></th>
                                        <th class="text-center">-</th>
                                        <th class="text-center">-</th>
                                        <th class="text-center">L. <?php echo e(number_format(
                                                array_sum(
                                                    array_map(
                                                        function($dist) {
                                                            // Solo sumar los enviados para evitar duplicar, o históricos sin estado
                                                            $estado = $dist['estado'] ?? 'historico';
                                                            return ($estado === 'enviado' || $estado === 'N/A' || $estado === 'historico') ?
                                                                (float)$dist['cantidad_distribuida'] * (float)$dist['precio_unitario'] : 0;
                                                        },
                                                        $distribuciones ?? []
                                                    )
                                                ),
                                                2
                                            )); ?></th>
                                        <th class="text-center">-</th>
                                        <th class="text-center">-</th>
                                        <th class="text-center">-</th>
                                        <th class="text-center">-</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Botones de Acción -->
                <div class="flex justify-end gap-3 mt-4">
                    <button type="button" wire:click="volverAProductos"
                        class="px-4 py-2 text-gray-700 bg-gray-200 rounded hover:bg-gray-300">
                        Cancelar
                    </button>

                    <!--[if BLOCK]><![endif]--><?php if($this->formularioCompleto): ?>
                        <!-- Botón habilitado cuando el formulario está completo -->
                        <button type="submit"
                            class="px-4 py-2 text-white transition-all duration-200 rounded"
                            :class="{
                                'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                                'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                                'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                                'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                            }">
                            <i class="fas fa-save me-2"></i>
                            Registrar Distribución
                        </button>
                    <?php else: ?>
                        <!-- Botón deshabilitado cuando faltan campos -->
                        <button type="button"
                            disabled
                            class="px-4 py-2 text-white transition-all duration-200 bg-gray-400 rounded cursor-not-allowed opacity-60"
                            title="Complete todos los campos obligatorios">
                            <i class="fas fa-save me-2"></i>
                            Registrar Distribución
                            <span class="ml-1">🔒</span>
                        </button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

            </form>
        </div>
    </div>

    <!-- Alerta de validación flotante -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarAlerta): ?>
        <div class="alert-campo-obligatorio">
            <strong>⚠️ Validación de Stock</strong>
            <button wire:click="cerrarAlerta" style="float: right; background: none; border: none; font-size: 18px; cursor: pointer;">×</button>
            <br><small><?php echo e($mensajeAlerta); ?></small>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de Éxito con Alpine.js -->
    <div x-data="{ open: <?php if ((object) ('mostrarModalExito') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarModalExito'->value()); ?>')<?php echo e('mostrarModalExito'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarModalExito'); ?>')<?php endif; ?> }"
         x-show="open"
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 transform scale-90"
         x-transition:enter-end="opacity-100 transform scale-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100 transform scale-100"
         x-transition:leave-end="opacity-0 transform scale-90"
         x-cloak
         class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         @click.self="$wire.cerrarModalExito()"
         @keydown.escape.window="$wire.cerrarModalExito()">

        <div class="w-full max-w-md mx-4">
            <div class="overflow-hidden bg-white rounded-lg shadow-xl">
                <!-- Header -->
                <div class="p-4 text-white bg-green-600">
                    <div class="flex items-center">
                        <svg class="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm3.707-9.293a1 1 0 0 0-1.414-1.414L9 10.586 7.707 9.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4z" clip-rule="evenodd"></path>
                        </svg>
                        <h3 class="text-lg font-semibold">¡Stock Actualizado!</h3>
                    </div>
                </div>

                <!-- Body -->
                <div class="p-6 text-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 mx-auto text-green-500" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm3.707-9.293a1 1 0 0 0-1.414-1.414L9 10.586 7.707 9.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <h4 class="mb-2 text-lg font-medium text-gray-900"><?php echo e($mensajeModalExito); ?></h4>
                    <p class="text-gray-600">Las cantidades de stock se han actualizado correctamente en el sistema.</p>
                </div>

                <!-- Footer -->
                <div class="px-6 py-3 text-center bg-gray-50">
                    <button wire:click="cerrarModalExito"
                            class="px-4 py-2 text-white transition-colors duration-200 bg-green-600 rounded-md hover:bg-green-700">
                        <svg class="inline w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.707 3.293a1 1 0 0 1 0 1.414L5.414 7H11a7 7 0 0 1 7 7v2a1 1 0 1 1-2 0v-2a5 5 0 0 0-5-5H5.414l2.293 2.293a1 1 0 1 1-1.414 1.414l-4-4a1 1 0 0 1 0-1.414l4-4a1 1 0 0 1 1.414 0z" clip-rule="evenodd"></path>
                        </svg>
                        Entendido
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Error con Alpine.js -->
    <div x-data="{ open: <?php if ((object) ('mostrarModalError') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarModalError'->value()); ?>')<?php echo e('mostrarModalError'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarModalError'); ?>')<?php endif; ?> }"
         x-show="open"
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 transform scale-90"
         x-transition:enter-end="opacity-100 transform scale-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100 transform scale-100"
         x-transition:leave-end="opacity-0 transform scale-90"
         x-cloak
         class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
         @click.self="$wire.cerrarModalError()"
         @keydown.escape.window="$wire.cerrarModalError()">

        <div class="w-full max-w-md mx-4">
            <div class="overflow-hidden bg-white rounded-lg shadow-xl">
                <!-- Header -->
                <div class="p-4 text-white bg-red-600">
                    <div class="flex items-center">
                        <svg class="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0zm-7 4a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-1-9a1 1 0 0 0-1 1v4a1 1 0 1 0 2 0V6a1 1 0 0 0-1-1z" clip-rule="evenodd"></path>
                        </svg>
                        <h3 class="text-lg font-semibold">Error en Stock</h3>
                    </div>
                </div>

                <!-- Body -->
                <div class="p-6 text-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 mx-auto text-red-500" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0zm-7 4a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-1-9a1 1 0 0 0-1 1v4a1 1 0 1 0 2 0V6a1 1 0 0 0-1-1z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <h4 class="mb-2 text-lg font-medium text-gray-900"><?php echo e($mensajeModalError); ?></h4>
                    <p class="text-gray-600">Por favor, revise las cantidades e intente nuevamente.</p>
                </div>

                <!-- Footer -->
                <div class="px-6 py-3 text-center bg-gray-50">
                    <button wire:click="cerrarModalError"
                            class="px-4 py-2 text-white transition-colors duration-200 bg-red-600 rounded-md hover:bg-red-700">
                        <svg class="inline w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 0 1 1.414 0L10 8.586l4.293-4.293a1 1 0 1 1 1.414 1.414L11.414 10l4.293 4.293a1 1 0 0 1-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 0 1-1.414-1.414L8.586 10 4.293 5.707a1 1 0 0 1 0-1.414z" clip-rule="evenodd"></path>
                        </svg>
                        Cerrar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Estilos CSS para validación -->
    <style>
        /* Campo con error - solo rojos */
        .is-invalid, .campo-obligatorio-vacio {
            border: 2px solid #dc3545 !important;
            background-color: #fff5f5 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
        }

        /* Mensaje de error personalizado */
        .text-danger {
            color: #dc3545 !important;
            font-size: 0.875rem;
            font-weight: 500;
        }

        /* Alerta flotante personalizada */
        .alert-campo-obligatorio {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            background: #f8d7da;
            color: #721c24;
            padding: 12px 16px;
            border-radius: 6px;
            font-size: 14px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            border-left: 4px solid #dc3545;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    </style>

    <!-- Modal para mostrar distribución por secciones -->
    <!-- Debug: modalSeccionesAbierto = <?php echo e($modalSeccionesAbierto ? 'true' : 'false'); ?> -->
    <!--[if BLOCK]><![endif]--><?php if($modalSeccionesAbierto): ?>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);" wire:click="cerrarModalSecciones">
            <div class="modal-dialog modal-lg modal-dialog-centered" wire:click.stop>
                <div class="modal-content">
                    <div class="modal-header text-white"
                         :class="{
                             'bg-emerald-600': theme === 'verde',
                             'bg-blue-600': theme === 'azul',
                             'bg-gray-900': theme === 'oscuro',
                             'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                         }">
                        <h5 class="modal-title">
                            🔍 <i class="fas fa-warehouse me-2"></i>Distribución por Secciones
                        </h5>
                        <button type="button" class="btn-close btn-close-white" wire:click="cerrarModalSecciones"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <h6 class="text-muted">
                                <i class="fas fa-box me-2"></i>Producto: <?php echo e($producto->nombre ?? 'N/A'); ?>

                            </h6>
                            <h6 class="text-muted">
                                <i class="fas fa-warehouse me-2"></i>Bodega: <?php echo e($recibido->seccion->segmento->bodega->nombre ?? 'N/A'); ?>

                            </h6>
                        </div>

                        <!-- Debug: Cantidad de secciones = <?php echo e(count($seccionesProducto)); ?> -->
                        <!--[if BLOCK]><![endif]--><?php if(!empty($seccionesProducto)): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th><i class="fas fa-layer-group me-1"></i>Sección</th>
                                            <th><i class="fas fa-cubes me-1"></i>Cantidad Inicial</th>
                                            <th><i class="fas fa-box me-1"></i>Cantidad Disponible</th>
                                            <th><i class="fas fa-calendar me-1"></i>Fecha Recibido</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $seccionesProducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="<?php echo e($seccion['seccion_actual'] ? 'table-warning' : ''); ?>">
                                                <td>
                                                    <?php echo e($seccion['nombre_seccion']); ?>

                                                    <!--[if BLOCK]><![endif]--><?php if($seccion['seccion_actual']): ?>
                                                        <span class="badge bg-warning text-dark ms-2">
                                                            <i class="fas fa-star me-1"></i>Sección Actual
                                                        </span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td>
                                                    <span class="badge bg-primary">
                                                        <?php echo e(number_format($seccion['cantidad_inicial'])); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo e($seccion['cantidad_disponible'] > 0 ? 'success' : 'secondary'); ?>">
                                                        <?php echo e(number_format($seccion['cantidad_disponible'])); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <small class="text-muted">
                                                        <?php echo e($seccion['fecha_recibido']); ?>

                                                    </small>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                    <tfoot class="table-light">
                                        <tr>
                                            <th>TOTAL</th>
                                            <th>
                                                <span class="badge bg-info">
                                                    <?php echo e(number_format(collect($seccionesProducto)->sum('cantidad_inicial'))); ?>

                                                </span>
                                            </th>
                                            <th>
                                                <span class="badge bg-success">
                                                    <?php echo e(number_format(collect($seccionesProducto)->sum('cantidad_disponible'))); ?>

                                                </span>
                                            </th>
                                            <th>-</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                No se encontraron registros de este producto en otras secciones de la bodega.
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="cerrarModalSecciones">
                            <i class="fas fa-times me-1"></i>Cerrar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/stock-form.blade.php ENDPATH**/ ?>