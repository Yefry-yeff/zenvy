<div>
    <style>
        /* Estilos para tabla CAI */
        .cai-row-active {
            background-color: rgba(34, 197, 94, 0.05) !important;
        }
        .cai-row-inactive {
            background-color: rgba(239, 68, 68, 0.05) !important;
            opacity: 0.7;
        }
        .badge-active {
            background-color: #22c55e !important;
            color: white;
            font-weight: 600;
        }
        .badge-inactive {
            background-color: #ef4444 !important;
            color: white;
            font-weight: 600;
        }
    </style>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('mensaje')): ?>
    <div x-data="{ show: true }" x-init="$nextTick(() => show = true)"
        x-show="show"
        x-transition
        style="display: none;"  
    >
        <div class="modal fade show d-block" tabindex="-1" role="dialog" @click.away="show = false">
            <div class="modal-dialog modal-dialog-centered" @click.stop>
                <div class="shadow modal-content border-success">
                    <div class="text-white modal-header bg-success">
                        <h5 class="modal-title">✅ Éxito</h5>
                        <button type="button" class="btn-close" @click="show = false"></button>
                    </div>
                    <div class="modal-body">
                        <p><?php echo e(session('mensaje')); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success" @click="show = false">Aceptar</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Backdrop manual -->
        <div class="modal-backdrop fade show" x-show="show" x-transition></div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
    <div x-data="{ show: true }" x-init="$nextTick(() => show = true)"
        x-show="show"
        x-transition
        style="display: none;"  
    >
        <div class="modal fade show d-block" tabindex="-1" role="dialog" @click.away="show = false">
            <div class="modal-dialog modal-dialog-centered modal-lg" @click.stop>
                <div class="shadow modal-content border-danger">
                    <div class="text-white modal-header bg-danger">
                        <h5 class="modal-title">❌ Error</h5>
                        <button type="button" class="btn-close btn-close-white" @click="show = false"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger mb-0">
                            <strong>Se ha producido un error:</strong>
                            <br><br>
                            <div class="font-monospace small bg-light p-2 rounded border">
                                <?php echo e(session('error')); ?>

                            </div>
                            <br>
                            <small class="text-muted">
                                <strong>Posibles causas:</strong>
                                <ul class="mb-0 mt-1">
                                    <li>Error de conexión con la base de datos</li>
                                    <li>Campos requeridos no completados correctamente</li>
                                    <li>Datos duplicados (CAI ya existe para esta tienda/documento)</li>
                                    <li>Formato incorrecto en fechas o campos numéricos</li>
                                    <li>Problemas de permisos en el servidor</li>
                                </ul>
                            </small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" @click="show = false">Entendido</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Backdrop manual -->
        <div class="modal-backdrop fade show" x-show="show" x-transition></div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal específico para errores de validación detallados -->
    <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
    <div x-data="{ show: true }" x-init="$nextTick(() => show = true)"
        x-show="show"
        x-transition
        style="display: none;"
    >
        <div class="modal fade show d-block" tabindex="-1" role="dialog" @click.away="show = false">
            <div class="modal-dialog modal-dialog-centered modal-lg" @click.stop>
                <div class="shadow modal-content border-warning">
                    <div class="text-white modal-header bg-warning">
                        <h5 class="modal-title">⚠️ Errores de Validación</h5>
                        <button type="button" class="btn-close btn-close-white" @click="show = false"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-warning mb-3">
                            <strong>Por favor, corrija los siguientes errores antes de continuar:</strong>
                        </div>
                        <ul class="list-group list-group-flush">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item border-0 py-1">
                                    <span class="text-danger">•</span> <?php echo e($error); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                        <br>
                        <div class="alert alert-info mb-0">
                            <small>
                                <strong>Tips:</strong>
                                <ul class="mb-0 mt-1">
                                    <li>Revise que todos los campos obligatorios estén completos</li>
                                    <li>Verifique el formato de las fechas (debe ser posterior a hoy para fecha límite)</li>
                                    <li>Asegúrese de que las cantidades sean números enteros positivos</li>
                                    <li>Confirme que ha seleccionado una tienda y tipo de documento</li>
                                </ul>
                            </small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning" @click="show = false">Entendido</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Backdrop manual -->
        <div class="modal-backdrop fade show" x-show="show" x-transition></div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Modal de debugging para errores técnicos -->
    <!--[if BLOCK]><![endif]--><?php if($mostrarErrorDebug && $errorDebugging): ?>
    <div x-data="{ show: <?php if ((object) ('mostrarErrorDebug') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarErrorDebug'->value()); ?>')<?php echo e('mostrarErrorDebug'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('mostrarErrorDebug'); ?>')<?php endif; ?> }" x-show="show" x-transition style="display: none;">
        <div class="modal fade show d-block" tabindex="-1" role="dialog" @click.away="show = false">
            <div class="modal-dialog modal-dialog-centered modal-xl" @click.stop>
                <div class="shadow modal-content border-danger">
                    <div class="text-white modal-header bg-dark">
                        <h5 class="modal-title">🐛 Error de Debugging - <?php echo e($errorDebugging['tipo'] ?? 'Desconocido'); ?></h5>
                        <button type="button" class="btn-close btn-close-white" wire:click="cerrarModalDebug"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger mb-3">
                            <strong><?php echo e($errorDebugging['mensaje'] ?? 'Error sin descripción'); ?></strong>
                            <br>
                            <small class="text-muted">Timestamp: <?php echo e($errorDebugging['timestamp'] ?? 'No disponible'); ?></small>
                        </div>
                        
                        <!--[if BLOCK]><![endif]--><?php if(isset($errorDebugging['detalles']) && is_array($errorDebugging['detalles'])): ?>
                            <div class="card">
                                <div class="card-header bg-light">
                                    <strong>Detalles Técnicos:</strong>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errorDebugging['detalles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item px-0">
                                                <code class="small"><?php echo e($detalle); ?></code>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        
                        <div class="alert alert-info mt-3 mb-0">
                            <strong>Para solucionar:</strong>
                            <ul class="mb-0 mt-2">
                                <li>Revisa los logs del servidor en: <code>storage/logs/laravel.log</code></li>
                                <li>Verifica la conexión a la base de datos</li>
                                <li>Confirma que todas las tablas existen y tienen la estructura correcta</li>
                                <li>Asegúrate de que los campos requeridos no sean nulos</li>
                                <!--[if BLOCK]><![endif]--><?php if(isset($errorDebugging['tipo']) && $errorDebugging['tipo'] === 'Base de Datos'): ?>
                                    <li>Verifica permisos de usuario en MySQL/MariaDB</li>
                                    <li>Confirma que las claves foráneas existan</li>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="cerrarModalDebug">Cerrar</button>
                        <button type="button" class="btn btn-primary" onclick="navigator.clipboard.writeText(document.querySelector('.modal-body code').textContent)">
                            📋 Copiar Error
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Backdrop manual -->
        <div class="modal-backdrop fade show" x-show="show" x-transition></div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



    
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO -->
        <div class="flex items-center justify-between px-5 py-3 mb-4 font-semibold text-white rounded-t" :class="{'bg-emerald-600': theme === 'verde','bg-blue-600': theme === 'azul','bg-gray-900': theme === 'oscuro','bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'}">
            <h5 class="mb-0 text-lg">Gestión de CAI</h5>
            <button wire:click="abrirModalCrear" class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                <span>➕</span> Ingresar Cai
            </button>
        </div>

        <!-- TABLA -->
        <div class="px-4 py-3 pt-0 card-body">
            <div class="table-responsive">
                <table id="tbl_cai" class="table mb-0 align-middle table-sm table-hover table-bordered">
                    <thead class="table-light">
                        <tr class="text-center align-middle">
                            <th>Cod</th>
                            <th>Doc. Fiscal</th>
                            <th>Nombre Comercial</th>
                            <th>Cai</th>
                            <th>Rango Inicial</th>
                            <th>Rango Final</th>
                            <th>Limite Emisión</th>
                            <th>Solicitud</th>
                            <th>Punto Emisión</th>
                            <th>Cant. Solicitada</th>
                            <th>Cant. Ortogada</th>
                            <th>Registrado por</th>
                            <th>Estado</th>
                            <th>Registro</th>
                            <th>Ult. Modificación</th>
                        </tr>
                    </thead>

                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center align-middle hover:bg-gray-50 <?php echo e($item->estado_id == 1 ? 'cai-row-active' : 'cai-row-inactive'); ?>">
                                <td class="fw-semibold"><?php echo e($item->id); ?></td>
                                <td class="text-start"><?php echo e($item->tipo_documento_fiscal); ?></td>
                                <td class="text-start"><?php echo e($item->denominacion_social); ?></td>
                                <td class="text-start"><?php echo e($item->cai); ?></td>
                                <td class="text-start"><?php echo e($item->rango_inicio); ?></td>
                                <td class="text-start"><?php echo e($item->rango_final); ?></td>
                                <td class="text-start"><?php echo e($item->fecha_limite_emision); ?></td>
                                <td class="text-start"><?php echo e($item->fecha_solicitud); ?></td>
                                <td class="text-start"><?php echo e($item->punto_emision); ?></td>
                                <td class="text-start"><?php echo e($item->cantidad_solicitada); ?></td>
                                <td class="text-start"><?php echo e($item->cantidad_otorgada); ?></td>
                                <td class="text-start"><?php echo e($item->users_registro); ?></td>
                                <td class="text-start">
                                    <span class="badge <?php echo e($item->estado_id == 1 ? 'badge-active' : 'badge-inactive'); ?>">
                                        <?php echo e($item->estado_id == 1 ? 'Activo' : 'Inactivo'); ?>

                                    </span>
                                </td>

                                <td class="text-start"><?php echo e($item->created_at); ?></td>
                                <td class="text-start"><?php echo e($item->updated_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                 <td colspan="14" class="text-center">No hay registros disponibles.</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </tbody>
                </table>
            </div>
        </div>

    </div>


    
    <div wire:key="modal-nuevp-cai">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($modalCrearAbierto): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cerrarModalCrear()"
        >
            <div class="modal-dialog modal-dialog-centered modal-xl">
                <div class="modal-content">
                    <div class="modal-header"
                         :class="{
                            'bg-emerald-700 text-white': theme === 'verde',
                            'bg-blue-700 text-white': theme === 'azul',
                            'bg-gray-900 text-white': theme === 'oscuro',
                            'bg-slate-700 text-white': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                         }"
                    >
                        <h5 class="modal-title">Ingreso de CAI</h5>
                    </div>
                    <div class="modal-body">
                        <form wire:submit.prevent="crearCai">
                            <div class="row">
                                <div class="mb-2 col-md-4">
                                    <label for="nuevoCai" class="form-label">CAI</label>
                                    <input type="text" id="nuevoCai" class="form-control" wire:model.defer="nuevoCai"  title="El CAI debe tener el formato ####-####-####-####-####-####" maxlength="39">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoCai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="nuevoFechaLimite" class="form-label">Fecha límite</label>
                                    <input type="date" id="nuevoFechaLimite" class="form-control" wire:model.defer="nuevoFechaLimite" title="Debe seleccionar una fecha límite de vigencia de este CAI.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoFechaLimite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>


                                <div class="mb-2 col-md-4">
                                    <label for="nuevoFechaSolicitud" class="form-label">Fecha de Solicitud</label>
                                    <input type="date" id="nuevoFechaSolicitud" class="form-control" wire:model.defer="nuevoFechaSolicitud" title="Debe seleccionar una fecha límite de vigencia de este CAI.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoFechaSolicitud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>


                                <div class="mb-2 col-md-4">
                                    <label for="nuevoPuntoEmision" class="form-label">Punto de Emisión</label>
                                    <input type="text" id="nuevoPuntoEmision" class="form-control" wire:model.defer="nuevoPuntoEmision" title="Debe seleccionar una fecha límite de vigencia de este CAI.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoPuntoEmision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="tipoDocumento" class="form-label">Tipo de documento</label>
                                    <select id="tipoDocumento" class="form-select" wire:model.defer="tipoDocumentoSeleccionado">
                                        <option value="">Seleccione un tipo...</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tiposDocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tipoDocumentoSeleccionado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>


                                <div class="mb-2 col-md-4"
                                    x-data="{
                                        search: '',
                                        open: false,
                                        selected: <?php if ((object) ('tiendaSeleccionado') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('tiendaSeleccionado'->value()); ?>')<?php echo e('tiendaSeleccionado'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('tiendaSeleccionado'); ?>')<?php endif; ?>,
                                        options: <?php echo e($tiendas->toJson()); ?>,
                                        filteredOptions() {
                                            if (this.search === '') return this.options;
                                            const term = this.search.toLowerCase();
                                            return this.options.filter(o =>
                                                String(o.id).toLowerCase().includes(term) ||
                                                String(o.identificador_legal).toLowerCase().includes(term) ||
                                                String(o.numero_sucursal).toLowerCase().includes(term) ||
                                                String(o.denominacion_social).toLowerCase().includes(term)
                                            );
                                        },
                                        selectOption(option) {
                                            this.selected = option.id;
                                            this.search = `${option.id} (${option.denominacion_social} - ${option.numero_sucursal})`;
                                            this.open = false;
                                        },
                                        clearSearch() {
                                            this.search = '';
                                            this.open = true;
                                        },
                                        init() {
                                            this.$watch('selected', value => {
                                                const obj = this.options.find(o => o.id == value);
                                                if (obj) {
                                                    this.search = `${obj.id} (${obj.denominacion_social} - ${obj.numero_sucursal})`;
                                                }
                                            });
                                        }
                                    }"
                                    @click.outside="open = false"
                                >
                                    <label for="tiendaId" class="form-label">Seleccionar Tienda</label>

                                    <input type="text"
                                        placeholder="Buscar..."
                                        class="mb-1 form-control"
                                        x-model="search"
                                        @focus="open = true; clearSearch()"
                                        @input="open = true"
                                    >

                                    <ul class="list-group position-absolute w-100" x-show="open" style="z-index: 10; max-height: 150px; overflow-y: auto;">
                                        <template x-for="item in filteredOptions()" :key="item.id">
                                            <li class="list-group-item list-group-item-action"
                                                @click="selectOption(item)"
                                                x-text="`${item.id} - ${item.denominacion_social} - ${item.numero_sucursal}`">
                                            </li>
                                        </template>
                                    </ul>

                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tiendaSeleccionado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="nuevoCantidadSolicitada" class="form-label">Cantidad Solicitada</label>
                                    <input type="number" id="nuevoCantidadSolicitada" step="1" min="0" oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="form-control" wire:model.defer="nuevoCantidadSolicitada" title="Debe ingresar un numero entero.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoCantidadSolicitada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="nuevoCantidadOtorgada" class="form-label">Cantidad Otorgada</label>
                                    <input type="number" id="nuevoCantidadOtorgada" step="1" min="0" oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="form-control" wire:model.defer="nuevoCantidadOtorgada" title="Debe ingresar un numero entero.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoCantidadOtorgada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="nuevoRangoInicial" class="form-label">Rango Inicial</label>
                                    <input type="text" id="nuevoRangoInicial" step="1" class="form-control" wire:model.defer="nuevoRangoInicial" title="Debe contener el formato correcto.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoRangoInicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="nuevoRangoFinal" class="form-label">Rando Final</label>
                                    <input type="text" id="nuevoRangoFinal" class="form-control" wire:model.defer="nuevoRangoFinal" title="Debe contener el formato correcto.">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoRangoFinal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                            </div>
                            <div class="flex justify-end mt-4">
                                <button
                                    type="submit"
                                    wire:loading.attr="disabled"
                                    class="px-4 py-2 text-white rounded"
                                    :class="{
                                        'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                                        'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                                        'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                                        'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                                    }"
                                >
                                    Guardar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <div wire:key="modal-<?php echo e($form['id'] ?? 'nuevo'); ?>">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($modalAbierto): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cerrarModal()"
        >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header"
                         :class="{
                            'bg-emerald-700 text-white': theme === 'verde',
                            'bg-blue-700 text-white': theme === 'azul',
                            'bg-gray-900 text-white': theme === 'oscuro',
                            'bg-slate-700 text-white': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                         }"
                    >
                        <h5 class="modal-title">Editar Marca</h5>
                    </div>
                    <div class="modal-body">
                        <form wire:submit.prevent="guardar">
                            <div class="mb-3">
                                <label for="marcaId" class="form-label">ID</label>
                                <input type="text" id="marcaId" class="form-control" wire:model="form.id" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="marcaNombre" class="form-label">Nombre</label>
                                <input type="text" id="marcaNombre" class="form-control"
                                       wire:model.defer="form.nombre">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="mt-1 text-sm text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="flex justify-end mt-4">
                                <button
                                    type="submit"
                                    class="px-4 py-2 text-white rounded"
                                    :class="{
                                        'bg-emerald-600 hover:bg-emerald-700': theme === 'verde',
                                        'bg-blue-600 hover:bg-blue-700': theme === 'azul',
                                        'bg-gray-900 hover:bg-gray-800': theme === 'oscuro',
                                        'bg-slate-700 hover:bg-slate-800': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
                                    }"
                                >
                                    Guardar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Confirmar Eliminación -->
    <div wire:key="modal-confirmar-eliminar">
        <div class="modal fade show"
             tabindex="-1"
             style="display: <?php if($modalEliminarAbierto): ?> block <?php else: ?> none <?php endif; ?>; background: rgba(0,0,0,0.5); z-index: 1000;"
             aria-modal="true"
             role="dialog"
             @click.self="window.Livewire.find('<?php echo e($_instance->getId()); ?>').cerrarModalEliminar()"
        >
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="text-white modal-header bg-danger">
                        <h5 class="modal-title">¿Eliminar marca?</h5>
                    </div>
                    <div class="modal-body">
                        <p>¿Estás seguro que deseas eliminar esta marca? Esta acción no se puede deshacer.</p>
                        <div class="flex justify-end gap-2 mt-4">
                            <button type="button" class="btn btn-secondary" wire:click="cerrarModalEliminar">No</button>
                            <button type="button" class="btn btn-danger" wire:click="eliminarMarca">Sí, eliminar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div> 
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/gestion/cai.blade.php ENDPATH**/ ?>