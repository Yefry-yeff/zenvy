<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Recibo Cierre de Caja - <?php echo e(\Carbon\Carbon::parse($cierre->fecha_cierre)->format('d/m/Y')); ?></title>
    <style>
        @page {
            size: 72.1mm 350mm;
            margin: 3mm;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 20px;
            line-height: 1.4;
            color: #000;
        }

        .container {
            width: 100%;
            max-width: 66mm;
        }

        .text-center {
            text-align: center;
        }

        .text-left {
            text-align: left;
        }

        .text-right {
            text-align: right;
        }

        .separator {
            border-top: 1px dashed #000;
            margin: 8px 0;
        }

        .double-separator {
            border-top: 2px solid #000;
            margin: 8px 0;
        }

        .company-name {
            font-weight: bold;
            font-size: 22px;
            text-transform: uppercase;
            margin-bottom: 3px;
        }

        .business-name {
            font-weight: bold;
            font-size: 19px;
            margin: 2px 0;
        }

        .company-info {
            font-size: 17px;
            margin: 1px 0;
        }

        .title {
            font-weight: bold;
            font-size: 22px;
            text-align: center;
            margin: 8px 0;
        }

        .subtitle {
            font-size: 16px;
            text-align: center;
            margin: 4px 0;
        }

        .info-row {
            font-size: 16px;
            margin: 4px 0;
        }

        .section-title {
            font-weight: bold;
            font-size: 18px;
            margin: 8px 0 4px 0;
            text-align: center;
        }

        .table-row {
            display: table;
            width: 100%;
            margin-bottom: 2px;
            font-size: 16px;
        }

        .col-left {
            display: table-cell;
            width: 60%;
            padding-right: 5px;
        }

        .col-right {
            display: table-cell;
            width: 40%;
            text-align: right;
        }

        .total-row {
            font-weight: bold;
            font-size: 18px;
            margin: 6px 0;
        }

        .denominacion-row {
            font-size: 15px;
            margin-bottom: 2px;
        }

        .highlight {
            font-weight: bold;
            font-size: 20px;
            margin: 8px 0;
        }

        .diferencia-positiva {
            color: #000;
        }

        .diferencia-negativa {
            color: #000;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- ENCABEZADO -->
        <div class="text-center">
            <?php if($empresa && $empresa->logo): ?>
                <div style="margin-bottom: 4px;">
                    <img src="data:image/png;base64,<?php echo e(base64_encode($empresa->logo)); ?>"
                         style="max-width: 45mm; max-height: 12mm;">
                </div>
            <?php endif; ?>

            <?php if($tienda && $tienda->denominacion_social): ?>
                <div class="company-name">
                    <?php echo e($tienda->denominacion_social); ?>

                </div>
            <?php endif; ?>

            <?php if($empresa && $empresa->nombre): ?>
                <div class="business-name">
                    <?php echo e($empresa->nombre); ?>

                </div>
            <?php endif; ?>

            <?php if($empresa && $empresa->rtn): ?>
                <div class="company-info">
                    RTN: <?php echo e($empresa->rtn); ?>

                </div>
            <?php endif; ?>

            <?php if($tienda && $tienda->domicilio_tributario): ?>
                <div class="company-info">
                    <?php echo e($tienda->domicilio_tributario); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="separator"></div>

        <!-- TÍTULO -->
        <div class="title">
            CIERRE DE CAJA
        </div>

        <!-- INFORMACIÓN DEL CIERRE -->
        <div class="info-row">
            <strong>Cajero:</strong> <?php echo e($usuario->name); ?>

        </div>
        <div class="info-row">
            <strong>Fecha:</strong> <?php echo e(\Carbon\Carbon::parse($cierre->fecha_cierre)->format('d/m/Y')); ?>

        </div>
        <div class="info-row">
            <strong>Hora:</strong> <?php echo e(\Carbon\Carbon::parse($cierre->fecha_cierre)->format('H:i:s')); ?>

        </div>
        <div class="info-row">
            <strong>Total Transacciones:</strong> <?php echo e($cierre->cantidad_facturas ?? 0); ?>

        </div>

        <div class="separator"></div>

        <!-- RESUMEN DE TRANSACCIONES -->
        <div class="section-title">
            RESUMEN DE VENTAS
        </div>

        <?php $__currentLoopData = $resumenTransacciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="table-row">
                <div class="col-left"><?php echo e($item->forma_pago); ?></div>
                <div class="col-right">L. <?php echo e(number_format($item->total, 2)); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="separator"></div>
        <div class="table-row total-row">
            <div class="col-left">TOTAL VENTAS:</div>
            <div class="col-right">L. <?php echo e(number_format($resumenTransacciones->sum('total'), 2)); ?></div>
        </div>

        <!-- REVERSIÓN DE FACTURAS ANULADAS -->
        <?php if($facturasAnuladas['efectivo'] > 0 || $facturasAnuladas['tarjeta'] > 0 || $facturasAnuladas['transferencia'] > 0 || $facturasAnuladas['cheque'] > 0): ?>
            <div class="double-separator"></div>
            <div class="section-title" style="color: #dc2626;">
                REVERSIÓN DE FACTURAS
            </div>
            <div style="font-size: 8px; text-align: center; margin-bottom: 5px; color: #6b7280;">
                (Se restan del total del sistema)
            </div>

            <?php if($facturasAnuladas['efectivo'] > 0): ?>
            <div class="table-row">
                <div class="col-left">Efectivo:</div>
                <div class="col-right" style="color: #dc2626;">- L. <?php echo e(number_format($facturasAnuladas['efectivo'], 2)); ?></div>
            </div>
            <?php endif; ?>

            <?php if($facturasAnuladas['tarjeta'] > 0): ?>
            <div class="table-row">
                <div class="col-left">Tarjeta:</div>
                <div class="col-right" style="color: #dc2626;">- L. <?php echo e(number_format($facturasAnuladas['tarjeta'], 2)); ?></div>
            </div>
            <?php endif; ?>

            <?php if($facturasAnuladas['transferencia'] > 0): ?>
            <div class="table-row">
                <div class="col-left">Transferencia:</div>
                <div class="col-right" style="color: #dc2626;">- L. <?php echo e(number_format($facturasAnuladas['transferencia'], 2)); ?></div>
            </div>
            <?php endif; ?>

            <?php if($facturasAnuladas['cheque'] > 0): ?>
            <div class="table-row">
                <div class="col-left">Cheque:</div>
                <div class="col-right" style="color: #dc2626;">- L. <?php echo e(number_format($facturasAnuladas['cheque'], 2)); ?></div>
            </div>
            <?php endif; ?>

            <div class="separator"></div>
            <div class="table-row total-row" style="color: #dc2626;">
                <div class="col-left">TOTAL REVERSIONES:</div>
                <div class="col-right">- L. <?php echo e(number_format($facturasAnuladas['efectivo'] + $facturasAnuladas['tarjeta'] + $facturasAnuladas['transferencia'] + $facturasAnuladas['cheque'], 2)); ?></div>
            </div>
        <?php endif; ?>

        <div class="double-separator"></div>

        <!-- CONTABILIZACIÓN DE MÉTODOS DE PAGO -->
        <div class="section-title">
            CONTABILIZACIÓN
        </div>

        <?php if(($cierre->total_tarjeta ?? 0) > 0): ?>
        <div class="table-row">
            <div class="col-left">Tarjeta:</div>
            <div class="col-right">L. <?php echo e(number_format($cierre->total_tarjeta, 2)); ?></div>
        </div>
        <?php endif; ?>

        <?php if(($cierre->total_transferencia ?? 0) > 0): ?>
        <div class="table-row">
            <div class="col-left">Transferencia:</div>
            <div class="col-right">L. <?php echo e(number_format($cierre->total_transferencia, 2)); ?></div>
        </div>
        <?php endif; ?>

        <?php if(($cierre->total_cheque ?? 0) > 0): ?>
        <div class="table-row">
            <div class="col-left">Cheque:</div>
            <div class="col-right">L. <?php echo e(number_format($cierre->total_cheque, 2)); ?></div>
        </div>
        <?php endif; ?>

        <div class="separator"></div>

        <!-- EFECTIVO -->
        <div class="section-title">
            EFECTIVO
        </div>

        <?php if(count($denominaciones) > 0): ?>
            <div class="subtitle"><strong>Denominaciones Contadas:</strong></div>
            <?php $__currentLoopData = $denominaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="table-row denominacion-row">
                    <div class="col-left"><?php echo e($denom['denominacion']); ?> × <?php echo e($denom['cantidad']); ?></div>
                    <div class="col-right">L. <?php echo e(number_format($denom['total'], 2)); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <div class="separator"></div>
        <div class="table-row total-row">
            <div class="col-left">Total Contado:</div>
            <div class="col-right">L. <?php echo e(number_format($cierre->total_efectivo_contado, 2)); ?></div>
        </div>

        <div class="table-row highlight <?php echo e($cierre->diferencia >= 0 ? 'diferencia-positiva' : 'diferencia-negativa'); ?>">
            <div class="col-left">Diferencia Efectivo:</div>
            <div class="col-right">L. <?php echo e(number_format($cierre->diferencia, 2)); ?></div>
        </div>

        <div class="double-separator"></div>

        <!-- DEPÓSITO -->
        <div class="section-title" style="font-size: 20px;">
            DEPÓSITO
        </div>

        <div class="info-row">
            <div class="table-row">
                <div class="col-left">Efectivo:</div>
                <div class="col-right">L. <?php echo e(number_format($cierre->total_efectivo_sistema, 2)); ?></div>
            </div>
            <?php if($cierre->diferencia > 0): ?>
            <div class="table-row">
                <div class="col-left">Sobrante de conteo:</div>
                <div class="col-right">L. <?php echo e(number_format($cierre->diferencia, 2)); ?></div>
            </div>
            <?php endif; ?>
            <div class="table-row">
                <div class="col-left">Menos saldo inicial:</div>
                <div class="col-right">- L. 2,000.00</div>
            </div>
        </div>

        <div class="separator"></div>

        <div class="table-row" style="font-weight: bold; font-size: 22px;">
            <div class="col-left">MONTO A DEPOSITAR:</div>
            <div class="col-right">L. <?php echo e(number_format($montoDeposito, 2)); ?></div>
        </div>

        <div class="separator"></div>

        <!-- PIE DE PÁGINA -->
        <div class="text-center" style="font-size: 14px; margin-top: 10px;">
            <div>Este documento es un comprobante</div>
            <div>interno de cierre de caja</div>
            <div style="margin-top: 6px;">¡Gracias!</div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/pdf/recibo-cierre-caja.blade.php ENDPATH**/ ?>