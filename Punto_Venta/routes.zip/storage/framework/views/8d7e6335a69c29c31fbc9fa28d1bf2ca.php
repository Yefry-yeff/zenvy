

<div> 

    
    
    <div class="overflow-hidden border border-gray-300 rounded shadow" x-data x-init="$watch('theme', t => localStorage.setItem('theme', t))">

        <!-- ENCABEZADO PRINCIPAL -->
        <div class="flex items-center justify-between px-5 py-3 mb-4 font-semibold text-white rounded-t"
            
            :class="{
                'bg-emerald-600': theme === 'verde',
                'bg-blue-600': theme === 'azul',
                'bg-gray-900': theme === 'oscuro',
                'bg-slate-700': theme !== 'verde' && theme !== 'azul' && theme !== 'oscuro'
            }"
        >
            <div>
                
                <h5 class="mb-0 text-lg">
                    <i class="fas fa-boxes me-2"></i>Productos en Sección
                </h5>
            </div>

            
            <div class="flex gap-2">
                <button wire:click="volverASecciones"
                    class="inline-flex items-center gap-1 px-3 py-2 text-sm text-gray-800 bg-white rounded hover:bg-gray-100">
                    <i class="fas fa-arrow-left"></i> Volver a Secciones
                </button>
            </div>
        </div>

        
        <!-- CONTENIDO PRINCIPAL -->
        <div class="px-4 py-3 pt-0 card-body">
            
            <!-- Información de la Sección -->
            <!--[if BLOCK]><![endif]--><?php if($seccion): ?>
                <div class="p-3 mb-4 rounded bg-light">
                    <div class="row">
                        
                        <div class="col-md-3">
                            <strong><i class="fas fa-store text-warning me-2"></i>Tienda:</strong><br>
                            
                            <?php echo e($seccion->segmento->bodega->tienda->denominacion_social ?? 'N/A'); ?>

                        </div>

                        
                        <div class="col-md-3">
                            <strong><i class="fas fa-warehouse text-primary me-2"></i>Bodega:</strong><br>
                            
                            <?php echo e($seccion->segmento->bodega->nombre); ?>

                        </div>

                        
                        <div class="col-md-3">
                            <strong><i class="fas fa-layer-group text-success me-2"></i>Segmento:</strong><br>
                            
                            <?php echo e($seccion->segmento->descripcion); ?>

                        </div>

                        
                        <div class="col-md-3">
                            <strong><i class="fas fa-cube text-info me-2"></i>Sección:</strong><br>
                            
                            <?php echo e($seccion->descripcion); ?> (<?php echo e($seccion->numeracion); ?>)
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

           

           <!-- Información sobre funcionalidad -->
           <div class="p-3 mb-3 border rounded bg-info bg-opacity-10 border-info">
               <div class="d-flex align-items-center">
                   <i class="fas fa-info-circle text-info me-2"></i>
                   <div>
                       <strong>Edición de Stock:</strong>
                       <small>Haga clic en cualquier fila para editar las cantidades de stock del producto. El stock en sección no puede exceder la cantidad del lote de compra.</small>
                   </div>
               </div>
           </div>

           <!-- Tabla de Productos -->
            <div class="table-responsive">
                
                <table id="productosSeccionTable" class="table mb-0 align-middle table-sm table-hover table-bordered">
                    
                    <thead class="table-light">
                        <tr class="text-center align-middle">
                            <th>ID</th>                 
                            <th>Producto</th>           
                            <th>Código</th>             
                            <th>Marca</th>              
                            <th>Categoría</th>          
                            <th>U. Medida</th>          
                            <th class="bg-opacity-25 bg-warning"><i class="fas fa-cubes me-1"></i>Stock</th>   
                            <th>F. Recibido</th>        
                            <th>F. Expiración</th>      
                            <th>Precio Base</th>        
                            <th>Estado</th>             
                        </tr>
                    </thead>
                    <tbody>
                        
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recibido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center align-middle transition-colors duration-200 cursor-pointer hover:bg-blue-50 hover:shadow-sm"
                                wire:click="editarProducto(<?php echo e($recibido->producto->id); ?>)"
                                title="🖱️ Haga clic para editar el stock de este producto"
                                style="user-select: none;">
                                
                                <td><?php echo e($recibido->producto->id); ?></td>
                                

                                
                                <td class="text-start">
                                    <div>
                                        
                                        <strong><?php echo e($recibido->producto->nombre); ?></strong><br>
                                        

                                        
                                        <small class="text-muted"><?php echo e(\Illuminate\Support\Str::limit($recibido->producto->descripcion, 50)); ?></small>
                                        
                                    </div>
                                </td>

                                
                                <td>
                                    
                                    <!--[if BLOCK]><![endif]--><?php if($recibido->producto->codigo_barra): ?>
                                        <span class="badge bg-primary"><?php echo e($recibido->producto->codigo_barra); ?></span><br>
                                        
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    
                                    <!--[if BLOCK]><![endif]--><?php if($recibido->producto->codigo_estatal): ?>
                                        <span class="badge bg-secondary"><?php echo e($recibido->producto->codigo_estatal); ?></span>
                                        
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>

                                
                                <td><?php echo e($recibido->producto->marca->nombre ?? 'Sin marca'); ?></td>
                                
                                

                                
                                <td>
                                    
                                    <?php echo e($recibido->producto->subcategoria->categoria->nombre ?? 'Sin categoría'); ?><br>
                                    
                                    

                                    
                                    <small class="text-muted"><?php echo e($recibido->producto->subcategoria->txt_nombre ?? 'N/A'); ?></small>
                                    
                                </td>

                                
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo e($recibido->producto->unidadMedidaCompra->nombre ?? 'N/A'); ?>

                                        
                                        
                                    </span>
                                </td>

                                
                                <td>
                                    
                                    <span class="badge <?php echo e($recibido->cantidad_disponible > 10 ? 'bg-success' : ($recibido->cantidad_disponible > 0 ? 'bg-warning' : 'bg-danger')); ?>">
                                        <?php echo e($recibido->cantidad_disponible); ?>

                                        
                                    </span>
                                </td>
                                
                                <td><?php echo e($this->formatearFecha($recibido->fecha_recibido)); ?></td>
                                
                                

                                
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($recibido->fecha_expiracion): ?>
                                        
                                        <span class="badge <?php echo e(\Carbon\Carbon::parse($recibido->fecha_expiracion)->isPast() ? 'bg-danger' : 'bg-success'); ?>">
                                            <?php echo e($this->formatearFecha($recibido->fecha_expiracion)); ?>

                                            
                                            
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                        
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>

                                
                                <td class="text-end">L. <?php echo e(number_format($recibido->producto->precio_base ?? 0, 2)); ?></td>
                                
                                
                                

                                
                                <td>
                                    <span class="<?php echo e($this->obtenerEstadoClase($recibido->producto->estado_id)); ?>">
                                        <?php echo e($this->obtenerEstadoTexto($recibido->producto->estado_id)); ?>

                                        
                                        
                                        
                                        
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                            <tr>
                                <td colspan="11" class="py-4 text-center text-muted">No hay productos disponibles en esta sección.</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
            

        </div>
        

        

        
        <!--[if BLOCK]><![endif]--><?php if($mostrarModalExito): ?>
            
            <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="text-white modal-header bg-success">
                            <h5 class="modal-title">
                                <i class="fas fa-check-circle me-2"></i>¡Éxito!
                            </h5>
                        </div>
                        <div class="modal-body">
                            <div class="text-center">
                                <i class="fas fa-check-circle text-success" style="font-size: 3rem;"></i>
                                <p class="mt-3 mb-0"><?php echo e($mensajeModalExito); ?></p>
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" wire:click="cerrarModalExito" class="btn btn-success">
                                
                                <i class="fas fa-check me-2"></i>Entendido
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($mostrarModalError): ?>
            
            <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="text-white modal-header bg-danger">
                            <h5 class="modal-title">
                                <i class="fas fa-exclamation-triangle me-2"></i>Error
                            </h5>
                        </div>
                        <div class="modal-body">
                            <div class="text-center">
                                <i class="fas fa-exclamation-triangle text-danger" style="font-size: 3rem;"></i>
                                <p class="mt-3 mb-0"><?php echo e($mensajeModalError); ?></p>
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" wire:click="cerrarModalError" class="btn btn-danger">
                                
                                <i class="fas fa-times me-2"></i>Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    

    
    <!-- Estilos CSS adicionales -->
    <style>
        
        .modal.show {
            display: block !important;
        }

        
        .table td .badge {
            font-size: 0.75rem;
        }

        
        @media (max-width: 768px) {
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>

    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('mensaje')): ?>
        
        <div x-data="{ show: true }" x-show="show"
             
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="mt-3 mb-0 transition-opacity duration-300 alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <?php if(session()->has('error')): ?>
        
        <div x-data="{ show: true }" x-show="show"
             
             @click.window="show = false"
             @keydown.window="show = false"
             @mousemove.window="show = false"
             class="mt-3 mb-0 transition-opacity duration-300 alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>

<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/productos-seccion.blade.php ENDPATH**/ ?>