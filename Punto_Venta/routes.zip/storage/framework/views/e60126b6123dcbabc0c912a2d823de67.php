<div>
    
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/inventario/lista-de-producto.blade.php ENDPATH**/ ?>