<?php
    $componentClass = 'App\\Livewire\\' . str_replace('.', '\\', $vista);
?>

<div>
    

    <!--[if BLOCK]><![endif]--><?php if(class_exists($componentClass)): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($vista, $parametros);

$__html = app('livewire')->mount($__name, $__params, $componenteId, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php else: ?>
        <p class="font-semibold text-red-600">❌ Componente Livewire no encontrado para: <?php echo e($vista); ?></p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/dynamic-content.blade.php ENDPATH**/ ?>