<div class="container-fluid px-4">
    <!-- Encabezado -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-0 text-gray-800">
                <i class="fas fa-ban text-danger"></i> Reporte de Facturas Anuladas
            </h1>
        </div>
    </div>

    <!-- Tarjetas de resumen -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                Total Facturas Anuladas
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($totalRegistros); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-ban fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Monto Total Anulado
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">L. <?php echo e(number_format($totalMonto, 2)); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-coins fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-gradient-danger">
            <h6 class="m-0 font-weight-bold text-white">
                <i class="fas fa-filter"></i> Filtros de Búsqueda
            </h6>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Número de Factura -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">N° Factura</label>
                    <input type="text" 
                           wire:model.live.debounce.300ms="filtroNumeroFactura"
                           class="form-control form-control-sm"
                           placeholder="Buscar...">
                </div>

                <!-- Cliente -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Cliente</label>
                    <input type="text" 
                           wire:model.live.debounce.300ms="filtroCliente"
                           class="form-control form-control-sm"
                           placeholder="Buscar...">
                </div>

                <!-- Usuario que Anuló -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Usuario que Anuló</label>
                    <input type="text" 
                           wire:model.live.debounce.300ms="filtroUsuarioAnulo"
                           class="form-control form-control-sm"
                           placeholder="Buscar...">
                </div>

                <!-- Vendedor -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Vendedor Original</label>
                    <input type="text" 
                           wire:model.live.debounce.300ms="filtroVendedor"
                           class="form-control form-control-sm"
                           placeholder="Buscar...">
                </div>
            </div>

            <div class="row">
                <!-- Fecha Anulación Inicio -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Fecha Anulación (Desde)</label>
                    <input type="date" 
                           wire:model.live="filtroFechaAnulacionInicio"
                           class="form-control form-control-sm">
                </div>

                <!-- Fecha Anulación Fin -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Fecha Anulación (Hasta)</label>
                    <input type="date" 
                           wire:model.live="filtroFechaAnulacionFin"
                           class="form-control form-control-sm">
                </div>

                <!-- Fecha Emisión Inicio -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Fecha Emisión (Desde)</label>
                    <input type="date" 
                           wire:model.live="filtroFechaEmisionInicio"
                           class="form-control form-control-sm">
                </div>

                <!-- Fecha Emisión Fin -->
                <div class="col-md-3 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Fecha Emisión (Hasta)</label>
                    <input type="date" 
                           wire:model.live="filtroFechaEmisionFin"
                           class="form-control form-control-sm">
                </div>
            </div>

            <div class="row">
                <!-- Motivo -->
                <div class="col-md-12 mb-3">
                    <label class="text-xs font-weight-bold text-gray-700">Motivo de Anulación</label>
                    <input type="text" 
                           wire:model.live.debounce.300ms="filtroMotivo"
                           class="form-control form-control-sm"
                           placeholder="Buscar por motivo...">
                </div>
            </div>
        </div>
    </div>

    <!-- Tabla -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-gradient-danger">
            <div class="d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-white">
                    <i class="fas fa-table"></i> Listado de Facturas Anuladas
                </h6>
                <button wire:click="exportarExcel" 
                        class="btn btn-success btn-sm"
                        wire:loading.attr="disabled"
                        wire:target="exportarExcel">
                    <span wire:loading.remove wire:target="exportarExcel">
                        <i class="fas fa-file-excel"></i> Exportar Excel
                    </span>
                    <span wire:loading wire:target="exportarExcel">
                        <i class="fas fa-spinner fa-spin"></i> Generando...
                    </span>
                </button>
            </div>
        </div>
        <div class="card-body">
            <!--[if BLOCK]><![endif]--><?php if($facturasAnuladas->count() > 0): ?>
                <div class="table-responsive" style="max-height: calc(100vh - 500px); overflow-y: auto;">
                    <table class="table table-bordered table-hover table-sm text-xs">
                        <thead class="bg-danger text-white sticky-top">
                            <tr>
                                <th class="cursor-pointer" wire:click="ordenar('id')">
                                    ID
                                    <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'id'): ?>
                                        <i class="fas fa-sort-<?php echo e($direccionOrden === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                                <th class="cursor-pointer" wire:click="ordenar('numero_factura')">
                                    N° Factura
                                    <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'numero_factura'): ?>
                                        <i class="fas fa-sort-<?php echo e($direccionOrden === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                                <th>Cliente</th>
                                <th class="cursor-pointer" wire:click="ordenar('fecha_emision_factura')">
                                    F. Emisión
                                    <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'fecha_emision_factura'): ?>
                                        <i class="fas fa-sort-<?php echo e($direccionOrden === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                                <th class="cursor-pointer" wire:click="ordenar('fecha_anulacion')">
                                    F. Anulación
                                    <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'fecha_anulacion'): ?>
                                        <i class="fas fa-sort-<?php echo e($direccionOrden === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                                <th class="text-right cursor-pointer" wire:click="ordenar('total')">
                                    Total
                                    <!--[if BLOCK]><![endif]--><?php if($ordenarPor === 'total'): ?>
                                        <i class="fas fa-sort-<?php echo e($direccionOrden === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                                <th>Vendedor</th>
                                <th>Anuló</th>
                                <th>Motivo</th>
                                <th class="text-center">Detalles</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $facturasAnuladas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anulacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="font-weight-bold"><?php echo e($anulacion->id); ?></td>
                                    <td>
                                        <span class="badge badge-danger"><?php echo e($anulacion->numero_factura); ?></span>
                                    </td>
                                    <td>
                                        <div><?php echo e($anulacion->nombre_cliente ?? 'N/A'); ?></div>
                                        <!--[if BLOCK]><![endif]--><?php if($anulacion->rtn): ?>
                                            <small class="text-muted">RTN: <?php echo e($anulacion->rtn); ?></small>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td class="text-center">
                                        <?php echo e(\Carbon\Carbon::parse($anulacion->fecha_emision_factura)->format('d/m/Y')); ?>

                                    </td>
                                    <td class="text-center">
                                        <div class="font-weight-bold text-danger">
                                            <?php echo e(\Carbon\Carbon::parse($anulacion->fecha_anulacion)->format('d/m/Y')); ?>

                                        </div>
                                        <small class="text-muted">
                                            <?php echo e(\Carbon\Carbon::parse($anulacion->fecha_anulacion)->format('H:i:s')); ?>

                                        </small>
                                    </td>
                                    <td class="text-right font-weight-bold text-danger">
                                        L. <?php echo e(number_format($anulacion->total, 2)); ?>

                                    </td>
                                    <td>
                                        <i class="fas fa-user-tie"></i> <?php echo e($anulacion->vendedor_nombre); ?>

                                    </td>
                                    <td>
                                        <i class="fas fa-user-shield"></i> <?php echo e($anulacion->usuario_anulo_nombre); ?>

                                    </td>
                                    <td>
                                        <div class="text-truncate" style="max-width: 200px;" title="<?php echo e($anulacion->motivo_anulacion); ?>">
                                            <?php echo e(Str::limit($anulacion->motivo_anulacion, 50)); ?>

                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" 
                                                class="btn btn-sm btn-info"
                                                onclick="$('#modalDetalle<?php echo e($anulacion->id); ?>').modal('show')">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <!-- Modales fuera del loop -->
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $facturasAnuladas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anulacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Modal de Detalles -->
                    <div class="modal fade" id="modalDetalle<?php echo e($anulacion->id); ?>" tabindex="-1" wire:ignore.self>
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title">
                                                    <i class="fas fa-info-circle"></i> Detalles de Anulación - Factura <?php echo e($anulacion->numero_factura); ?>

                                                </h5>
                                                <button type="button" class="close text-white" onclick="event.preventDefault(); event.stopPropagation(); var modal = $('#modalDetalle<?php echo e($anulacion->id); ?>'); modal.find('*').blur(); modal.modal('hide'); return false;">
                                                    <span>&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h6 class="border-bottom pb-2"><i class="fas fa-file-invoice"></i> Información de Factura</h6>
                                                        <p><strong>N° Factura:</strong> <?php echo e($anulacion->numero_factura); ?></p>
                                                        <p><strong>Cliente:</strong> <?php echo e($anulacion->nombre_cliente ?? 'N/A'); ?></p>
                                                        <p><strong>RTN:</strong> <?php echo e($anulacion->rtn ?? 'N/A'); ?></p>
                                                        <p><strong>Subtotal:</strong> L. <?php echo e(number_format($anulacion->sub_total, 2)); ?></p>
                                                        <p><strong>ISV:</strong> L. <?php echo e(number_format($anulacion->isv, 2)); ?></p>
                                                        <p><strong>Total:</strong> <span class="text-danger font-weight-bold">L. <?php echo e(number_format($anulacion->total, 2)); ?></span></p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <h6 class="border-bottom pb-2"><i class="fas fa-ban"></i> Información de Anulación</h6>
                                                        <p><strong>Fecha Emisión:</strong> <?php echo e(\Carbon\Carbon::parse($anulacion->fecha_emision_factura)->format('d/m/Y')); ?></p>
                                                        <p><strong>Fecha Anulación:</strong> <?php echo e(\Carbon\Carbon::parse($anulacion->fecha_anulacion)->format('d/m/Y H:i:s')); ?></p>
                                                        <p><strong>Vendedor:</strong> <?php echo e($anulacion->vendedor_nombre); ?></p>
                                                        <p><strong>Anuló:</strong> <?php echo e($anulacion->usuario_anulo_nombre); ?></p>
                                                        <p><strong>Método Devolución:</strong> 
                                                            <!--[if BLOCK]><![endif]--><?php switch($anulacion->metodo_devolucion):
                                                                case ('efectivo'): ?>
                                                                    <span class="badge badge-success">💵 Efectivo</span>
                                                                    <?php break; ?>
                                                                <?php case ('transferencia'): ?>
                                                                    <span class="badge badge-info">🏦 Transferencia</span>
                                                                    <?php break; ?>
                                                                <?php case ('nota_credito'): ?>
                                                                    <span class="badge badge-warning">📝 Nota Crédito</span>
                                                                    <?php break; ?>
                                                                <?php default: ?>
                                                                    <span class="badge badge-secondary">❌ No Aplica</span>
                                                            <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </p>
                                                        <!--[if BLOCK]><![endif]--><?php if($anulacion->impacto_flujo_caja): ?>
                                                            <p><strong>Impacto Flujo:</strong> <span class="text-danger">L. <?php echo e(number_format($anulacion->impacto_flujo_caja, 2)); ?></span></p>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                                <div class="row mt-3">
                                                    <div class="col-12">
                                                        <h6 class="border-bottom pb-2"><i class="fas fa-comment-alt"></i> Motivo de Anulación</h6>
                                                        <p class="bg-light p-3 rounded"><?php echo e($anulacion->motivo_anulacion); ?></p>
                                                    </div>
                                                </div>
                                                <!--[if BLOCK]><![endif]--><?php if($anulacion->observaciones): ?>
                                                    <div class="row mt-2">
                                                        <div class="col-12">
                                                            <h6 class="border-bottom pb-2"><i class="fas fa-sticky-note"></i> Observaciones</h6>
                                                            <p class="bg-light p-3 rounded"><?php echo e($anulacion->observaciones); ?></p>
                                                        </div>
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" onclick="event.preventDefault(); event.stopPropagation(); var modal = $('#modalDetalle<?php echo e($anulacion->id); ?>'); modal.find('*').blur(); modal.modal('hide'); return false;">Cerrar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Paginación -->
                <div class="mt-3">
                    <?php echo e($facturasAnuladas->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                    <h5>No hay facturas anuladas</h5>
                    <p class="text-muted">No se encontraron registros con los filtros aplicados.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('livewire:load', function () {
        // Reinicializar modales después de actualizaciones de Livewire
        Livewire.hook('message.processed', (message, component) => {
            // Asegurar que Bootstrap modal esté disponible
            if (typeof $ !== 'undefined' && $.fn.modal) {
                $('.modal').modal('dispose');
            }
        });

        // Prevenir el error de aria-hidden
        $(document).on('show.bs.modal', '.modal', function () {
            $(this).removeAttr('aria-hidden');
        });

        $(document).on('shown.bs.modal', '.modal', function () {
            $(this).removeAttr('aria-hidden');
            // Asegurar que no haya focus en elementos cuando aria-hidden está presente
            $(this).find('[aria-hidden="true"]').removeAttr('aria-hidden');
        });

        $(document).on('hide.bs.modal', '.modal', function () {
            $(this).removeAttr('aria-hidden');
            // Remover focus del modal antes de cerrarlo
            $(this).find('*').blur();
        });

        $(document).on('hidden.bs.modal', '.modal', function () {
            $(this).removeAttr('aria-hidden');
            $(this).removeAttr('style');
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open');
            $('body').css('padding-right', '');
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\Procadts\zenvy\Punto_Venta\resources\views/livewire/reporte/facturas-anuladas.blade.php ENDPATH**/ ?>